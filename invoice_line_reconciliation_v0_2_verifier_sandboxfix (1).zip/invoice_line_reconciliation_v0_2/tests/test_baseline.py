from __future__ import annotations

from _paths import app_solve_path, verifier_log_dir
from hidden_eval import evaluate


def test_candidate_not_below_minimal_floor():
    # This is a very low smoke-floor, not the final score. It catches broken
    # pipelines that return constants/garbage while leaving normal scoring to
    # test_main.py.
    reward, metrics = evaluate(app_solve_path(), verifier_log_dir() / "baseline_floor")
    assert reward >= 0.02, f"candidate below minimal baseline floor: reward={reward:.6f}, metrics={metrics}"
