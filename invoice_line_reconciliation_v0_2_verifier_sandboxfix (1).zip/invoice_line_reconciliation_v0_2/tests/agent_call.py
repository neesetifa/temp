#!/usr/bin/env python3
"""Sandbox-side agent runner for invoice_line_reconciliation.

The root verifier writes plain .npz inputs, this unprivileged subprocess loads the
candidate once, runs fit + predict in-process, and writes only plain .npz outputs.
No params or pickled objects cross the sandbox boundary.
"""
from __future__ import annotations

import importlib.util
import json
import os
from pathlib import Path
import sys
import traceback

import numpy as np

REQUIRED = ("fit_invoice_model", "predict_net_line_cost")


def _load(path: str | os.PathLike):
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"candidate file not found: {path}")
    sys.path.insert(0, str(path.parent))
    spec = importlib.util.spec_from_file_location("candidate_solution", str(path))
    if spec is None or spec.loader is None:
        raise ImportError(f"could not load candidate module from {path}")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def check(path: str | os.PathLike) -> bool:
    try:
        mod = _load(path)
        return all(callable(getattr(mod, name, None)) for name in REQUIRED)
    except Exception:
        return False


def _arrays_equal(a, b) -> bool:
    return np.array_equal(np.asarray(a), np.asarray(b), equal_nan=True)


def _save_error(out_path: str | os.PathLike, code: str, detail: str = "") -> None:
    np.savez(
        out_path,
        n=np.array(0, dtype=np.int64),
        error=np.array(str(code)),
        detail=np.array(str(detail)[:1200]),
    )


def run_eval(solve_path: str | os.PathLike, in_path: str | os.PathLike, out_path: str | os.PathLike) -> int:
    try:
        with np.load(in_path, allow_pickle=False) as z:
            train_line_X = np.asarray(z["train_line_X"], dtype=np.float64)
            train_line_code = np.asarray(z["train_line_code"], dtype=np.int64)
            train_invoice_X = np.asarray(z["train_invoice_X"], dtype=np.float64)
            train_invoice_code = np.asarray(z["train_invoice_code"], dtype=np.int64)
            train_invoice_offsets = np.asarray(z["train_invoice_offsets"], dtype=np.int64)
            train_y = np.asarray(z["train_y"], dtype=np.float64)
            line_X = np.asarray(z["line_X"], dtype=np.float64)
            line_code = np.asarray(z["line_code"], dtype=np.int64)
            invoice_X = np.asarray(z["invoice_X"], dtype=np.float64)
            invoice_code = np.asarray(z["invoice_code"], dtype=np.int64)
            invoice_offsets = np.asarray(z["invoice_offsets"], dtype=np.int64)
        mod = _load(solve_path)
        if not all(callable(getattr(mod, name, None)) for name in REQUIRED):
            _save_error(out_path, "api_missing", "required fit_invoice_model/predict_net_line_cost not found")
            return 0

        fit_args = [
            train_line_X.copy(),
            train_line_code.copy(),
            train_invoice_X.copy(),
            train_invoice_code.copy(),
            train_invoice_offsets.copy(),
            train_y.copy(),
        ]
        fit_before = [x.copy() for x in fit_args]
        params = mod.fit_invoice_model(*fit_args)
        if not all(_arrays_equal(a, b) for a, b in zip(fit_args, fit_before)):
            _save_error(out_path, "input_mutation_in_fit", "fit_invoice_model modified one or more input arrays")
            return 0

        pred_args = [
            line_X.copy(),
            line_code.copy(),
            invoice_X.copy(),
            invoice_code.copy(),
            invoice_offsets.copy(),
        ]
        pred_before = [x.copy() for x in pred_args]
        pred1 = np.asarray(mod.predict_net_line_cost(*pred_args, params), dtype=np.float64)
        if not all(_arrays_equal(a, b) for a, b in zip(pred_args, pred_before)):
            _save_error(out_path, "input_mutation_in_predict", "predict_net_line_cost modified one or more input arrays")
            return 0

        pred2_args = [line_X.copy(), line_code.copy(), invoice_X.copy(), invoice_code.copy(), invoice_offsets.copy()]
        pred2 = np.asarray(mod.predict_net_line_cost(*pred2_args, params), dtype=np.float64)
        if pred1.shape != pred2.shape or not np.allclose(pred1, pred2, rtol=0, atol=1e-10, equal_nan=True):
            _save_error(out_path, "nondeterministic_prediction", "two predict calls with the same params differed")
            return 0
        np.savez(out_path, n=np.array(1, dtype=np.int64), p0=pred1.astype(np.float64))
        return 0
    except Exception as exc:  # pragma: no cover - verifier diagnostic path
        _save_error(out_path, "runtime_error", traceback.format_exc())
        return 0


def main(argv: list[str]) -> int:
    if len(argv) < 3:
        print("usage: agent_call.py SOLVE_PATH {check|eval} [IN_NPZ OUT_NPZ]", file=sys.stderr)
        return 2
    solve_path = argv[1]
    cmd = argv[2]
    if cmd == "check":
        ok = check(solve_path)
        if ok:
            print(json.dumps({"ok": True}))
            return 0
        print(json.dumps({"ok": False}), file=sys.stderr)
        return 1
    if cmd == "eval":
        if len(argv) != 5:
            print("eval requires IN_NPZ and OUT_NPZ", file=sys.stderr)
            return 2
        return run_eval(solve_path, argv[3], argv[4])
    print(f"unknown command: {cmd}", file=sys.stderr)
    return 2


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
