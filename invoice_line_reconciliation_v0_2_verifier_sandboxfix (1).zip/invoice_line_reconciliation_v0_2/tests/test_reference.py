from __future__ import annotations

from _paths import reference_path, verifier_log_dir
from hidden_eval import evaluate


def test_reference_anchor_reaches_full_reward():
    reward, metrics = evaluate(reference_path(), verifier_log_dir() / "reference")
    assert reward >= 0.98, f"reference reward too low: {reward:.6f}, metrics={metrics}"
