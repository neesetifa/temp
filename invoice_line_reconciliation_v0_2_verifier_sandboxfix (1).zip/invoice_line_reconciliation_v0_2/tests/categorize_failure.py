#!/usr/bin/env python3
from __future__ import annotations

from pathlib import Path
import sys


def categorize(text: str) -> str:
    s = text.lower()
    if "api_missing" in s or "fit_invoice_model" in s or "predict_net_line_cost" in s:
        return "api_missing"
    if "wrong_shape" in s or "shape" in s:
        return "wrong_shape"
    if "nonfinite" in s or "nan" in s or "inf" in s:
        return "nonfinite_prediction"
    if "input_mutation" in s or "modified" in s:
        return "input_mutation"
    if "nondeterministic" in s:
        return "nondeterministic_prediction"
    if "timeout" in s or "timed out" in s:
        return "timeout"
    if "importerror" in s or "modulenotfounderror" in s:
        return "import_error"
    if "runtime_error" in s or "traceback" in s:
        return "runtime_error"
    return "unknown"


def main(argv: list[str]) -> int:
    if len(argv) != 3:
        print("usage: categorize_failure.py STDERR_TXT OUT_TXT", file=sys.stderr)
        return 2
    text = Path(argv[1]).read_text(errors="replace") if Path(argv[1]).exists() else ""
    Path(argv[2]).write_text(categorize(text) + "\n")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
