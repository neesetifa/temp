from __future__ import annotations

from generator import make_hidden


def test_hidden_slice_counts_are_not_tiny():
    hidden = make_hidden()
    counts = {name: int((hidden.slice_name == name).sum()) for name in sorted(set(hidden.slice_name.tolist()))}
    # Informational guard against accidental regeneration that creates noisy
    # high-weight slices.
    assert min(counts.values()) >= 100, counts
