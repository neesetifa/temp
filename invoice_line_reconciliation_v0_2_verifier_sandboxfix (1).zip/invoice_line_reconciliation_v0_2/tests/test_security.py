from __future__ import annotations

from pathlib import Path
import textwrap

from hidden_eval import evaluate


def test_evaluate_does_not_run_candidate_in_verifier_process(tmp_path):
    """Regression guard for the old same-process reward hack.

    If hidden_eval.evaluate() imports the candidate and calls predict in the
    verifier process, this solve can walk Python stack frames, find the local
    hidden dataset object, and return hidden.y for a perfect score. With the
    sandbox boundary, the candidate process only sees plain arrays and this
    probe falls back to zeros.
    """
    probe_dir = Path("/sandbox/io") if Path("/sandbox/io").exists() else tmp_path
    try:
        probe_dir.mkdir(parents=True, exist_ok=True)
        probe_dir.chmod(0o777)
    except Exception:
        pass
    try:
        tmp_path.chmod(0o755)
    except Exception:
        pass
    cheat = probe_dir / "solve_stack_probe.py"
    cheat.write_text(textwrap.dedent(
        r'''
        import inspect
        import numpy as np

        def fit_invoice_model(train_line_X, train_line_code, train_invoice_X,
                              train_invoice_code, train_invoice_offsets, train_y):
            return {"mean": float(np.mean(train_y))}

        def predict_net_line_cost(line_X, line_code, invoice_X, invoice_code,
                                  invoice_offsets, params):
            for frame_info in inspect.stack():
                hidden = frame_info.frame.f_locals.get("hidden")
                if hidden is not None and hasattr(hidden, "y"):
                    return np.asarray(hidden.y, dtype=float).copy()
            return np.zeros(line_X.shape[0], dtype=float)
        '''
    ))
    cheat.chmod(0o644)
    reward, metrics = evaluate(cheat, tmp_path / "logs")
    assert metrics.get("error") not in {"api_missing", "runtime_error"}, (
        "stack-probe solve did not actually execute; "
        f"reward={reward:.6f}, metrics={metrics}"
    )
    assert reward < 0.90, (
        "candidate appears to have run inside the verifier process; "
        f"stack-probe reward={reward:.6f}, metrics={metrics}"
    )
