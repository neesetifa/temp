"""Root-side sandbox helper for invoice_line_reconciliation.

When running in the platform verifier container as root, this helper executes the
candidate fit/predict path inside one unprivileged subprocess. Only plain .npz
arrays cross the boundary. The candidate never imports verifier code and cannot
read /tests after test.sh locks it down.

Local author fallback: when the platform sandbox is unavailable, run through the
same agent_call protocol in-process/subprocess without privilege dropping.
"""
from __future__ import annotations

import ctypes
import os
from pathlib import Path
import shutil
import subprocess
import sys

import numpy as np

RUNNER = "/sandbox/agent_call.py"
IO_DIR = "/sandbox/io"
_counter = [0]
REQUIRED = ("fit_invoice_model", "predict_net_line_cost")


def _sandbox_ready() -> bool:
    return os.path.exists(RUNNER) and getattr(os, "geteuid", lambda: 1000)() == 0


def _local_runner() -> str:
    return str(Path(__file__).resolve().parent / "agent_call.py")


def _demote():  # pragma: no cover - runs in child before exec
    try:
        # PR_SET_NO_NEW_PRIVS = 38. Prevent later privilege regain through exec.
        ctypes.CDLL("libc.so.6", use_errno=True).prctl(38, 1, 0, 0, 0)
    except Exception:
        pass
    try:
        import pwd
        p = pwd.getpwnam("nobody")
        try:
            os.setgroups([])
        except Exception:
            pass
        os.setgid(p.pw_gid)
        os.setuid(p.pw_uid)
    except Exception:
        # If nobody is unavailable, subprocess still runs isolated from verifier
        # state by protocol; platform containers normally have this account.
        pass



def _nobody_command(args: list[str]) -> tuple[list[str], object | None]:
    """Return a command that runs as nobody without preexec when possible."""
    if shutil.which("runuser"):
        return ["runuser", "-u", "nobody", "--", *args], None
    if shutil.which("su"):
        # Fallback for minimal images with su but no runuser.
        quoted = " ".join(subprocess.list2cmdline([a]) for a in args)
        return ["su", "-s", "/bin/sh", "nobody", "-c", quoted], None
    return args, _demote

def _payload_to_npz(path: str | os.PathLike, payload: dict) -> None:
    np.savez(
        path,
        train_line_X=np.asarray(payload["train_line_X"], dtype=np.float64),
        train_line_code=np.asarray(payload["train_line_code"], dtype=np.int64),
        train_invoice_X=np.asarray(payload["train_invoice_X"], dtype=np.float64),
        train_invoice_code=np.asarray(payload["train_invoice_code"], dtype=np.int64),
        train_invoice_offsets=np.asarray(payload["train_invoice_offsets"], dtype=np.int64),
        train_y=np.asarray(payload["train_y"], dtype=np.float64),
        line_X=np.asarray(payload["line_X"], dtype=np.float64),
        line_code=np.asarray(payload["line_code"], dtype=np.int64),
        invoice_X=np.asarray(payload["invoice_X"], dtype=np.float64),
        invoice_code=np.asarray(payload["invoice_code"], dtype=np.int64),
        invoice_offsets=np.asarray(payload["invoice_offsets"], dtype=np.int64),
    )


def _read_output(out_path: str | os.PathLike) -> dict:
    with np.load(out_path, allow_pickle=False) as z:
        if "error" in z.files:
            return {"error": str(z["error"].item()), "detail": str(z.get("detail", ""))}
        n = int(z["n"])
        return {"preds": [np.asarray(z[f"p{i}"], dtype=np.float64) for i in range(n)]}


def run_eval(solve_path: str | os.PathLike, payload: dict, timeout: int = 180) -> dict:
    """Run candidate fit + predict and return {"preds": [array]} or {"error": ...}."""
    if not _sandbox_ready():
        # Author/local path. Use the same .npz protocol but avoid absolute /sandbox.
        import tempfile
        runner = _local_runner()
        with tempfile.TemporaryDirectory() as td:
            in_path = os.path.join(td, "in_eval.npz")
            out_path = os.path.join(td, "out_eval.npz")
            _payload_to_npz(in_path, payload)
            r = subprocess.run(
                [sys.executable, runner, str(solve_path), "eval", in_path, out_path],
                capture_output=True,
                text=True,
                timeout=timeout,
            )
            if r.returncode != 0 or not os.path.exists(out_path):
                raise RuntimeError(f"local eval failed (rc={r.returncode}): {r.stderr[-800:]}")
            return _read_output(out_path)

    Path(IO_DIR).mkdir(parents=True, exist_ok=True)
    try:
        os.chmod(IO_DIR, 0o777)
    except Exception:
        pass
    _counter[0] += 1
    in_path = os.path.join(IO_DIR, f"in_eval_{_counter[0]}.npz")
    out_path = os.path.join(IO_DIR, f"out_eval_{_counter[0]}.npz")
    _payload_to_npz(in_path, payload)
    os.chmod(in_path, 0o644)
    if os.path.exists(out_path):
        os.remove(out_path)
    cmd, preexec = _nobody_command([sys.executable, RUNNER, str(solve_path), "eval", in_path, out_path])
    r = subprocess.run(
        cmd,
        preexec_fn=preexec,
        capture_output=True,
        text=True,
        timeout=timeout,
        cwd="/sandbox",
    )
    if r.returncode != 0 or not os.path.exists(out_path):
        raise RuntimeError(f"sandboxed eval failed (rc={r.returncode}): {r.stderr[-800:]}")
    return _read_output(out_path)


def check_solution(solve_path: str | os.PathLike, timeout: int = 30) -> bool:
    runner = RUNNER if _sandbox_ready() else _local_runner()
    try:
        if _sandbox_ready():
            cmd, preexec = _nobody_command([sys.executable, runner, str(solve_path), "check"])
        else:
            cmd, preexec = [sys.executable, runner, str(solve_path), "check"], None
        r = subprocess.run(
            cmd,
            preexec_fn=preexec,
            capture_output=True,
            text=True,
            timeout=timeout,
            cwd="/sandbox" if _sandbox_ready() else None,
        )
        return r.returncode == 0
    except Exception:
        return False
