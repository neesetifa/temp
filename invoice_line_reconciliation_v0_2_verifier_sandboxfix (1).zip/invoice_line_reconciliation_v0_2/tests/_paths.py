from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def app_solve_path() -> Path:
    p = Path("/app/solve.py")
    if p.exists():
        return p
    return ROOT / "environment" / "app" / "solve.py"


def app_data_path(name: str) -> Path:
    p = Path("/app") / name
    if p.exists():
        return p
    return ROOT / "environment" / "app" / name


def reference_path() -> Path:
    p = Path("/solution/reference_solution.py")
    if p.exists():
        return p
    return ROOT / "solution" / "reference_solution.py"


def verifier_log_dir() -> Path:
    p = Path("/logs/verifier")
    if p.exists() or Path("/logs").exists():
        p.mkdir(parents=True, exist_ok=True)
        return p
    p = ROOT / "logs" / "verifier"
    p.mkdir(parents=True, exist_ok=True)
    return p
