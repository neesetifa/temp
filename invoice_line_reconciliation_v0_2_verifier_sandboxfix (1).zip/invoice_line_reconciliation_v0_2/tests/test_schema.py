from __future__ import annotations

import numpy as np

from _paths import app_data_path
from generator import N_INVOICE_CODE, N_INVOICE_X, N_LINE_CODE, N_LINE_X, make_hidden, make_train_public


def _check_dataset(d, *, has_y: bool, has_slices: bool = False):
    assert d["line_X"].ndim == 2 and d["line_X"].shape[1] == N_LINE_X
    assert d["line_code"].ndim == 2 and d["line_code"].shape[1] == N_LINE_CODE
    assert d["invoice_X"].ndim == 2 and d["invoice_X"].shape[1] == N_INVOICE_X
    assert d["invoice_code"].ndim == 2 and d["invoice_code"].shape[1] == N_INVOICE_CODE
    assert d["invoice_offsets"].ndim == 1
    assert d["invoice_offsets"][0] == 0
    assert d["invoice_offsets"][-1] == d["line_X"].shape[0]
    assert np.all(np.diff(d["invoice_offsets"]) > 0)
    assert d["line_code"].shape[0] == d["line_X"].shape[0]
    assert d["invoice_code"].shape[0] == d["invoice_X"].shape[0]
    assert d["invoice_offsets"].shape[0] == d["invoice_X"].shape[0] + 1
    assert np.all(np.isfinite(d["line_X"]))
    assert np.all(np.isfinite(d["invoice_X"]))
    if has_y:
        assert "y" in d
        assert d["y"].shape == (d["line_X"].shape[0],)
        assert np.all(np.isfinite(d["y"]))
    if has_slices:
        assert "slice_name" in d
        assert d["slice_name"].shape == (d["line_X"].shape[0],)


def test_agent_visible_schema():
    for name in ("train_data.npz", "public_eval.npz"):
        with np.load(app_data_path(name), allow_pickle=False) as z:
            _check_dataset(z, has_y=True)


def test_verifier_generated_schema():
    train, public = make_train_public()
    hidden = make_hidden()
    _check_dataset(train.as_npz_dict(include_y=True), has_y=True)
    _check_dataset(public.as_npz_dict(include_y=True), has_y=True)
    _check_dataset(hidden.as_npz_dict(include_y=True, include_slices=True), has_y=True, has_slices=True)


def test_train_public_hidden_are_distinct_sizes():
    train, public = make_train_public()
    hidden = make_hidden()
    assert train.line_X.shape[0] > public.line_X.shape[0] > 0
    assert hidden.line_X.shape[0] > public.line_X.shape[0] > 0
