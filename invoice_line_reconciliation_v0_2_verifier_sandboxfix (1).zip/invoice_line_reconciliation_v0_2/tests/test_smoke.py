from __future__ import annotations

import numpy as np

from _paths import app_data_path, app_solve_path
from sandbox_utils import check_solution


def test_candidate_file_exists():
    assert app_solve_path().exists(), "solve.py not found"


def test_required_functions_present():
    assert check_solution(app_solve_path()), "required fit_invoice_model / predict_net_line_cost functions not found"


def test_visible_data_loadable():
    for name in ("train_data.npz", "public_eval.npz"):
        path = app_data_path(name)
        assert path.exists(), f"{name} not found"
        with np.load(path, allow_pickle=False) as z:
            assert "line_X" in z.files and "invoice_offsets" in z.files, f"{name} missing core arrays"
