from __future__ import annotations
from pathlib import Path
import sys
import numpy as np
from sklearn.ensemble import HistGradientBoostingRegressor, ExtraTreesRegressor
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
from sklearn.linear_model import Ridge
from dataclasses import replace

ROOT = Path(__file__).resolve().parents[1]
import importlib.util

def _load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, str(path))
    mod = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod

generator_mod = _load_module('generator_mod', ROOT / 'tests' / 'generator.py')
sys.modules['generator'] = generator_mod
hidden_eval_mod = _load_module('hidden_eval_mod', ROOT / 'tests' / 'hidden_eval.py')
ref = _load_module('reference_solution_mod', ROOT / 'solution' / 'reference_solution.py')
make_train_public = generator_mod.make_train_public
make_hidden = generator_mod.make_hidden
GeneratedData = generator_mod.GeneratedData
sys.path.append(str(Path(__file__).resolve().parent))
from hand_replay import hand_pred
signed_log = hidden_eval_mod.signed_log
score_rmse = hidden_eval_mod.score_rmse
OVERALL_GOOD = hidden_eval_mod.OVERALL_GOOD
OVERALL_BAD = hidden_eval_mod.OVERALL_BAD
SLICE_GOOD = hidden_eval_mod.SLICE_GOOD
SLICE_BAD = hidden_eval_mod.SLICE_BAD
SLICE_WEIGHTS = hidden_eval_mod.SLICE_WEIGHTS
OVERALL_WEIGHT = hidden_eval_mod.OVERALL_WEIGHT


def inv_signed_log(z):
    z = np.asarray(z, dtype=float)
    return np.sign(z) * np.expm1(np.abs(z))


def basic_score(pred, hidden):
    err = signed_log(pred) - signed_log(hidden.y)
    overall_rmse = float(np.sqrt(np.mean(err**2)))
    overall_score = score_rmse(overall_rmse, OVERALL_GOOD, OVERALL_BAD)
    reward = OVERALL_WEIGHT * overall_score
    slices = {}
    for name, wt in SLICE_WEIGHTS.items():
        m = hidden.slice_name == name
        if np.any(m):
            rmse = float(np.sqrt(np.mean(err[m]**2)))
            sc = score_rmse(rmse, SLICE_GOOD.get(name, OVERALL_GOOD), SLICE_BAD.get(name, OVERALL_BAD))
            slices[name] = (int(m.sum()), rmse, sc)
            reward += wt * sc
    return float(np.clip(reward,0,1)), overall_rmse, slices


def invoice_ids(offsets):
    return np.searchsorted(offsets[1:], np.arange(offsets[-1]), side='right')




def concat_labeled(a, b):
    return GeneratedData(
        line_X=np.vstack([a.line_X, b.line_X]),
        line_code=np.vstack([a.line_code, b.line_code]),
        invoice_X=np.vstack([a.invoice_X, b.invoice_X]),
        invoice_code=np.vstack([a.invoice_code, b.invoice_code]),
        invoice_offsets=np.concatenate([a.invoice_offsets, b.invoice_offsets[1:] + a.invoice_offsets[-1]]),
        y=np.concatenate([a.y, b.y]),
        slice_name=None,
    )

def row_features(line_X, line_code):
    return np.hstack([signed_log(line_X), line_code.astype(float), np.log1p(np.abs(line_X))])


def aggregate_features(line_X, line_code, invoice_X, invoice_code, offsets):
    ids = invoice_ids(offsets)
    n = line_X.shape[0]
    rep_inv = invoice_X[ids]
    rep_code = invoice_code[ids].astype(float)
    raw = line_X[:,2]
    raw_pos = np.maximum(raw,0)
    agg = np.zeros((n, 24), dtype=float)
    for ii in range(len(offsets)-1):
        s,e = offsets[ii], offsets[ii+1]
        idx=slice(s,e); m=e-s
        rr=raw[idx]; rp=raw_pos[idx]
        subtotal=max(rp.sum(),1e-9)
        ch=line_code[idx,3]; fam=line_code[idx,0]
        wt=np.maximum(line_X[idx,7],0); pkg=np.maximum(line_X[idx,5],0)
        agg[idx,0]=m
        agg[idx,1]=signed_log(invoice_X[ii,2])
        agg[idx,2]=np.log1p(abs(invoice_X[ii,3])); agg[idx,3]=np.log1p(abs(invoice_X[ii,4])); agg[idx,4]=np.log1p(abs(invoice_X[ii,5]))
        agg[idx,5]=rp/subtotal
        agg[idx,6]=wt/max(wt.sum(),1e-9)
        agg[idx,7]=pkg/max(pkg.sum(),1e-9)
        agg[idx,8]=np.mean(rr<0); agg[idx,9]=np.mean(np.isin(ch,[1,2,3])); agg[idx,10]=np.mean(line_code[idx,8]>0)
        for c in range(7):
            mask=ch==c
            agg[idx,11+c]=mask.sum()/max(m,1)
        # family amount/cnt by current row's family
        for f in np.unique(fam):
            mask=fam==f
            agg[s+np.where(mask)[0],18]=rp[mask].sum()/subtotal
            agg[s+np.where(mask)[0],19]=mask.sum()/max(m,1)
        rounded=np.round(np.abs(rr)/5.0)
        agg[idx,20]=[np.sum(rounded==r) for r in rounded]
        agg[idx,21]=np.argsort(np.argsort(rr))/max(1,m-1)
        agg[idx,22]=invoice_X[ii,6]
        agg[idx,23]=invoice_X[ii,7]
    return np.hstack([row_features(line_X,line_code), rep_inv, rep_code, agg])


def fit_predict_model(kind):
    train,_ = make_train_public(); hidden=make_hidden()
    if kind == 'constant_train_mean':
        pred=np.full_like(hidden.y, np.mean(train.y), dtype=float)
    elif kind == 'raw_amount_formula':
        pred=hidden.line_X[:,2] - hidden.line_X[:,3] + hidden.line_X[:,4]
    elif kind == 'proportional_allocation':
        pred=hidden.line_X[:,2] - hidden.line_X[:,3] + hidden.line_X[:,4]
        for ii in range(len(hidden.invoice_offsets)-1):
            s,e=hidden.invoice_offsets[ii], hidden.invoice_offsets[ii+1]
            raw_pos=np.maximum(hidden.line_X[s:e,2],0)
            share=raw_pos/max(raw_pos.sum(),1e-9)
            adj=hidden.invoice_X[ii,4]+hidden.invoice_X[ii,5]-hidden.invoice_X[ii,3]
            pred[s:e]+=adj*share
    elif kind == 'row_only_hgb':
        X=row_features(train.line_X, train.line_code); Xt=row_features(hidden.line_X, hidden.line_code)
        m=HistGradientBoostingRegressor(max_iter=180, learning_rate=0.06, max_leaf_nodes=31, random_state=1, min_samples_leaf=20)
        m.fit(X, signed_log(train.y)); pred=inv_signed_log(m.predict(Xt))
    elif kind == 'invoice_aggregate_hgb':
        X=aggregate_features(train.line_X,train.line_code,train.invoice_X,train.invoice_code,train.invoice_offsets)
        Xt=aggregate_features(hidden.line_X,hidden.line_code,hidden.invoice_X,hidden.invoice_code,hidden.invoice_offsets)
        m=HistGradientBoostingRegressor(max_iter=220, learning_rate=0.055, max_leaf_nodes=31, random_state=2, min_samples_leaf=18)
        m.fit(X, signed_log(train.y)); pred=inv_signed_log(m.predict(Xt))
    elif kind == 'context_explosion_extra_trees':
        X=aggregate_features(train.line_X,train.line_code,train.invoice_X,train.invoice_code,train.invoice_offsets)
        Xt=aggregate_features(hidden.line_X,hidden.line_code,hidden.invoice_X,hidden.invoice_code,hidden.invoice_offsets)
        # Kept as a context-explosion replay, but uses HGB to avoid slow/sticky
        # tree-worker shutdowns in repeated calibration runs.
        m=HistGradientBoostingRegressor(max_iter=260, learning_rate=0.045, max_leaf_nodes=39, random_state=3, min_samples_leaf=14)
        m.fit(X, signed_log(train.y)); pred=inv_signed_log(m.predict(Xt))
    elif kind == 'allocation_feature_hgb':
        X,_enc = ref._build_features(train.line_X,train.line_code,train.invoice_X,train.invoice_code,train.invoice_offsets,fit=True,y_log=signed_log(train.y))
        Xt = ref._build_features(hidden.line_X,hidden.line_code,hidden.invoice_X,hidden.invoice_code,hidden.invoice_offsets,encoders=_enc,fit=False)
        m=HistGradientBoostingRegressor(max_iter=190, learning_rate=0.052, max_leaf_nodes=23, l2_regularization=0.05, random_state=4, min_samples_leaf=24)
        m.fit(X, signed_log(train.y)); pred=inv_signed_log(m.predict(Xt))

    elif kind == 'allocation_feature_ensemble':
        X,_enc = ref._build_features(train.line_X,train.line_code,train.invoice_X,train.invoice_code,train.invoice_offsets,fit=True,y_log=signed_log(train.y))
        Xt = ref._build_features(hidden.line_X,hidden.line_code,hidden.invoice_X,hidden.invoice_code,hidden.invoice_offsets,encoders=_enc,fit=False)
        ylog = signed_log(train.y)
        models = [
            HistGradientBoostingRegressor(max_iter=260, learning_rate=0.045, max_leaf_nodes=31, l2_regularization=0.03, random_state=41, min_samples_leaf=18),
            HistGradientBoostingRegressor(max_iter=320, learning_rate=0.035, max_leaf_nodes=19, l2_regularization=0.08, random_state=42, min_samples_leaf=12),
            HistGradientBoostingRegressor(max_iter=180, learning_rate=0.060, max_leaf_nodes=43, l2_regularization=0.02, random_state=43, min_samples_leaf=26),
            make_pipeline(StandardScaler(), Ridge(alpha=3.0)),
        ]
        preds=[]
        for m in models:
            m.fit(X, ylog)
            preds.append(m.predict(Xt))
        weights=np.array([0.34,0.27,0.23,0.16])
        pred=inv_signed_log(np.average(np.vstack(preds), axis=0, weights=weights))
    elif kind == 'mechanism_reconstruction_replay':
        pred = hand_pred(hidden.line_X, hidden.line_code, hidden.invoice_X, hidden.invoice_code, hidden.invoice_offsets)

    elif kind == 'mechanism_reconstruction_residual':
        # Strongest replay: a hand-built old allocation parser plus residual learning on
        # the full labeled visible fixture (train + public labels are shipped).
        tr = concat_labeled(train, _)
        base_train = hand_pred(tr.line_X, tr.line_code, tr.invoice_X, tr.invoice_code, tr.invoice_offsets)
        base_hidden = hand_pred(hidden.line_X, hidden.line_code, hidden.invoice_X, hidden.invoice_code, hidden.invoice_offsets)
        ylog = signed_log(tr.y)
        residual = ylog - signed_log(base_train)
        X, enc = ref._build_features(tr.line_X, tr.line_code, tr.invoice_X, tr.invoice_code, tr.invoice_offsets, fit=True, y_log=ylog)
        Xt = ref._build_features(hidden.line_X, hidden.line_code, hidden.invoice_X, hidden.invoice_code, hidden.invoice_offsets, encoders=enc, fit=False)
        models = [
            HistGradientBoostingRegressor(max_iter=360, learning_rate=0.035, max_leaf_nodes=31, l2_regularization=0.03, random_state=61, min_samples_leaf=12),
            HistGradientBoostingRegressor(max_iter=420, learning_rate=0.028, max_leaf_nodes=19, l2_regularization=0.06, random_state=62, min_samples_leaf=10),
            make_pipeline(StandardScaler(), Ridge(alpha=8.0)),
        ]
        preds=[]
        for m in models:
            m.fit(X, residual)
            preds.append(m.predict(Xt))
        resid = 0.52 * preds[0] + 0.30 * preds[1] + 0.18 * preds[2]
        pred = inv_signed_log(signed_log(base_hidden) + resid)

    elif kind == 'vendor_item_te_hgb':
        X=aggregate_features(train.line_X,train.line_code,train.invoice_X,train.invoice_code,train.invoice_offsets)
        Xt=aggregate_features(hidden.line_X,hidden.line_code,hidden.invoice_X,hidden.invoice_code,hidden.invoice_offsets)
        # intentionally less structural; uses numeric ids and HGB.
        m=HistGradientBoostingRegressor(max_iter=160, learning_rate=0.06, max_leaf_nodes=19, random_state=5, min_samples_leaf=20)
        m.fit(X[:, :45], signed_log(train.y)); pred=inv_signed_log(m.predict(Xt[:, :45]))
    elif kind == 'reference_solution':
        params=ref.fit_invoice_model(train.line_X,train.line_code,train.invoice_X,train.invoice_code,train.invoice_offsets,train.y)
        pred=ref.predict_net_line_cost(hidden.line_X,hidden.line_code,hidden.invoice_X,hidden.invoice_code,hidden.invoice_offsets,params)
    else:
        raise ValueError(kind)
    return basic_score(pred, hidden)


BASELINES = [
    'constant_train_mean',
    'raw_amount_formula',
    'proportional_allocation',
    'row_only_hgb',
    'vendor_item_te_hgb',
    'invoice_aggregate_hgb',
    'context_explosion_extra_trees',
    'allocation_feature_hgb',
    'allocation_feature_ensemble',
    'mechanism_reconstruction_replay',
    'mechanism_reconstruction_residual',
    'reference_solution',
]
