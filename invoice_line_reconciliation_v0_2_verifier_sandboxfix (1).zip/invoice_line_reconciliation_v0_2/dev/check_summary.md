# v0.2 local check summary

Generated after the v0.2 mechanism-hardening patch.

## Delta from v0.1a

- Added a hand-built `mechanism_reconstruction_replay` baseline after v0.1a showed a copied allocation parser could nearly match the reference.
- Added `mechanism_reconstruction_residual`, a stronger replay that combines that old parser with residual learning on visible train + public labels.
- Hardened the target with visible but more nonlinear audit adjustments based on line history, lead time, recent price index, seasonality, subfamily, vendor-line type, and header-allocation interactions.
- Regenerated `environment/app/train_data.npz` and `environment/app/public_eval.npz` from the patched generator.
- Retuned evaluator anchors around the updated reference.
- Did not change the public API, agent-facing instruction, package layout, or public tests.

## Public tests

`pytest -q environment/tests` from `environment/`: 4 passed.

## Hidden-style evaluation

- starter `environment/app/solve.py`: reward 0.105, signed-log RMSE 0.7656
- `solution/reference_solution.py`: reward 1.000, signed-log RMSE 0.3038

## Calibration ladder

See `dev/calibration_results.json` for full slice metrics.

| model | reward | signed-log RMSE |
|---|---:|---:|
| constant_train_mean | 0.000 | 2.7889 |
| raw_amount_formula | 0.043 | 0.8207 |
| proportional_allocation | 0.064 | 0.8007 |
| row_only_hgb | 0.279 | 0.6588 |
| vendor_item_te_hgb | 0.532 | 0.5215 |
| invoice_aggregate_hgb | 0.570 | 0.5031 |
| context_explosion_extra_trees | 0.591 | 0.4914 |
| allocation_feature_hgb | 0.596 | 0.4886 |
| allocation_feature_ensemble | 0.616 | 0.4799 |
| mechanism_reconstruction_replay | 0.350 | 0.6067 |
| mechanism_reconstruction_residual | 0.779 | 0.4042 |
| reference_solution | 1.000 | 0.3038 |

## Data shape / realism smoke stats

- train: 850 invoices, 7,018 lines, median 4 lines/invoice, p95 30, max 75, 173 vendors, 24 item families
- public: 160 invoices, 1,192 lines, median 4 lines/invoice, p95 29, max 58, 58 vendors, 24 item families
- hidden: 380 invoices, 3,189 lines, median 5 lines/invoice, p95 30, max 61, 123 vendors, 24 item families

Hidden diagnostic row counts:

- regular: 981
- discount: 372
- matched_mix: 290
- rare_vendor: 263
- shipping: 254
- minimum: 254
- unit_shift: 227
- reversal: 219
- rare_exception: 219
- service_absorb: 110

## Current interpretation

v0.2 fixes the immediate v0.1a failure mode: the direct old allocation parser falls to 0.350, and the stronger parser-plus-residual replay reaches 0.779 instead of near-oracle. Generic feature/ensemble baselines remain around 0.53-0.62. This is a healthier prototype but still needs a true frontier probe before submission, because a stronger reconstruction of the v0.2 nonlinear audit adjustment could exceed the current replay.

## v0.2 verifier sandbox fix

Reviewer/security issue: the main scoring path must not import and execute the
agent solution in the verifier process. `hidden_eval.evaluate()` now builds a
plain-array payload and calls `sandbox_utils.run_eval(...)`; the candidate runs
inside `agent_call.py` in a separate subprocess, and on the platform path under
`nobody`. Only prediction arrays cross back through `.npz` with
`allow_pickle=False`.

Added `tests/test_security.py` as a regression guard. It creates a stack-walking
candidate that would return `hidden.y` if it were executed inside the verifier
process. Under the sandbox path it executes but scores 0 rather than 1.

Smoke/schema/reference/baseline/main/holdout tests were checked individually.
The simulated platform scoring path writes continuous reward through
`hidden_eval.evaluate(..., write_dir=/logs/verifier)` rather than overwriting it
with a binary success marker.
