# Probe results — invoice_line_reconciliation v0.2
Probe: `mechanism_reconstruction_residual`

This probe uses a hand-reconstructed allocation parser plus residual learning on all visible labeled data (`train_data.npz` + `public_eval.npz`). It is intended to imitate a strong agent that recovers the apparent invoice-allocation structure and then learns residual nonlinear adjustments.

- reward: 0.778613
- signed-log RMSE: 0.404155

| slice | n | rmse | score |
|---|---:|---:|---:|
| discount | 372 | 0.588136 | 0.317700 |
| matched_mix | 290 | 0.358403 | 0.762911 |
| minimum | 254 | 0.276824 | 0.875309 |
| rare_exception | 219 | 0.378285 | 0.684075 |
| rare_vendor | 263 | 0.402599 | 0.615465 |
| regular | 981 | 0.427011 | 0.759799 |
| reversal | 219 | 0.398283 | 0.825663 |
| service_absorb | 110 | 0.254728 | 0.893792 |
| shipping | 254 | 0.258474 | 1.000000 |
| unit_shift | 227 | 0.323909 | 0.801065 |

Interpretation: the probe does not show near-oracle saturation. The main gap is on `discount`; `shipping` is saturated by this probe, but it is only a 4% slice and does not dominate reward. Recommendation: hold v0.2 for a real external/frontier probe if available; do not redesign solely based on this local result.
