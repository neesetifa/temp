from pathlib import Path
import sys
sys.path.append(str(Path(__file__).resolve().parents[1] / 'tests'))
from generator import *  # noqa: F401,F403
