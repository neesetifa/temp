from __future__ import annotations
import json
import sys
from baselines import fit_predict_model

name = sys.argv[1]
reward, rmse, slices = fit_predict_model(name)
result = {
    'reward': reward,
    'overall_rmse': rmse,
    'slices': {k: {'n': v[0], 'rmse': v[1], 'score': v[2]} for k, v in slices.items()},
}
print(json.dumps(result, sort_keys=True))
