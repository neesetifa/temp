# invoice_line_reconciliation v0.2 notes

Status: prototype, not submitted.

Capability: row-level prediction under packed invoice context, where final audited line cost depends on line features, invoice-level adjustments, same-invoice mix, supplier/contract shrinkage, ambiguous credit/reversal lines, and visible nonlinear audit adjustments.

## Delta from v0.1a

- v0.1a was not healthy after a hand-built mechanism reconstruction replay nearly matched the reference.
- v0.2 adds that reconstruction as an explicit exploit baseline.
- The target now includes nonlinear visible audit adjustments from line history, lead time, recent price index, seasonality, subfamily, vendor-line type, and header-allocation interactions.
- The public API and instruction remain unchanged.
- Train/public fixtures and evaluator anchors were regenerated/retuned.

## Wrong / exploit solutions currently tracked

- raw line formula
- proportional invoice reconciliation
- row-only gradient boosting
- invoice aggregate gradient boosting
- vendor/item target encoding
- context explosion model
- allocation-feature HGB
- allocation-feature multi-estimator ensemble
- old mechanism reconstruction replay
- old mechanism reconstruction plus residual learning on train + public labels

## Current calibration interpretation

- Reference: 1.000 reward, signed-log RMSE 0.3038.
- Strong generic allocation ensemble: 0.616 reward.
- Old mechanism reconstruction direct: 0.350 reward.
- Old mechanism reconstruction + residual learning: 0.779 reward.

The strongest replay is now below 0.80, which is the intended effect of v0.2 hardening. This version is still not submission-ready without a frontier probe, because the v0.2 adjustment itself might be reconstructed by a stronger agent.

## Remaining risks

- The reference still uses strong structural knowledge; reviewer sensitivity to oracle-like reference style should be considered.
- `service_absorb` remains the smallest hidden slice at 110 rows, though its reward weight is only 3%.
- The nonlinear audit adjustment must not become an unfair hidden formula; agent-visible data should show enough evidence through the included line/history/season/vendor-line features.
- Calibration script defaults to printing the checked snapshot. Individual rows can be recomputed with `python dev/run_one_baseline.py <baseline_name>`.


## v0.2 verifier-sandbox patch

- Added tests/sandbox_utils.py and tests/agent_call.py so hidden evaluation runs fit+predict in one unprivileged subprocess when the platform sandbox is available.
- Added verifier test harness files: test.sh, test_smoke.py, test_schema.py, test_reference.py, test_baseline.py, test_main.py, test_holdout.py, categorize_failure.py.
- Moved probe code out of environment/app into dev/probe_strong_context_ensemble.py; agent-visible app now only has solve.py and data files.
- Main continuous reward is written by hidden_eval/test_main rather than overwritten by test.sh.
