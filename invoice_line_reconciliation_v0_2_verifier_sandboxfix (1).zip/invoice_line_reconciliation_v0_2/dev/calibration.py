from __future__ import annotations
import json
from pathlib import Path

# The full replay ladder is relatively expensive, and some sklearn tree-worker
# shutdown paths are sticky in repeated subprocess runs on small sandboxes.
# This script reports the checked calibration snapshot. To recompute one row,
# run: python dev/run_one_baseline.py <baseline_name>

RESULTS = Path(__file__).with_name('calibration_results.json')
if __name__ == '__main__':
    out = json.loads(RESULTS.read_text())
    for name, result in out.items():
        print(f"{name:36s} reward={result['reward']:.3f} rmse={result['overall_rmse']:.4f}")
