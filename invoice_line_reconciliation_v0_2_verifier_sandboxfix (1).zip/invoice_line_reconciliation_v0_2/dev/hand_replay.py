from __future__ import annotations
import numpy as np

def softmax(z):
    z=np.asarray(z,float); z=z-np.max(z); e=np.exp(z); return e/e.sum()
def fam_attrs(family):
    # deliberately simple: inferable category pattern, not exact trig margin
    family=int(family)
    margin=1.0
    bulk=1.0 if (family % 7) in (0,3,5) else 0.55
    service_affinity=0.9 if (family % 11) in (1,6) else 0.25
    volatility=0.04
    return margin,bulk,service_affinity,volatility
def hand_pred(line_X,line_code,invoice_X,invoice_code,invoice_offsets):
    out=np.zeros(line_X.shape[0])
    for ii in range(len(invoice_offsets)-1):
        s,e=int(invoice_offsets[ii]),int(invoice_offsets[ii+1]); idx=slice(s,e); n=e-s
        vendor=int(invoice_code[ii,0]); channel=int(invoice_code[ii,1]); region=int(invoice_code[ii,2])
        # vendor styles approximated by observable volume tier/channel, not exact vendor sine
        volume=float(invoice_X[ii,1])
        disc_style=0.35+0.08*volume+0.08*(channel==1)
        ship_style=0.35+0.08*volume+0.07*(channel==3)
        min_style=0.45+0.05*(volume<2)
        vendor_bias=0.0 # don't know exact
        contract_tier=int(np.bincount(line_code[idx,5].astype(int), minlength=5).argmax())
        raw=line_X[idx,2]; raw_pos=np.maximum(raw,0); positive_subtotal=float(raw_pos.sum())
        hd=invoice_X[ii,3]; hs=invoice_X[ii,4]; handling=invoice_X[ii,5]
        min_flag=int(invoice_X[ii,6]>0.5); expedite=int(invoice_X[ii,7]>0.5)
        ch=line_code[idx,3].astype(int); fam=line_code[idx,0].astype(int); unit=line_code[idx,2].astype(int); exc=line_code[idx,8].astype(int)
        service=np.isin(ch,[1,2,3]).astype(float); eligible=(~np.isin(ch,[4,5])).astype(float)
        package=np.maximum(line_X[idx,5],0); weight=np.maximum(line_X[idx,7],0)
        amount_share=raw_pos/max(raw_pos.sum(),1e-9)
        elig_amount=raw_pos*eligible*(ch!=2)*(ch!=3); eligible_share=elig_amount/max(elig_amount.sum(),1e-9)
        package_share=package/max(package.sum(),1e-9); weight_share=weight/max(weight.sum(),1e-9)
        service_share=service/max(service.sum(),1e-9) if service.sum()>0 else amount_share
        low=(raw_pos <= np.quantile(raw_pos,.35) if n>2 else np.ones(n,bool)).astype(float)
        low_share=low*eligible/max(np.sum(low*eligible),1e-9)
        fam_bulk=np.array([fam_attrs(f)[1] for f in fam])
        bulk_mix=float(np.average(fam_bulk,weights=np.maximum(raw_pos,1.0))) if n else 0
        service_mix=float(service.mean())
        z_disc=np.array([.6+.5*disc_style+.18*contract_tier, .4+.8*(contract_tier>=2)+.3*(channel==1), -.1+.7*bulk_mix+.1*region, -.4+1.3*service_mix+.4*(service_mix>.16), -.2+.8*min_flag+.2*(n<4)])
        w_disc=softmax(z_disc)
        disc_share=w_disc[0]*amount_share+w_disc[1]*eligible_share+w_disc[2]*package_share+w_disc[3]*service_share+w_disc[4]*low_share; disc_share/=max(disc_share.sum(),1e-9)
        z_ship=np.array([.1+1.0*ship_style+.3*expedite, .3+1.5*bulk_mix+.25*region, -.2+.6*package.mean(), -.4+1.0*service_mix+.3*(channel==3)])
        w_ship=softmax(z_ship)
        ship_share=w_ship[0]*amount_share+w_ship[1]*weight_share+w_ship[2]*package_share+w_ship[3]*service_share; ship_share/=max(ship_share.sum(),1e-9)
        min_share=.58*service_share+.27*low_share+.15*package_share; min_share/=max(min_share.sum(),1e-9)
        for lj,j in enumerate(range(s,e)):
            family=int(fam[lj]); margin,bulk,service_aff,vol=fam_attrs(family); amount=float(raw[lj]); ut=int(unit[lj]); c=int(ch[lj]); ex=int(exc[lj])
            unit_shift=((family in (2,8,13,19)) and (ut in (3,4) or family%5==2))
            unit_correction=1.0+.012*ut+.018*float(unit_shift)
            # omit trig family-contract; use rough categorical effect
            family_contract=1.0+.006*contract_tier*((family%4)-1.5)+.004*channel*((family+region)%3-1)
            base=amount*unit_correction*family_contract*(1+vendor_bias)
            base-=line_X[j,3]*(.8+.1*contract_tier); base+=line_X[j,4]*(.55+.06*region)
            if c==1: base*=1.0+.05*service_aff+.02*contract_tier
            elif c==6: base*=.82+.04*ex
            elif c==2: base*=.60+.07*expedite
            elif c==3: base*=.72+.04*channel
            base-=hd*disc_share[lj] # omit small sin multiplier
            base+=hs*ship_share[lj]*(.90+.02*((region+family)%3-1))
            base+=handling*(.45*ship_share[lj]+.55*min_share[lj])*(1+.025*channel)
            if min_flag: base+=max(0.0,42+4.5*region-.025*positive_subtotal)*min_share[lj]*(.8+.3*min_style)
            if ex>=7: base+=(8+.018*abs(amount))*np.sin(.7*ex+.2*family)+4*(c==6)
            elif ex>0: base+=(2+.006*abs(amount))*np.cos(ex+channel)
            if c==4:
                base*=.75+.05*(ex>0); base-=.05*hd*eligible_share[lj]
            if c==5:
                paired_strength=.25+.50*(.35+.03*min(4,int(np.log1p(max(0,320-vendor))//1.5)))
                base*=paired_strength; base-=.02*positive_subtotal*amount_share[lj]
            out[j]=base
    return out
