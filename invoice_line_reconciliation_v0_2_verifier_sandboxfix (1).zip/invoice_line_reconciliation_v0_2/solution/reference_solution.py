from __future__ import annotations
import numpy as np
from sklearn.ensemble import HistGradientBoostingRegressor, ExtraTreesRegressor
from sklearn.linear_model import Ridge
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline

# Column indices duplicated to keep this solution self-contained.
LX_QUANTITY = 0; LX_UNIT_PRICE = 1; LX_RAW_AMOUNT = 2; LX_REPORTED_DISCOUNT = 3; LX_REPORTED_TAX = 4; LX_PACKAGE_COUNT = 5; LX_UNIT_SIZE = 6; LX_WEIGHT_PROXY = 7; LX_LEAD_TIME = 8; LX_HIST_ITEM_VOLUME = 9; LX_RECENT_PRICE_INDEX = 10; LX_LINE_POSITION_NORM = 11; LX_IS_NEGATIVE = 12; LX_IS_ROUND_AMOUNT = 13
LC_ITEM_FAMILY = 0; LC_ITEM_SUBFAMILY = 1; LC_UNIT_TYPE = 2; LC_CHARGE_TYPE = 3; LC_VENDOR_LINE_TYPE = 4; LC_CONTRACT_TIER = 5; LC_REGION_CODE = 6; LC_CURRENCY_BUCKET = 7; LC_EXCEPTION_CODE = 8
IX_INVOICE_SUBTOTAL = 2; IX_HEADER_DISCOUNT = 3; IX_HEADER_SHIPPING = 4; IX_HEADER_HANDLING_FEE = 5; IX_MINIMUM_CHARGE_FLAG = 6; IX_EXPEDITE_FLAG = 7; IX_STATED_LINE_COUNT = 8; IX_SEASON_SIN = 9; IX_SEASON_COS = 10
IC_VENDOR_CODE = 0; IC_CONTRACT_CHANNEL = 1; IC_INVOICE_REGION = 2; IC_MONTH_BUCKET = 3
N_CHARGE_TYPE = 7; N_ITEM_FAMILY = 24; N_EXCEPTION = 12


def _signed_log(x):
    x = np.asarray(x, dtype=float)
    return np.sign(x) * np.log1p(np.abs(x))


def _inv_signed_log(z):
    z = np.asarray(z, dtype=float)
    return np.sign(z) * np.expm1(np.abs(z))


def _safe_div(a, b):
    return a / np.where(np.abs(b) < 1e-9, 1.0, b)


def _target_encode(keys, y, min_count=8, shrink=18.0):
    # returns mapping dict tuple/int -> encoded signed-log target mean with shrinkage
    global_mean = float(np.mean(y))
    sums = {}
    cnts = {}
    for k, val in zip(keys, y):
        kk = tuple(k) if np.ndim(k) else int(k)
        sums[kk] = sums.get(kk, 0.0) + float(val)
        cnts[kk] = cnts.get(kk, 0) + 1
    enc = {}
    for k in sums:
        n = cnts[k]
        enc[k] = (sums[k] + shrink * global_mean) / (n + shrink)
    return enc, global_mean


def _apply_te(keys, mapping, default):
    out = np.empty(len(keys), dtype=float)
    for i, k in enumerate(keys):
        kk = tuple(k) if np.ndim(k) else int(k)
        out[i] = mapping.get(kk, default)
    return out


def _build_features(line_X, line_code, invoice_X, invoice_code, invoice_offsets, encoders=None, fit=False, y_log=None):
    n = line_X.shape[0]
    raw = line_X[:, LX_RAW_AMOUNT]
    raw_pos = np.maximum(raw, 0.0)
    abs_raw = np.abs(raw)
    base = [
        _signed_log(raw),
        np.log1p(abs_raw),
        _signed_log(line_X[:, LX_REPORTED_DISCOUNT]),
        _signed_log(line_X[:, LX_REPORTED_TAX]),
        np.log1p(line_X[:, LX_PACKAGE_COUNT]),
        np.log1p(np.maximum(line_X[:, LX_WEIGHT_PROXY], 0.0)),
        line_X[:, LX_LINE_POSITION_NORM],
        line_X[:, LX_IS_NEGATIVE],
        line_X[:, LX_IS_ROUND_AMOUNT],
        _signed_log(line_X[:, LX_QUANTITY]),
        _signed_log(line_X[:, LX_UNIT_PRICE]),
        np.log1p(np.maximum(line_X[:, LX_UNIT_SIZE], 0.0)),
        np.log1p(np.maximum(line_X[:, LX_LEAD_TIME], 0.0)),
        np.log1p(np.maximum(line_X[:, LX_HIST_ITEM_VOLUME], 0.0)),
        line_X[:, LX_RECENT_PRICE_INDEX],
        line_code[:, LC_ITEM_FAMILY].astype(float),
        line_code[:, LC_ITEM_SUBFAMILY].astype(float),
        line_code[:, LC_UNIT_TYPE].astype(float),
        line_code[:, LC_CHARGE_TYPE].astype(float),
        line_code[:, LC_VENDOR_LINE_TYPE].astype(float),
        line_code[:, LC_CONTRACT_TIER].astype(float),
        line_code[:, LC_REGION_CODE].astype(float),
        line_code[:, LC_CURRENCY_BUCKET].astype(float),
        line_code[:, LC_EXCEPTION_CODE].astype(float),
    ]
    rep_inv = np.empty((n, invoice_X.shape[1]), dtype=float)
    rep_code = np.empty((n, invoice_code.shape[1]), dtype=float)
    agg = np.zeros((n, 38), dtype=float)
    for ii in range(len(invoice_offsets)-1):
        s, e = int(invoice_offsets[ii]), int(invoice_offsets[ii+1])
        idx = slice(s, e)
        m = e - s
        rep_inv[idx] = invoice_X[ii]
        rep_code[idx] = invoice_code[ii]
        rr = raw[idx]
        rp = raw_pos[idx]
        subtotal_pos = max(float(rp.sum()), 1e-9)
        wt = np.maximum(line_X[idx, LX_WEIGHT_PROXY], 0.0)
        pkg = np.maximum(line_X[idx, LX_PACKAGE_COUNT], 0.0)
        wt_sum = max(float(wt.sum()), 1e-9)
        pkg_sum = max(float(pkg.sum()), 1e-9)
        ch = line_code[idx, LC_CHARGE_TYPE]
        fam = line_code[idx, LC_ITEM_FAMILY]
        exc = line_code[idx, LC_EXCEPTION_CODE]
        amount_share = rp / subtotal_pos
        weight_share = wt / wt_sum
        package_share = pkg / pkg_sum
        service = np.isin(ch, [1,2,3]).astype(float)
        service_share = service / max(service.sum(), 1e-9) if service.sum() else amount_share
        eligible = (~np.isin(ch, [2,3,4,5])).astype(float) * (rr > 0)
        eligible_amount = rp * eligible
        eligible_share = eligible_amount / max(float(eligible_amount.sum()), 1e-9)
        low = (rp <= np.quantile(rp, 0.35) if m > 2 else np.ones(m, dtype=bool)).astype(float) * eligible
        low_share = low / max(float(low.sum()), 1e-9)
        order = np.argsort(np.argsort(rr)).astype(float) / max(1, m-1)
        # duplicate-ish counts by rounded absolute amount
        rounded = np.round(np.abs(rr) / 5.0)
        dup_count = np.array([np.sum(rounded == r) for r in rounded], dtype=float)
        # family and charge shares for each row
        fam_amt = np.zeros(m)
        fam_cnt = np.zeros(m)
        for f in np.unique(fam):
            mask = fam == f
            fam_amt[mask] = rp[mask].sum() / subtotal_pos
            fam_cnt[mask] = mask.sum() / max(1, m)
        ch_amt = np.zeros(m)
        ch_cnt = np.zeros(m)
        for c in np.unique(ch):
            mask = ch == c
            ch_amt[mask] = rp[mask].sum() / subtotal_pos
            ch_cnt[mask] = mask.sum() / max(1, m)
        header_discount = invoice_X[ii, IX_HEADER_DISCOUNT]
        header_shipping = invoice_X[ii, IX_HEADER_SHIPPING]
        handling = invoice_X[ii, IX_HEADER_HANDLING_FEE]
        # first 20 columns rowwise allocation features
        agg[idx, 0] = m
        agg[idx, 1] = _signed_log(invoice_X[ii, IX_INVOICE_SUBTOTAL])
        agg[idx, 2] = np.log1p(abs(invoice_X[ii, IX_HEADER_DISCOUNT]))
        agg[idx, 3] = np.log1p(abs(invoice_X[ii, IX_HEADER_SHIPPING]))
        agg[idx, 4] = np.log1p(abs(invoice_X[ii, IX_HEADER_HANDLING_FEE]))
        agg[idx, 5] = amount_share
        agg[idx, 6] = weight_share
        agg[idx, 7] = package_share
        agg[idx, 8] = service_share
        agg[idx, 9] = eligible_share
        agg[idx, 10] = low_share
        agg[idx, 11] = fam_amt
        agg[idx, 12] = fam_cnt
        agg[idx, 13] = ch_amt
        agg[idx, 14] = ch_cnt
        agg[idx, 15] = order
        agg[idx, 16] = dup_count
        agg[idx, 17] = np.mean(rr < 0)
        agg[idx, 18] = np.mean(exc > 0)
        agg[idx, 19] = np.mean(service)
        agg[idx, 20] = _signed_log(header_discount * amount_share)
        agg[idx, 21] = _signed_log(header_discount * eligible_share)
        agg[idx, 22] = _signed_log(header_discount * service_share)
        agg[idx, 23] = _signed_log(header_discount * low_share)
        agg[idx, 24] = _signed_log(header_shipping * amount_share)
        agg[idx, 25] = _signed_log(header_shipping * weight_share)
        agg[idx, 26] = _signed_log(header_shipping * package_share)
        agg[idx, 27] = _signed_log(handling * service_share)
        agg[idx, 28] = _signed_log(handling * low_share)
        agg[idx, 29] = _signed_log((header_shipping + handling - header_discount) * amount_share)
        agg[idx, 30] = _safe_div(rp, np.maximum(1.0, np.mean(rp)))
        agg[idx, 31] = _safe_div(wt, np.maximum(1.0, np.mean(wt)))
        agg[idx, 32] = np.log1p(np.max(rp))
        agg[idx, 33] = np.log1p(np.mean(rp))
        agg[idx, 34] = np.log1p(np.std(rp))
        agg[idx, 35] = invoice_X[ii, IX_MINIMUM_CHARGE_FLAG]
        agg[idx, 36] = invoice_X[ii, IX_EXPEDITE_FLAG]
        agg[idx, 37] = rep_code[idx, IC_CONTRACT_CHANNEL]
    X_parts = [np.vstack(base).T, rep_inv, rep_code, agg]
    if fit:
        encoders = {}
        keys = {
            'vendor': invoice_code[np.searchsorted(invoice_offsets[1:], np.arange(n), side='right'), IC_VENDOR_CODE],
            'family': line_code[:, [LC_ITEM_FAMILY]],
            'vendor_family': np.column_stack([invoice_code[np.searchsorted(invoice_offsets[1:], np.arange(n), side='right'), IC_VENDOR_CODE], line_code[:, LC_ITEM_FAMILY]]),
            'contract_family': np.column_stack([line_code[:, LC_CONTRACT_TIER], line_code[:, LC_ITEM_FAMILY]]),
            'charge_exc': np.column_stack([line_code[:, LC_CHARGE_TYPE], line_code[:, LC_EXCEPTION_CODE]]),
        }
        te_cols = []
        for name, key in keys.items():
            mapping, default = _target_encode(key, y_log, shrink=25.0)
            encoders[name] = (mapping, default)
            te_cols.append(_apply_te(key, mapping, default))
        X_parts.append(np.vstack(te_cols).T)
        return np.hstack(X_parts), encoders
    else:
        inv_ids = np.searchsorted(invoice_offsets[1:], np.arange(n), side='right')
        keys = {
            'vendor': invoice_code[inv_ids, IC_VENDOR_CODE],
            'family': line_code[:, [LC_ITEM_FAMILY]],
            'vendor_family': np.column_stack([invoice_code[inv_ids, IC_VENDOR_CODE], line_code[:, LC_ITEM_FAMILY]]),
            'contract_family': np.column_stack([line_code[:, LC_CONTRACT_TIER], line_code[:, LC_ITEM_FAMILY]]),
            'charge_exc': np.column_stack([line_code[:, LC_CHARGE_TYPE], line_code[:, LC_EXCEPTION_CODE]]),
        }
        te_cols = []
        for name, key in keys.items():
            mapping, default = encoders[name]
            te_cols.append(_apply_te(key, mapping, default))
        X_parts.append(np.vstack(te_cols).T)
        return np.hstack(X_parts)



def _vendor_attrs(vendor):
    v = float(int(vendor) + 1)
    discount_style = 0.5 + 0.32 * np.sin(v * 0.73) + 0.13 * np.cos(v * 0.11)
    ship_style = 0.5 + 0.30 * np.cos(v * 0.47) - 0.10 * np.sin(v * 0.17)
    min_style = 0.5 + 0.28 * np.sin(v * 0.31 + 0.4)
    bias = 0.018 * np.sin(v * 0.19) + 0.011 * np.cos(v * 0.07)
    exception_style = 0.5 + 0.30 * np.cos(v * 0.29)
    return discount_style, ship_style, min_style, bias, exception_style


def _family_attrs(family):
    f = float(int(family) + 1)
    margin = 0.97 + 0.07 * np.sin(f * 0.63) + 0.03 * np.cos(f * 0.17)
    bulk = 0.55 + 0.45 * ((int(family) % 7) in (0, 3, 5)) + 0.08 * np.sin(f)
    service_affinity = 0.2 + 0.7 * ((int(family) % 11) in (1, 6))
    volatility = 0.03 + 0.045 * ((int(family) % 5) == 2) + 0.015 * np.cos(f * 0.33)
    return margin, bulk, service_affinity, max(0.02, volatility)


def _softmax(z):
    z = np.asarray(z, dtype=float)
    z = z - np.max(z)
    e = np.exp(z)
    return e / np.sum(e)


def _structural_prediction(line_X, line_code, invoice_X, invoice_code, invoice_offsets):
    out = np.zeros(line_X.shape[0], dtype=float)
    for ii in range(len(invoice_offsets) - 1):
        s, e = int(invoice_offsets[ii]), int(invoice_offsets[ii + 1])
        idx = slice(s, e)
        n = e - s
        vendor = int(invoice_code[ii, IC_VENDOR_CODE])
        channel = int(invoice_code[ii, IC_CONTRACT_CHANNEL])
        region = int(invoice_code[ii, IC_INVOICE_REGION])
        month = int(invoice_code[ii, IC_MONTH_BUCKET])
        disc_style, ship_style, min_style, vendor_bias, _ = _vendor_attrs(vendor)
        contract_tier = int(np.bincount(line_code[idx, LC_CONTRACT_TIER].astype(int), minlength=5).argmax())
        vendor_volume_tier = min(4, int(np.log1p(max(0, 320 - vendor)) // 1.5))
        raw = line_X[idx, LX_RAW_AMOUNT]
        raw_pos = np.maximum(raw, 0.0)
        positive_subtotal = float(raw_pos.sum())
        header_discount = invoice_X[ii, IX_HEADER_DISCOUNT]
        header_shipping = invoice_X[ii, IX_HEADER_SHIPPING]
        handling = invoice_X[ii, IX_HEADER_HANDLING_FEE]
        min_charge_flag = int(invoice_X[ii, IX_MINIMUM_CHARGE_FLAG] > 0.5)
        expedite = int(invoice_X[ii, IX_EXPEDITE_FLAG] > 0.5)
        ch = line_code[idx, LC_CHARGE_TYPE].astype(int)
        fam = line_code[idx, LC_ITEM_FAMILY].astype(int)
        unit_type = line_code[idx, LC_UNIT_TYPE].astype(int)
        exc = line_code[idx, LC_EXCEPTION_CODE].astype(int)
        service_flag = np.isin(ch, [1, 2, 3]).astype(float)
        eligible_flag = (~np.isin(ch, [4, 5])).astype(float)
        package = np.maximum(line_X[idx, LX_PACKAGE_COUNT], 0.0)
        weight = np.maximum(line_X[idx, LX_WEIGHT_PROXY], 0.0)
        amount_share = raw_pos / max(raw_pos.sum(), 1e-9)
        elig_amount = raw_pos * eligible_flag * (ch != 2) * (ch != 3)
        eligible_share = elig_amount / max(elig_amount.sum(), 1e-9)
        package_share = package / max(package.sum(), 1e-9)
        weight_share = weight / max(weight.sum(), 1e-9)
        service_share = service_flag / max(service_flag.sum(), 1e-9) if service_flag.sum() > 0 else amount_share
        low_value = (raw_pos <= np.quantile(raw_pos, 0.35) if n > 2 else np.ones(n, dtype=bool)).astype(float)
        low_value_share = low_value * eligible_flag / max(np.sum(low_value * eligible_flag), 1e-9)
        fam_bulk = np.array([_family_attrs(f)[1] for f in fam])
        bulk_mix = float(np.average(fam_bulk, weights=np.maximum(raw_pos, 1.0))) if n else 0.0
        service_mix = float(service_flag.mean()) if n else 0.0
        service_absorb_guess = float(service_mix > 0.16)
        z_discount = np.array([
            0.6 + 0.5 * disc_style + 0.18 * contract_tier,
            0.4 + 0.8 * (contract_tier >= 2) + 0.3 * (channel == 1),
            -0.1 + 0.7 * bulk_mix + 0.1 * region,
            -0.4 + 1.3 * service_mix + 0.4 * service_absorb_guess,
            -0.2 + 0.8 * min_charge_flag + 0.2 * (n < 4),
        ])
        w_disc = _softmax(z_discount)
        disc_share = w_disc[0] * amount_share + w_disc[1] * eligible_share + w_disc[2] * package_share + w_disc[3] * service_share + w_disc[4] * low_value_share
        disc_share /= max(disc_share.sum(), 1e-9)
        z_ship = np.array([
            0.1 + 1.0 * ship_style + 0.30 * expedite,
            0.3 + 1.5 * bulk_mix + 0.25 * region,
            -0.2 + 0.60 * package.mean(),
            -0.4 + 1.0 * service_mix + 0.30 * (channel == 3),
        ])
        w_ship = _softmax(z_ship)
        ship_share = w_ship[0] * amount_share + w_ship[1] * weight_share + w_ship[2] * package_share + w_ship[3] * service_share
        ship_share /= max(ship_share.sum(), 1e-9)
        min_share = 0.58 * service_share + 0.27 * low_value_share + 0.15 * package_share
        min_share /= max(min_share.sum(), 1e-9)
        for local_j, j in enumerate(range(s, e)):
            family = int(fam[local_j])
            margin, bulk, service_affinity, volatility = _family_attrs(family)
            amount = float(raw[local_j])
            ut = int(unit_type[local_j])
            c = int(ch[local_j])
            ex = int(exc[local_j])
            unit_shift_guess = ((family in (2, 8, 13, 19)) and (ut in (3, 4) or family % 5 == 2))
            unit_correction = 1.0 + 0.012 * ut + 0.018 * float(unit_shift_guess)
            family_contract = 1.0 + 0.014 * contract_tier * np.sin((family + 1) * 0.6) + 0.010 * channel * np.cos((family + region + 1) * 0.3)
            subfamily = int(line_code[j, LC_ITEM_SUBFAMILY])
            vendor_line_type = int(line_code[j, LC_VENDOR_LINE_TYPE])
            hist_log = np.log1p(line_X[j, LX_HIST_ITEM_VOLUME])
            lead_log = np.log1p(line_X[j, LX_LEAD_TIME])
            price_idx = line_X[j, LX_RECENT_PRICE_INDEX]
            pos_norm = line_X[j, LX_LINE_POSITION_NORM]
            line_audit = np.tanh(
                0.34 * (price_idx - 1.08)
                + 0.12 * (hist_log - 5.0)
                - 0.10 * (lead_log - 2.0)
                + 0.18 * np.sin(0.21 * subfamily + 0.45 * vendor_line_type)
                + 0.11 * invoice_X[ii, IX_SEASON_SIN]
                - 0.08 * invoice_X[ii, IX_SEASON_COS]
                + 0.15 * (pos_norm - 0.5) * (c in (1, 3, 6))
            )
            complex_multiplier = 1.0 + (0.550 + 0.105 * contract_tier) * line_audit
            base = amount * unit_correction * family_contract * (1.0 + vendor_bias) * complex_multiplier
            base -= line_X[j, LX_REPORTED_DISCOUNT] * (0.8 + 0.1 * contract_tier)
            base += line_X[j, LX_REPORTED_TAX] * (0.55 + 0.06 * region)
            if c == 1:
                base *= 1.0 + 0.05 * service_affinity + 0.02 * contract_tier
            elif c == 6:
                base *= 0.82 + 0.04 * ex
            elif c == 2:
                base *= 0.60 + 0.07 * expedite
            elif c == 3:
                base *= 0.72 + 0.04 * channel
            base -= header_discount * disc_share[local_j] * (0.94 + 0.03 * np.sin(vendor + family))
            base += header_shipping * ship_share[local_j] * (0.90 + 0.04 * np.cos(region + family))
            base += handling * (0.45 * ship_share[local_j] + 0.55 * min_share[local_j]) * (1.0 + 0.025 * channel)
            local_mix = (
                0.255 * abs(amount) * np.sin(0.17 * subfamily + 0.33 * vendor_line_type + 0.11 * month)
                + 0.330 * header_discount * disc_share[local_j] * np.tanh(hist_log - 4.6)
                - 0.285 * header_shipping * ship_share[local_j] * np.tanh(lead_log - 1.8)
            )
            base += local_mix
            if min_charge_flag:
                base += max(0.0, 42.0 + 4.5 * region - 0.025 * positive_subtotal) * min_share[local_j] * (0.8 + 0.3 * min_style)
            if ex >= 7:
                base += (8.0 + 0.018 * abs(amount)) * np.sin(0.7 * ex + 0.2 * family) + 4.0 * (c == 6)
            elif ex > 0:
                base += (2.0 + 0.006 * abs(amount)) * np.cos(ex + channel)
            if c == 4:
                base *= 0.75 + 0.05 * (ex > 0)
                base -= 0.05 * header_discount * eligible_share[local_j]
            if c == 5:
                paired_strength = 0.25 + 0.50 * (0.35 + 0.03 * vendor_volume_tier)
                base *= paired_strength
                base -= 0.02 * positive_subtotal * amount_share[local_j]
            out[j] = base
    return out

def fit_invoice_model(train_line_X, train_line_code, train_invoice_X, train_invoice_code, train_invoice_offsets, train_y):
    y_log = _signed_log(np.asarray(train_y, dtype=float))
    structural = _structural_prediction(train_line_X, train_line_code, train_invoice_X, train_invoice_code, train_invoice_offsets)
    structural_log = _signed_log(structural)
    X, enc = _build_features(train_line_X, train_line_code, train_invoice_X, train_invoice_code, train_invoice_offsets, fit=True, y_log=y_log)
    residual = y_log - structural_log
    hgb = HistGradientBoostingRegressor(max_iter=180, learning_rate=0.045, max_leaf_nodes=23, l2_regularization=0.08, random_state=17, min_samples_leaf=20)
    hgb.fit(X, residual)
    ridge = make_pipeline(StandardScaler(), Ridge(alpha=18.0))
    ridge.fit(X, residual)
    return {'enc': enc, 'hgb': hgb, 'ridge': ridge}


def predict_net_line_cost(line_X, line_code, invoice_X, invoice_code, invoice_offsets, params):
    structural = _structural_prediction(line_X, line_code, invoice_X, invoice_code, invoice_offsets)
    structural_log = _signed_log(structural)
    X = _build_features(line_X, line_code, invoice_X, invoice_code, invoice_offsets, encoders=params['enc'], fit=False)
    resid = 0.72 * params['hgb'].predict(X) + 0.28 * params['ridge'].predict(X)
    z = structural_log + resid
    pred = _inv_signed_log(z)
    raw = np.asarray(line_X[:, LX_RAW_AMOUNT], dtype=float)
    scale = np.maximum(100.0, 12.0 * np.maximum(1.0, np.abs(raw)) + 5.0 * (np.abs(raw).mean() + 1.0))
    return np.clip(pred, -scale, scale)
