# Task

The records are packed invoice line data. Each invoice has one or more line rows. Implement the two functions in `app/solve.py`:

```python
fit_invoice_model(
    train_line_X,
    train_line_code,
    train_invoice_X,
    train_invoice_code,
    train_invoice_offsets,
    train_y,
)

predict_net_line_cost(
    line_X,
    line_code,
    invoice_X,
    invoice_code,
    invoice_offsets,
    params,
)
```

Return one finite prediction for every input line. The target is the final audited net cost for each line. Rows from the same invoice may affect one another.

`invoice_offsets[i]:invoice_offsets[i + 1]` gives the line rows belonging to invoice `i`.

Scoring is based mainly on RMSE after a signed log transform of predicted and true net line costs, with additional held-out cohorts. Signed log means `sign(x) * log1p(abs(x))`.

Keep the implementation deterministic and do not mutate the input arrays.
