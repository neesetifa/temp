"""Starter implementation for invoice_line_reconciliation.

Replace the bodies of fit_invoice_model and predict_net_line_cost.
"""
from __future__ import annotations
import numpy as np


def fit_invoice_model(
    train_line_X,
    train_line_code,
    train_invoice_X,
    train_invoice_code,
    train_invoice_offsets,
    train_y,
):
    # Simple starter: remember a signed-log mean and a rough raw-line slope.
    y = np.asarray(train_y, dtype=float)
    raw = np.asarray(train_line_X[:, 2], dtype=float)
    denom = float(np.dot(raw, raw) + 1e-9)
    slope = float(np.dot(raw, y) / denom) if raw.size else 1.0
    return {"mean": float(np.mean(y)) if y.size else 0.0, "slope": slope}


def predict_net_line_cost(
    line_X,
    line_code,
    invoice_X,
    invoice_code,
    invoice_offsets,
    params,
):
    raw = np.asarray(line_X[:, 2], dtype=float)
    slope = float(params.get("slope", 1.0)) if isinstance(params, dict) else 1.0
    pred = slope * raw
    if pred.shape[0] != line_X.shape[0]:
        pred = np.full(line_X.shape[0], float(params.get("mean", 0.0)))
    return pred.astype(float)
