# invoice_line_reconciliation

Modify `environment/app/solve.py` only.

Data files:

- `app/train_data.npz`: labeled invoice line data.
- `app/public_eval.npz`: small public evaluation fixture used by the public tests.

Array shapes:

- `line_X`: `(n_lines, n_line_features)`, numeric line features.
- `line_code`: `(n_lines, n_line_codes)`, integer-coded line categories.
- `invoice_X`: `(n_invoices, n_invoice_features)`, numeric invoice-level features.
- `invoice_code`: `(n_invoices, n_invoice_codes)`, integer-coded invoice-level categories.
- `invoice_offsets`: `(n_invoices + 1,)`, packed line boundaries.
- `y`: `(n_lines,)`, final audited net line cost, present in the training file.

Run public tests from the `environment` directory with:

```bash
python -m pytest tests
```
