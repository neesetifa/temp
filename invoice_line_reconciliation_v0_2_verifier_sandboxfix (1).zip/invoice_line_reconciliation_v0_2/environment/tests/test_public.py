from __future__ import annotations
import importlib.util
from pathlib import Path
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "app" / "solve.py"
DATA = np.load(ROOT / "app" / "train_data.npz")
PUBLIC = np.load(ROOT / "app" / "public_eval.npz")


def load_mod():
    spec = importlib.util.spec_from_file_location("solve", str(APP))
    mod = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(mod)
    return mod


def test_api_shape_and_finite():
    mod = load_mod()
    params = mod.fit_invoice_model(DATA['line_X'], DATA['line_code'], DATA['invoice_X'], DATA['invoice_code'], DATA['invoice_offsets'], DATA['y'])
    pred = np.asarray(mod.predict_net_line_cost(PUBLIC['line_X'], PUBLIC['line_code'], PUBLIC['invoice_X'], PUBLIC['invoice_code'], PUBLIC['invoice_offsets'], params), dtype=float)
    assert pred.shape == PUBLIC['y'].shape
    assert np.all(np.isfinite(pred))


def test_predict_is_deterministic():
    mod = load_mod()
    params = mod.fit_invoice_model(DATA['line_X'], DATA['line_code'], DATA['invoice_X'], DATA['invoice_code'], DATA['invoice_offsets'], DATA['y'])
    p1 = np.asarray(mod.predict_net_line_cost(PUBLIC['line_X'], PUBLIC['line_code'], PUBLIC['invoice_X'], PUBLIC['invoice_code'], PUBLIC['invoice_offsets'], params), dtype=float)
    p2 = np.asarray(mod.predict_net_line_cost(PUBLIC['line_X'], PUBLIC['line_code'], PUBLIC['invoice_X'], PUBLIC['invoice_code'], PUBLIC['invoice_offsets'], params), dtype=float)
    assert np.allclose(p1, p2, rtol=0, atol=1e-12)


def test_does_not_mutate_inputs():
    mod = load_mod()
    args = [DATA['line_X'].copy(), DATA['line_code'].copy(), DATA['invoice_X'].copy(), DATA['invoice_code'].copy(), DATA['invoice_offsets'].copy(), DATA['y'].copy()]
    before = [x.copy() for x in args]
    params = mod.fit_invoice_model(*args)
    for a,b in zip(args,before):
        assert np.array_equal(a,b)
    pargs = [PUBLIC['line_X'].copy(), PUBLIC['line_code'].copy(), PUBLIC['invoice_X'].copy(), PUBLIC['invoice_code'].copy(), PUBLIC['invoice_offsets'].copy()]
    before = [x.copy() for x in pargs]
    _ = mod.predict_net_line_cost(*pargs, params)
    for a,b in zip(pargs,before):
        assert np.array_equal(a,b)


def test_offsets_are_consistent():
    assert DATA['invoice_offsets'][0] == 0
    assert DATA['invoice_offsets'][-1] == DATA['line_X'].shape[0]
    assert np.all(np.diff(DATA['invoice_offsets']) > 0)
    assert PUBLIC['invoice_offsets'][0] == 0
    assert PUBLIC['invoice_offsets'][-1] == PUBLIC['line_X'].shape[0]
