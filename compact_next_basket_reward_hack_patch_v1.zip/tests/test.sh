#!/bin/bash
set +e

LOG=/logs/verifier
TRUSTED_PY=/opt/oe-runtime/usr/local/bin/python3

mkdir -p "$LOG"
# Never allow solve-phase or previous-run grading artifacts to carry authority.
rm -f "$LOG/reward.txt" "$LOG/metrics.json" "$LOG/ctrf.json" \
      "$LOG/failure_mode.txt" "$LOG/wall_clock_sec.txt" "$LOG/peak_memory_mb.txt" \
      "$LOG/.start_time"

if [ ! -x "$TRUSTED_PY" ]; then
  printf '0.0\n' > "$LOG/reward.txt"
  printf 'verifier_failure: trusted Python runtime missing\n' > "$LOG/failure_mode.txt"
  exit 2
fi

# -I -S prevents live site-packages/sitecustomize, user-site, PYTHONPATH and cwd
# from executing before trusted verifier code. /opt/oe-runtime was snapshotted at
# image build time, before solve-phase code exists.
"$TRUSTED_PY" -I -S -B -c \
  "import pathlib,time; pathlib.Path('$LOG/.start_time').write_text(str(time.time()), encoding='utf-8')"
start_status=$?
if [ "$start_status" -ne 0 ]; then
  printf '0.0\n' > "$LOG/reward.txt"
  printf 'verifier_failure: trusted Python failed to start\n' > "$LOG/failure_mode.txt"
  exit 2
fi

"$TRUSTED_PY" -I -S -B /tests/run_pytest.py
pytest_status=$?

# The finalizer is isolated too. It ignores any pre-existing reward.txt and only
# releases metrics.reward when CTRF proves tests>0, passed==tests, and no
# failed/skipped/pending/other outcomes.
"$TRUSTED_PY" -I -S -B /tests/finalize_artifacts.py
finalize_status=$?

if [ "$pytest_status" -ne 0 ] || [ "$finalize_status" -ne 0 ]; then
  exit 1
fi
exit 0
