from __future__ import annotations

import csv
import json
import math
import pathlib
import resource
import tempfile

from verifier_utils import artifact_size_and_validate, load_catalog, ndcg_at_10, parse_predictions, run_predict, write_input

TEST_DIR = pathlib.Path(__file__).resolve().parent
LOG_DIR = pathlib.Path('/logs/verifier')


def _load_cases():
    out = []
    with (TEST_DIR / 'test.csv').open(newline='', encoding='utf-8') as f:
        r = csv.DictReader(f)
        assert r.fieldnames == ['query_id', 'history', 'gaps_days', 'target_items'], f'bad test schema: {r.fieldnames}'
        for row in r:
            target = {x for x in row['target_items'].split() if x}
            if not target:
                continue
            seen = {x for basket in row['history'].split('|') for x in basket.split() if x}
            assert target.isdisjoint(seen), 'v0.4 verifier target contains a repeated history item'
            out.append((row['query_id'], row['history'], row['gaps_days'], target))
    assert out, 'empty test.csv'
    return out


def _score(preds, cases):
    vals = [ndcg_at_10(p, c[3]) for p, c in zip(preds, cases)]
    hits = [1.0 if any(x in c[3] for x in p) else 0.0 for p, c in zip(preds, cases)]
    return sum(vals) / len(vals), sum(hits) / len(hits)


def test_reward():
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    artifact_bytes = artifact_size_and_validate()
    catalog = load_catalog()
    cases = _load_cases()
    config = json.loads((TEST_DIR / 'scoring_config.json').read_text())
    floor = float(config['unseen_popularity_ndcg_at_10'])
    anchor = float(config['calibration_anchor_ndcg_at_10'])
    anchor_reward = float(config['calibration_anchor_reward'])
    assert config['novel_target_only'] is True
    assert 0.0 <= floor < anchor <= 1.0, 'invalid reward anchors'
    assert 0.0 < anchor_reward < 1.0, 'invalid calibration anchor reward'

    rows = [(c[0], c[1], c[2]) for c in cases]
    with tempfile.TemporaryDirectory(prefix='oe_main_') as td:
        td = pathlib.Path(td)
        p_in = td / 'in.csv'; p_out = td / 'out.csv'
        p_rev = td / 'rev.csv'; p_rev_out = td / 'rev_out.csv'
        write_input(p_in, rows)
        run_predict(p_in, p_out, timeout=60)
        preds = parse_predictions(p_out, len(cases), catalog)
        write_input(p_rev, list(reversed(rows)))
        run_predict(p_rev, p_rev_out, timeout=60)
        rp = parse_predictions(p_rev_out, len(cases), catalog)
        assert rp == list(reversed(preds)), 'predictions depend on input row position'

    raw, hit = _score(preds, cases)
    z = max(0.0, (raw - floor) / max(1e-12, anchor - floor))
    reward = 1.0 - (1.0 - anchor_reward) ** z
    reward = max(0.0, min(1.0, reward))
    assert math.isfinite(reward)
    peak = resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss / 1024.0
    metrics = {
        'artifact_bytes': artifact_bytes,
        'artifact_limit_bytes': int(config['artifact_limit_bytes']),
        'calibration_anchor_ndcg_at_10': anchor,
        'calibration_anchor_reward': anchor_reward,
        'catalog_size': len(catalog),
        'customer_disjoint_eval': True,
        'evaluated_customers': len(cases),
        'hit_rate_at_10': hit,
        'ndcg_at_10': raw,
        'novel_target_only': True,
        'peak_child_memory_mb': peak,
        'reward': reward,
        'reward_gap_units': z,
        'unseen_popularity_ndcg_at_10': floor,
    }
    (LOG_DIR / 'metrics.json').write_text(json.dumps(metrics, indent=2, sort_keys=True) + '\n')
