from __future__ import annotations

import json
import math
import pathlib
import time

LOG = pathlib.Path('/logs/verifier')


def _as_nonnegative_int(summary: dict, key: str) -> int:
    value = summary[key]
    if isinstance(value, bool):
        raise ValueError(f'CTRF summary.{key} must be an integer')
    ivalue = int(value)
    if ivalue != value or ivalue < 0:
        raise ValueError(f'CTRF summary.{key} must be a non-negative integer')
    return ivalue


def validate_ctrf(path: pathlib.Path) -> dict:
    data = json.loads(path.read_text(encoding='utf-8'))
    summary = data['results']['summary']
    tests = _as_nonnegative_int(summary, 'tests')
    passed = _as_nonnegative_int(summary, 'passed')
    failed = _as_nonnegative_int(summary, 'failed')
    pending = _as_nonnegative_int(summary, 'pending')
    skipped = _as_nonnegative_int(summary, 'skipped')
    other = _as_nonnegative_int(summary, 'other')

    if tests <= 0 or passed <= 0:
        raise ValueError('CTRF proves no tests ran/passed')
    if failed != 0 or pending != 0 or skipped != 0 or other != 0:
        raise ValueError('CTRF contains non-passing tests')
    if passed != tests:
        raise ValueError('CTRF passed count does not equal tests count')
    return summary


def finalize(log_dir: pathlib.Path = LOG) -> tuple[float, str]:
    log_dir.mkdir(parents=True, exist_ok=True)
    reward_path = log_dir / 'reward.txt'
    metrics_path = log_dir / 'metrics.json'
    ctrf_path = log_dir / 'ctrf.json'

    failure = 'none'
    reward = 0.0
    metrics: dict = {}
    try:
        validate_ctrf(ctrf_path)
        if not metrics_path.exists():
            raise FileNotFoundError('metrics.json missing')
        metrics = json.loads(metrics_path.read_text(encoding='utf-8'))
        reward = float(metrics['reward'])
        if not math.isfinite(reward) or not (0.0 <= reward <= 1.0):
            raise ValueError('metrics.reward must be finite and in [0,1]')
    except Exception as e:
        failure = f'verifier_failure: {type(e).__name__}: {e}'
        reward = 0.0
        if not isinstance(metrics, dict):
            metrics = {}
        metrics = dict(metrics)
        metrics['reward'] = 0.0
        metrics_path.write_text(json.dumps(metrics, indent=2, sort_keys=True) + '\n', encoding='utf-8')

    # reward.txt is an OUTPUT of the trusted finalizer, never an input. A
    # solve-phase or pre-test planted reward.txt therefore has no authority.
    reward_path.write_text(f'{reward:.12f}\n', encoding='utf-8')
    (log_dir / 'failure_mode.txt').write_text(failure + '\n', encoding='utf-8')

    start_path = log_dir / '.start_time'
    try:
        start = float(start_path.read_text(encoding='utf-8').strip())
        wall = max(0.0, time.time() - start)
    except Exception:
        wall = 0.0
    (log_dir / 'wall_clock_sec.txt').write_text(f'{wall:.6f}\n', encoding='utf-8')

    peak = float(metrics.get('peak_child_memory_mb', 0.0) or 0.0)
    if not math.isfinite(peak) or peak < 0:
        peak = 0.0
    (log_dir / 'peak_memory_mb.txt').write_text(f'{peak:.3f}\n', encoding='utf-8')
    return reward, failure


def main() -> int:
    reward, failure = finalize(LOG)
    return 0 if failure == 'none' else 1


if __name__ == '__main__':
    raise SystemExit(main())
