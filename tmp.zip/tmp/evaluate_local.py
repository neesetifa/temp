#!/usr/bin/env python3
"""Local self-check that mirrors the hidden grader.

    python /app/tools/evaluate_local.py --codec /output --n 25

Takes the last N pool caches as a stand-in for the hidden set (hold them out of your own
fitting if you want an honest estimate), then:
  1. runs <codec>/encode.py twice into fresh directories and requires byte-identical output;
  2. runs <codec>/decode.py on the first encoding (its input dir holds only .bin + positions);
  3. checks every decoded element against its bound (float32 comparison with the original
     bf16 value), plus dtype float32 and the original shape;
  4. times each run against the per-run limit;
  5. computes CR = raw bf16 bytes / encoded bytes, CR_base with the baseline codec, and
     reward = clamp(log(CR / CR_base) / log(2), 0, 1).
The grader does the same on the 50 hidden caches (4 CPUs, 12 GB RAM).
"""
from __future__ import annotations

import argparse
import json
import math
import pathlib
import os
import subprocess
import sys
import tempfile
import time

import numpy as np

APP = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(APP / "baseline"))
import kvcodec_baseline as kb  # noqa: E402
import kvformat as kf  # noqa: E402

SCALE = math.log(2.0)


def run(codec, mode, inp, out, limit):
    t0 = time.time()
    # Same thread pinning as the grader: BLAS/OpenMP/MKL single-threaded inside the codec.
    env = dict(os.environ, PYTHONHASHSEED="0", OMP_NUM_THREADS="1", OPENBLAS_NUM_THREADS="1",
               MKL_NUM_THREADS="1")
    cp = subprocess.run([sys.executable, "-B", str(codec / f"{mode}.py"), str(inp), str(out)],
                        capture_output=True, text=True, timeout=limit + 30, env=env)
    dt = time.time() - t0
    if cp.returncode != 0:
        raise SystemExit(f"{mode}.py failed ({cp.returncode}):\n{cp.stderr[-3000:]}")
    return dt


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--codec", default="/output")
    ap.add_argument("--pool", default=str(APP / "pool"))
    ap.add_argument("--n", type=int, default=25, help="use the last N pool caches")
    ap.add_argument("--limit", type=float, default=600.0, help="seconds per encode/decode run")
    args = ap.parse_args()
    codec, pool = pathlib.Path(args.codec), pathlib.Path(args.pool)
    ids = sorted(p.name[: -len(".kv.npy")] for p in pool.glob("*.kv.npy"))[-args.n:]
    eps = kf.eps_per_channel(np.load(APP / "bounds.npy")).astype(np.float32)
    eps5 = kf.from_tc(eps[None, :]).astype(np.float32)          # (23, 2, 1, 2, 64)

    with tempfile.TemporaryDirectory(prefix="kv_eval_") as td:
        td = pathlib.Path(td)
        inp, enc1, enc2, dec_in, dec_out = (td / n for n in ("in", "e1", "e2", "din", "dout"))
        for d in (inp, enc1, enc2, dec_in, dec_out):
            d.mkdir()
        for i in ids:                       # symlinks: saves disk (10 GB sandbox)
            for suf in (".kv.npy", ".pos.npy"):
                (inp / f"{i}{suf}").symlink_to(pool / f"{i}{suf}")
        t_enc = run(codec, "encode", inp, enc1, args.limit)
        run(codec, "encode", inp, enc2, args.limit)
        names1 = sorted(p.name for p in enc1.iterdir())
        assert names1 == sorted(f"{i}.bin" for i in ids), "encode.py must write exactly <id>.bin per cache"
        same = all((enc1 / n).read_bytes() == (enc2 / n).read_bytes() for n in names1)
        for i in ids:
            (dec_in / f"{i}.bin").write_bytes((enc1 / f"{i}.bin").read_bytes())
            (dec_in / f"{i}.pos.npy").symlink_to(pool / f"{i}.pos.npy")
        t_dec = run(codec, "decode", dec_in, dec_out, args.limit)

        raw = coded = base = 0
        viol = 0
        ba = kb.Assets(APP / "baseline" / "baseline_assets.npz")
        for i in ids:
            u = np.load(pool / f"{i}.kv.npy", allow_pickle=False)
            out = np.load(dec_out / f"{i}.npy", allow_pickle=False)
            if out.dtype != np.float32 or out.shape != u.shape:
                raise SystemExit(f"{i}: decoded array must be float32 with shape {u.shape}")
            orig = kf.bf16_to_f32(u)
            viol += int((~(np.abs(out - orig) <= eps5)).sum())       # NaN counts as a violation
            raw += u.size * 2
            coded += (enc1 / f"{i}.bin").stat().st_size
            base += len(kb.encode(u, ba))
    cr, cr_base = raw / coded, raw / base
    gated = (not same) or viol > 0 or t_enc > args.limit or t_dec > args.limit
    reward = 0.0 if gated else max(0.0, min(1.0, math.log(cr / cr_base) / SCALE))
    print(json.dumps({"caches": len(ids), "deterministic": same, "bound_violations": viol,
                      "encode_s": round(t_enc, 1), "decode_s": round(t_dec, 1),
                      "CR": round(cr, 4), "CR_base": round(cr_base, 4),
                      "reward": round(reward, 4), "gated_to_zero": gated}, indent=2))


if __name__ == "__main__":
    main()
