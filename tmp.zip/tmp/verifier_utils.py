"""Grader helpers for the KV-cache codec task."""
from __future__ import annotations

import json
import os
import pathlib
import shutil
import signal
import stat
import subprocess
import sys
import tempfile
import time

import numpy as np

TEST_DIR = pathlib.Path(__file__).resolve().parent
OUTPUT_DIR = pathlib.Path('/output')
HIDDEN = TEST_DIR / 'hidden'
KVREF = TEST_DIR / 'kvref'
CONFIG = json.loads((TEST_DIR / 'scoring_config.json').read_text(encoding='utf-8'))
ARTIFACT_LIMIT = int(CONFIG['artifact_limit_bytes'])

# --- codec isolation -------------------------------------------------------------------------
# Every encode/decode call runs as an unprivileged uid that cannot read /tests, in a fresh
# sandbox directory that holds only its input (read-only links) and private out/tmp/home/work
# folders. Between calls the grader kills every process of that uid, deletes everything it
# left in world-writable places, removes SysV IPC objects, and checks /output is unchanged.
RUNNER_UID = int(os.environ.get('KV_RUNNER_UID', '10001'))
RUNNER_GID = int(os.environ.get('KV_RUNNER_GID', '10001'))
GRADE_BASE = pathlib.Path(os.environ.get('KV_GRADE_BASE', '/var/lib/kvgrade'))
PROTECT = [pathlib.Path(p) for p in ('/tests', '/solution')]
_SKIP_SCAN = {'/proc', '/sys', '/dev'}
_EXTRA_SCAN = ('/dev/shm', '/dev/mqueue')
_ww_dirs = None


def hidden_ids():
    ids = sorted(p.name[: -len('.kv.npy')] for p in HIDDEN.glob('*.kv.npy'))
    if len(ids) != int(CONFIG['hidden_caches']):
        raise AssertionError(f'hidden set has {len(ids)} caches, expected {CONFIG["hidden_caches"]}')
    return ids


def artifact_size(root: pathlib.Path = None) -> int:
    """File bytes plus relative path bytes under /output; regular files and directories only."""
    root = OUTPUT_DIR if root is None else root
    total = 0
    for dirpath, dirnames, filenames in os.walk(root, followlinks=False):
        for name in dirnames + filenames:
            p = pathlib.Path(dirpath) / name
            rel = str(p.relative_to(root))
            total += len(rel.encode()) + 1
            if p.is_symlink() or not (p.is_dir() or p.is_file()):
                raise AssertionError(f'only regular files and directories are allowed in /output: {rel}')
            if p.is_file():
                total += p.lstat().st_size
    if total > ARTIFACT_LIMIT:
        raise AssertionError(f'/output is {total} bytes, over the {ARTIFACT_LIMIT}-byte limit')
    for need in ('encode.py', 'decode.py'):
        if not (root / need).is_file() or (root / need).stat().st_size == 0:
            raise AssertionError(f'/output/{need} missing or empty')
    return total


def store_dir() -> pathlib.Path:
    """Root-only area for the grader's own copies (inputs, encodings, decodings)."""
    d = GRADE_BASE / 'store'
    d.mkdir(parents=True, exist_ok=True)
    os.chmod(GRADE_BASE, 0o711)
    os.chmod(d, 0o700)
    return d


def _runs_dir() -> pathlib.Path:
    d = GRADE_BASE / 'runs'
    d.mkdir(parents=True, exist_ok=True)
    os.chmod(GRADE_BASE, 0o711)
    os.chmod(d, 0o711)
    return d


def setup_isolation():
    """Lock grader-only paths and make the submission readable but not writable by the runner."""
    if os.geteuid() != 0:
        raise AssertionError('the grader must run as root to isolate the codec')
    _ensure_runner_account()
    for p in PROTECT:
        if p.exists():
            os.chmod(p, 0o700)
    for root in (OUTPUT_DIR,):
        if not root.exists():
            continue
        for dirpath, dirnames, filenames in os.walk(root, followlinks=False):
            for name in [''] + dirnames + filenames:
                q = pathlib.Path(dirpath) / name if name else pathlib.Path(dirpath)
                try:
                    st = q.lstat()
                    if stat.S_ISLNK(st.st_mode):
                        continue
                    extra = 0o555 if stat.S_ISDIR(st.st_mode) else 0o444
                    os.chmod(q, (st.st_mode | extra) & ~0o022)
                except OSError:
                    pass                                  # read-only mount: permissions as shipped
    _world_writable()                                     # scan once, before any codec runs


def _ensure_runner_account():
    """Give the runner uid a passwd/group entry (some libraries look up the current user)."""
    import grp
    import pwd
    try:
        pwd.getpwuid(RUNNER_UID)
        return
    except KeyError:
        pass
    try:
        grp.getgrgid(RUNNER_GID)
    except KeyError:
        with open('/etc/group', 'a') as f:
            f.write(f'codec_runner:x:{RUNNER_GID}:\n')
    with open('/etc/passwd', 'a') as f:
        f.write(f'codec_runner:x:{RUNNER_UID}:{RUNNER_GID}::/nonexistent:/usr/sbin/nologin\n')


def _world_writable():
    """World-writable directories on the image (where the runner could leave state); also strip
    o+w from world-writable regular files, which the runner could otherwise use to carry data."""
    global _ww_dirs
    if _ww_dirs is not None:
        return _ww_dirs
    found = set()
    roots = ['/'] + [p for p in _EXTRA_SCAN if os.path.isdir(p)]
    for top in roots:
        for dirpath, dirnames, filenames in os.walk(top, followlinks=False):
            if top == '/':
                dirnames[:] = [d for d in dirnames
                               if os.path.join(dirpath, d) not in _SKIP_SCAN
                               and not os.path.join(dirpath, d).startswith(str(GRADE_BASE))]
            try:
                if os.lstat(dirpath).st_mode & 0o002:
                    found.add(dirpath)
            except OSError:
                pass
            for name in filenames:
                q = os.path.join(dirpath, name)
                try:
                    st = os.lstat(q)
                    if stat.S_ISREG(st.st_mode) and st.st_mode & 0o002:
                        os.chmod(q, st.st_mode & ~0o002)
                except OSError:
                    pass
    _ww_dirs = sorted(found)
    return _ww_dirs


def _kill_runner_processes():
    for _ in range(50):
        alive = []
        for d in os.listdir('/proc'):
            if not d.isdigit():
                continue
            try:
                with open(f'/proc/{d}/status') as f:
                    uids = next(l for l in f if l.startswith('Uid:')).split()[1:]
            except (OSError, StopIteration):
                continue
            if str(RUNNER_UID) in uids:
                alive.append(int(d))
        if not alive:
            return
        for pid in alive:
            try:
                os.kill(pid, signal.SIGKILL)
            except OSError:
                pass
        time.sleep(0.05)
    raise AssertionError('could not stop the codec\'s leftover processes')


def _sweep_runner_state():
    """Delete everything the runner uid owns in world-writable places and remove SysV IPC."""
    for d in _world_writable():
        try:
            entries = os.listdir(d)
        except OSError:
            continue
        for name in entries:
            q = os.path.join(d, name)
            try:
                st = os.lstat(q)
            except OSError:
                continue
            if st.st_uid != RUNNER_UID:
                continue
            if stat.S_ISDIR(st.st_mode):
                shutil.rmtree(q, ignore_errors=True)
            else:
                try:
                    os.unlink(q)
                except OSError:
                    pass
    if shutil.which('ipcrm'):
        subprocess.run(['ipcrm', '--all'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


def _manifest(root: pathlib.Path):
    out = []
    for dirpath, dirnames, filenames in os.walk(root, followlinks=False):
        dirnames.sort()
        for name in sorted(dirnames + filenames):
            q = pathlib.Path(dirpath) / name
            st = q.lstat()
            out.append((str(q.relative_to(root)), st.st_mode, st.st_size, st.st_mtime_ns))
    return out


def _link_or_copy(src: pathlib.Path, dst: pathlib.Path):
    try:
        os.link(src, dst)
    except OSError:
        shutil.copyfile(src, dst)
    os.chmod(dst, 0o644)


def run_codec(mode: str, inp: pathlib.Path, out: pathlib.Path, limit: float,
              codec_dir: pathlib.Path = None) -> float:
    """Run <codec_dir>/<mode>.py <in> <out> as the isolated runner; return wall seconds.

    `inp` (regular files only) is exposed read-only inside a fresh sandbox; whatever the codec
    writes to its sandbox output folder is moved into `out` (a grader-owned directory)."""
    codec_dir = OUTPUT_DIR if codec_dir is None else codec_dir
    before = _manifest(codec_dir)
    _kill_runner_processes()
    _sweep_runner_state()
    sandbox = pathlib.Path(tempfile.mkdtemp(prefix=f'{mode}_', dir=_runs_dir()))
    try:
        os.chmod(sandbox, 0o755)
        sb_in = sandbox / 'in'
        sb_in.mkdir(mode=0o755)
        for p in sorted(inp.iterdir()):
            if not p.is_file() or p.is_symlink():
                raise AssertionError(f'grader input {p} is not a regular file')
            _link_or_copy(p, sb_in / p.name)
        os.chmod(sb_in, 0o555)
        private = {}
        for name in ('out', 'tmp', 'home', 'work'):
            d = sandbox / name
            d.mkdir(mode=0o700)
            os.chown(d, RUNNER_UID, RUNNER_GID)
            private[name] = d
        env = {'PATH': '/usr/local/bin:/usr/bin:/bin', 'LANG': 'C.UTF-8',
               'HOME': str(private['home']), 'TMPDIR': str(private['tmp']),
               'PYTHONHASHSEED': '0', 'PYTHONDONTWRITEBYTECODE': '1',
               'OMP_NUM_THREADS': '1', 'OPENBLAS_NUM_THREADS': '1', 'MKL_NUM_THREADS': '1',
               'NUMBA_NUM_THREADS': '4', 'NUMBA_CACHE_DIR': str(private['tmp'] / 'numba_cache')}
        t0 = time.monotonic()
        try:
            cp = subprocess.run([sys.executable, '-B', str(codec_dir / f'{mode}.py'),
                                 str(sb_in), str(private['out'])],
                                cwd=private['work'], env=env, stdin=subprocess.DEVNULL,
                                capture_output=True, timeout=limit, start_new_session=True,
                                user=RUNNER_UID, group=RUNNER_GID, extra_groups=[], umask=0o077)
        except subprocess.TimeoutExpired as exc:
            raise AssertionError(f'{mode}.py exceeded the {limit:g}s time limit') from exc
        finally:
            _kill_runner_processes()
        wall = time.monotonic() - t0
        if cp.returncode != 0:
            raise AssertionError(f'{mode}.py failed with code {cp.returncode}: '
                                 + cp.stderr.decode('utf-8', 'replace')[-3000:])
        if _manifest(codec_dir) != before:
            raise AssertionError(f'{mode}.py modified the submission directory {codec_dir}')
        out.mkdir(parents=True, exist_ok=True)
        for p in sorted(private['out'].iterdir()):
            st = p.lstat()
            if not stat.S_ISREG(st.st_mode):
                raise AssertionError(f'{mode}.py wrote a non-regular file: {p.name}')
            dst = out / p.name
            shutil.move(str(p), str(dst))
            os.chown(dst, 0, 0)
            os.chmod(dst, 0o600)
        return wall
    finally:
        shutil.rmtree(sandbox, ignore_errors=True)
        _sweep_runner_state()


def load_decoded(path: pathlib.Path, shape) -> np.ndarray:
    """Load a submitted .npy without pickles; require C-order float32 of the original shape."""
    with open(path, 'rb') as f:
        fmt = np.lib.format
        version = fmt.read_magic(f)
        if version == (1, 0):
            hdr_shape, fortran, dtype = fmt.read_array_header_1_0(f)
        elif version == (2, 0):
            hdr_shape, fortran, dtype = fmt.read_array_header_2_0(f)
        else:
            raise AssertionError(f'{path.name}: unsupported npy version {version} (use numpy.save)')
        if dtype != np.dtype('<f4') or tuple(hdr_shape) != tuple(shape) or fortran:
            raise AssertionError(f'{path.name}: decoded array must be C-order float32 of shape {tuple(shape)}')
        arr = np.fromfile(f, dtype='<f4', count=int(np.prod(shape)))
    if arr.size != int(np.prod(shape)):
        raise AssertionError(f'{path.name}: truncated decoded array')
    return arr.reshape(shape)
