"""Grader helpers for the KV-cache codec task."""
from __future__ import annotations

import json
import os
import pathlib
import subprocess
import sys
import time

import numpy as np

TEST_DIR = pathlib.Path(__file__).resolve().parent
OUTPUT_DIR = pathlib.Path('/output')
HIDDEN = TEST_DIR / 'hidden'
KVREF = TEST_DIR / 'kvref'
CONFIG = json.loads((TEST_DIR / 'scoring_config.json').read_text(encoding='utf-8'))
ARTIFACT_LIMIT = int(CONFIG['artifact_limit_bytes'])


def hidden_ids():
    ids = sorted(p.name[: -len('.kv.npy')] for p in HIDDEN.glob('*.kv.npy'))
    if len(ids) != int(CONFIG['hidden_caches']):
        raise AssertionError(f'hidden set has {len(ids)} caches, expected {CONFIG["hidden_caches"]}')
    return ids


def artifact_size(root: pathlib.Path = None) -> int:
    """File bytes plus relative path bytes under /output; regular files and directories only."""
    root = OUTPUT_DIR if root is None else root
    total = 0
    for dirpath, dirnames, filenames in os.walk(root, followlinks=False):
        for name in dirnames + filenames:
            p = pathlib.Path(dirpath) / name
            rel = str(p.relative_to(root))
            total += len(rel.encode()) + 1
            if p.is_symlink() or not (p.is_dir() or p.is_file()):
                raise AssertionError(f'only regular files and directories are allowed in /output: {rel}')
            if p.is_file():
                total += p.lstat().st_size
    if total > ARTIFACT_LIMIT:
        raise AssertionError(f'/output is {total} bytes, over the {ARTIFACT_LIMIT}-byte limit')
    for need in ('encode.py', 'decode.py'):
        if not (root / need).is_file() or (root / need).stat().st_size == 0:
            raise AssertionError(f'/output/{need} missing or empty')
    return total


def run_codec(mode: str, inp: pathlib.Path, out: pathlib.Path, limit: float) -> float:
    """Run /output/<mode>.py <inp> <out> with the per-run time limit; return wall seconds."""
    env = {'PATH': '/usr/local/bin:/usr/bin:/bin', 'LANG': 'C.UTF-8', 'HOME': str(out),
           'PYTHONHASHSEED': '0', 'OMP_NUM_THREADS': '1', 'OPENBLAS_NUM_THREADS': '1',
           'MKL_NUM_THREADS': '1', 'NUMBA_NUM_THREADS': '4', 'NUMBA_CACHE_DIR': str(out.parent / 'numba_cache')}
    t0 = time.monotonic()
    try:
        cp = subprocess.run([sys.executable, '-B', str(OUTPUT_DIR / f'{mode}.py'), str(inp), str(out)],
                            cwd=out, env=env, stdin=subprocess.DEVNULL, capture_output=True,
                            timeout=limit, start_new_session=True)
    except subprocess.TimeoutExpired as exc:
        raise AssertionError(f'{mode}.py exceeded the {limit:g}s time limit') from exc
    wall = time.monotonic() - t0
    if cp.returncode != 0:
        raise AssertionError(f'{mode}.py failed with code {cp.returncode}: '
                             + cp.stderr.decode('utf-8', 'replace')[-3000:])
    return wall


def load_decoded(path: pathlib.Path, shape) -> np.ndarray:
    """Load a submitted .npy without pickles; require C-order float32 of the original shape."""
    with open(path, 'rb') as f:
        fmt = np.lib.format
        version = fmt.read_magic(f)
        if version == (1, 0):
            hdr_shape, fortran, dtype = fmt.read_array_header_1_0(f)
        elif version == (2, 0):
            hdr_shape, fortran, dtype = fmt.read_array_header_2_0(f)
        else:
            raise AssertionError(f'{path.name}: unsupported npy version {version} (use numpy.save)')
        if dtype != np.dtype('<f4') or tuple(hdr_shape) != tuple(shape) or fortran:
            raise AssertionError(f'{path.name}: decoded array must be C-order float32 of shape {tuple(shape)}')
        arr = np.fromfile(f, dtype='<f4', count=int(np.prod(shape)))
    if arr.size != int(np.prod(shape)):
        raise AssertionError(f'{path.name}: truncated decoded array')
    return arr.reshape(shape)
