"""Regression test: a codec that tries to reach outside its sandbox gets nothing.

A probe "codec" is run through the same isolated runner as real submissions:
  * its encode.py tries to read /tests and the grader's store, to write into its own codec
    directory, and plants state for a later call (files in /tmp, /var/tmp, /dev/shm, HOME,
    TMPDIR and cwd, a POSIX shared-memory block, and a background process that writes late);
  * its decode.py, run next, looks for every one of those traces and for leftover processes.
The test fails if any access succeeds or any trace survives into the second call.
"""
from __future__ import annotations

import json
import os
import pathlib
import shutil
import tempfile

import verifier_utils as vu

MARKERS = ['/tmp/kvprobe_marker', '/var/tmp/kvprobe_marker', '/dev/shm/kvprobe_marker',
           '/tmp/kvprobe_late']

PLANT = r'''
import json, os, pathlib, subprocess, sys
out = pathlib.Path(sys.argv[2])
rep = {}
def attempt(key, fn):
    try:
        fn(); rep[key] = True
    except Exception:
        rep[key] = False
attempt('read_tests_config', lambda: open('/tests/scoring_config.json').read())
attempt('list_tests_hidden', lambda: os.listdir('/tests/hidden'))
attempt('list_grader_store', lambda: os.listdir(STORE))
attempt('list_grader_runs', lambda: os.listdir(RUNS))
attempt('write_codec_dir', lambda: (pathlib.Path(__file__).parent / 'kvprobe').write_text('x'))
attempt('write_tests', lambda: open('/tests/kvprobe', 'w').write('x'))
for m in MARKERS[:3] + [os.path.join(os.environ['HOME'], 'kvprobe'),
                        os.path.join(os.environ['TMPDIR'], 'kvprobe'), 'kvprobe_cwd']:
    attempt('plant:' + m, lambda m=m: open(m, 'w').write('secret'))
try:
    from multiprocessing import shared_memory, resource_tracker
    shm = shared_memory.SharedMemory(name='kvprobe_shm', create=True, size=64)
    resource_tracker.unregister(shm._name, 'shared_memory')
    shm.buf[:6] = b'secret'
    rep['plant:shm'] = True
except Exception:
    rep['plant:shm'] = False
subprocess.Popen([sys.executable, '-c',
                  "import time, pathlib; time.sleep(3); pathlib.Path('/tmp/kvprobe_late').write_text('x')"],
                 start_new_session=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
(out / 'report.json').write_text(json.dumps(rep))
'''

CHECK = r'''
import json, os, pathlib, sys, time
out = pathlib.Path(sys.argv[2])
time.sleep(4)                                  # give a surviving late writer time to act
rep = {}
for m in MARKERS + [os.path.join(os.environ['HOME'], 'kvprobe'),
                    os.path.join(os.environ['TMPDIR'], 'kvprobe'), 'kvprobe_cwd']:
    rep['found:' + m] = os.path.exists(m)
try:
    from multiprocessing import shared_memory
    shared_memory.SharedMemory(name='kvprobe_shm')
    rep['found:shm'] = True
except Exception:
    rep['found:shm'] = False
others = []
for d in os.listdir('/proc'):
    if d.isdigit() and int(d) != os.getpid():
        try:
            if os.stat('/proc/' + d).st_uid == os.getuid():
                others.append(int(d))
        except OSError:
            pass
rep['found:other_processes'] = bool(others)
try:
    open('/tests/scoring_config.json').read(); rep['read_tests_config'] = True
except Exception:
    rep['read_tests_config'] = False
(out / 'report.json').write_text(json.dumps(rep))
'''


def test_codec_isolation():
    vu.setup_isolation()
    header = (f'MARKERS = {MARKERS!r}\nSTORE = {str(vu.store_dir())!r}\n'
              f'RUNS = {str(vu.GRADE_BASE / "runs")!r}\n')
    with tempfile.TemporaryDirectory(prefix='kv_iso_', dir=vu.store_dir()) as td:
        td = pathlib.Path(td)
        codec = pathlib.Path(tempfile.mkdtemp(prefix='probe_', dir=vu._runs_dir()))
        try:
            os.chmod(codec, 0o755)
            (codec / 'encode.py').write_text(header + PLANT)
            (codec / 'decode.py').write_text(header + CHECK)
            for f in codec.iterdir():
                os.chmod(f, 0o644)
            inp = td / 'in'
            inp.mkdir()
            (inp / 'dummy.pos.npy').write_bytes(b'\0' * 16)

            vu.run_codec('encode', inp, td / 'o1', 60, codec_dir=codec)
            plant = json.loads((td / 'o1' / 'report.json').read_text())
            vu.run_codec('decode', inp, td / 'o2', 60, codec_dir=codec)
            check = json.loads((td / 'o2' / 'report.json').read_text())
        finally:
            shutil.rmtree(codec, ignore_errors=True)

    for key in ('read_tests_config', 'list_tests_hidden', 'list_grader_store', 'list_grader_runs',
                'write_codec_dir', 'write_tests'):
        assert plant[key] is False, f'isolation broken: probe could {key}'
    # the probe must have been able to plant at least the private and world-writable traces,
    # otherwise the second half of the test proves nothing
    assert plant['plant:/tmp/kvprobe_marker'] and plant['plant:shm'], plant
    leaked = sorted(k for k, v in check.items() if v)
    assert not leaked, f'isolation broken: second call saw {leaked}'
