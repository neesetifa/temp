#!/bin/bash
# Run the grading test, then write /logs/verifier/reward.txt from metrics.json (0 on any failure).
LOG=/logs/verifier
mkdir -p "$LOG"
rm -f "$LOG/reward.txt" "$LOG/metrics.json"
# Grader-only paths: the codec runs as an unprivileged uid (see verifier_utils.run_codec).
chmod 700 /tests
[ -d /solution ] && chmod 700 /solution
cd /tests
python -m pytest -q -p no:cacheprovider /tests/test_smoke.py /tests/test_isolation.py /tests/test_main.py
status=$?
python - "$status" << 'PY'
import json, math, pathlib, sys
log = pathlib.Path('/logs/verifier')
reward = 0.0
if sys.argv[1] == '0':
    try:
        r = float(json.loads((log / 'metrics.json').read_text())['reward'])
        if math.isfinite(r) and 0.0 <= r <= 1.0:
            reward = r
    except Exception:
        pass
(log / 'reward.txt').write_text(f'{reward:.12f}\n')
PY
exit $status
