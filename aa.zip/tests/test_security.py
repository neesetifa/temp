from __future__ import annotations

import os
import pathlib
import tempfile
import textwrap
import uuid

import pytest

from verifier_utils import ARTIFACT_LIMIT, artifact_size_and_validate, run_predict


@pytest.mark.linux_isolation
def test_external_solve_phase_state_is_not_visible():
    """A tiny submitted predictor must not be able to read state left outside /output."""
    secret = b'OE_EXTERNAL_STATE_MUST_NOT_BE_VISIBLE_7f93a1\n'
    name = 'oe_external_' + uuid.uuid4().hex
    candidates = [pathlib.Path(p) / name for p in ('/tmp', '/var/tmp', '/workspace', str(pathlib.Path.home()))]
    if os.geteuid() == 0:
        candidates.append(pathlib.Path('/') / name)

    created = []
    try:
        for p in candidates:
            try:
                p.write_bytes(secret)
                p.chmod(0o644)
                created.append(p)
            except OSError:
                pass
        assert created, 'security regression could not create any external-state fixture'

        with tempfile.TemporaryDirectory(prefix='oe_external_artifact_') as ad, tempfile.TemporaryDirectory(prefix='oe_external_io_') as iod:
            artifact = pathlib.Path(ad)
            io = pathlib.Path(iod)
            in_csv = io / 'in.csv'
            out_csv = io / 'out.csv'
            in_csv.write_text('query_id,history,gaps_days\nq,1,0\n', encoding='utf-8')
            literals = repr([str(p) for p in created])
            predictor = f'''import pathlib,sys\nSECRET={secret!r}\nPATHS={literals}\nvisible=[]\nfor raw in PATHS:\n    try:\n        if pathlib.Path(raw).read_bytes()==SECRET: visible.append(raw)\n    except OSError:\n        pass\nif visible:\n    pathlib.Path(sys.argv[2]).write_text("prediction\\nLEAKED\\n",encoding="utf-8")\n    raise SystemExit(0)\nprint("EXTERNAL_STATE_BLOCKED",file=sys.stderr)\nraise SystemExit(91)\n'''
            (artifact / 'predict.py').write_text(predictor, encoding='utf-8')

            with pytest.raises(AssertionError) as exc:
                run_predict(in_csv, out_csv, timeout=10, artifact_root=artifact)
            msg = str(exc.value)
            assert 'code 91' in msg and 'EXTERNAL_STATE_BLOCKED' in msg, msg
            assert not out_csv.exists(), 'external solve-phase state was visible to predictor'
    finally:
        for p in created:
            try:
                p.unlink()
            except OSError:
                pass


def test_filename_encoded_payload_counts_toward_budget():
    """Empty files with ~100 KB of user-controlled names must exceed 64 KiB."""
    with tempfile.TemporaryDirectory(prefix='oe_filename_payload_') as td:
        root = pathlib.Path(td)
        (root / 'predict.py').write_text('raise SystemExit(0)\n', encoding='utf-8')
        # 500 empty files x ~205 bytes/name: >100 KB of filename payload while
        # regular-file contents remain tiny.
        for i in range(500):
            name = f'{i:04d}_' + ('A' * 200)
            (root / name).touch()

        content_only = sum(p.stat().st_size for p in root.rglob('*') if p.is_file())
        assert content_only < 1024
        with pytest.raises(AssertionError, match='artifact too large'):
            artifact_size_and_validate(root)

        name_bytes = sum(
            len(os.fsencode(p.relative_to(root).as_posix())) + 1
            for p in root.rglob('*')
        )
        assert name_bytes > ARTIFACT_LIMIT


def infer(tmp_path, body, files=None, timeout=10):
    artifact = tmp_path / 'artifact'
    artifact.mkdir(exist_ok=True)
    (artifact / 'predict.py').write_text(textwrap.dedent(body), encoding='utf-8')
    for name, data in (files or {}).items():
        p = artifact / name
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_bytes(data)
    source, result = tmp_path / 'input.csv', tmp_path / 'output.csv'
    source.write_text('query_id,history,gaps_days\nq,1,0\n', encoding='utf-8')
    run_predict(source, result, timeout=timeout, artifact_root=artifact)
    return result.read_text()


@pytest.mark.linux_isolation
def test_absolute_output_and_relative_artifacts_remain_readable(tmp_path):
    template = pathlib.Path('/opt/oe-runtime')
    assert template.stat().st_uid == 0
    assert template.stat().st_mode & 0o777 == 0o700
    if os.geteuid() != 0:
        with pytest.raises(PermissionError):
            list(template.iterdir())
    assert infer(tmp_path, '''
        import pathlib, sys, os
        assert pathlib.Path('/output/model.bin').read_bytes() == b'model'
        assert pathlib.Path('nested/data.bin').read_bytes() == b'nested'
        assert pathlib.Path('/input.csv').read_text().startswith('query_id,')
        assert os.getuid() == os.geteuid() == 10002
        assert os.getgroups() == []
        assert os.getcwd() == '/output'
        pathlib.Path(sys.argv[2]).write_text('prediction\\nOK\\n')
    ''', {'model.bin': b'model', 'nested/data.bin': b'nested'}) == 'prediction\nOK\n'


@pytest.mark.linux_isolation
def test_native_reads_proc_fd_environment_and_network_are_isolated(tmp_path, monkeypatch):
    stash = tmp_path / 'outside'
    stash.write_bytes(b'EXTERNAL_PAYLOAD')
    monkeypatch.setenv('OE_SECRET', 'EXTERNAL_PAYLOAD')
    monkeypatch.setenv('PYTHONPATH', str(tmp_path))
    (tmp_path / 'sitecustomize.py').write_text('raise RuntimeError("INJECTED")')
    fd = os.open(stash, os.O_RDONLY)
    os.set_inheritable(fd, True)
    try:
        body = '''
            import ctypes, os, pathlib, socket, sys, subprocess
            libc = ctypes.CDLL(None, use_errno=True)
            assert 'OE_SECRET' not in os.environ
            assert 'PYTHONPATH' not in os.environ
            assert not pathlib.Path('/proc').exists()
            for path in PATHS:
                assert libc.open(os.fsencode(path), 0) == -1, path
            # Raw native socket calls bypass all Python-level audit hooks.
            for family in (socket.AF_INET, socket.AF_INET6, socket.AF_UNIX):
                assert libc.socket(family, socket.SOCK_STREAM, 0) == -1
            # System V IPC, process memory and namespace APIs must be unavailable.
            assert libc.shmget(0x123456, 1, 0o1666) == -1
            assert libc.ptrace(0, 0, 0, 0) == -1
            assert libc.unshare(0x10000000) == -1
            assert libc.setsid() == -1
            assert libc.setpgid(0, 0) == -1
            assert libc.chroot(b'/') == -1
            assert libc.setuid(0) == -1
            for n in range(3, 256):
                try: os.fstat(n)
                except OSError: pass
                else: raise AssertionError('inherited fd: ' + str(n))
            # Exec/fork retain the filter and independent root.
            subprocess.run(['/bin/sh', '-c', 'test ! -r "$1"', 'sh', PATHS[0]], check=True)
            for path in ('/output/model.bin', '/usr/local/bin/python3'):
                try: open(path, 'wb')
                except OSError: pass
                else: raise AssertionError('writable trusted data')
            pathlib.Path(sys.argv[2]).write_text('OK')
        '''
        paths = [str(stash), '/proc/self/root' + str(stash),
                 '/proc/1/root' + str(stash), '/proc/self/fd/' + str(fd),
                 '/app/train.csv', '/tests/test.csv', '/var/lib/oe-inference',
                 '/output/../../' + str(stash).lstrip('/')]
        body = textwrap.dedent(body).replace('PATHS', repr(paths))
        assert infer(tmp_path, body, {'model.bin': b'model'}) == 'OK'
    finally:
        os.close(fd)


@pytest.mark.linux_isolation
@pytest.mark.image_build_only
def test_numpy_pandas_scipy_sklearn_and_threads(tmp_path):
    # This validates the immutable inference runtime, not a submission.  Keep it
    # out of the per-submission grading path: cold native imports can vary
    # substantially across hosts.  Image-build/CI may spend the full inference
    # allowance without turning host startup variance into a contestant zero.
    assert infer(tmp_path, '''
        import pathlib, sys, threading
        import numpy as np, pandas as pd, scipy.sparse as sp
        from sklearn.preprocessing import normalize
        import joblib
        a = np.array([[3., 4.]])
        assert np.allclose(normalize(a), [[.6, .8]])
        assert sp.csr_matrix(a).sum() == 7
        assert pd.read_csv(sys.argv[1]).shape == (1, 3)
        values = []
        t = threading.Thread(target=lambda: values.append(1))
        t.start(); t.join()
        assert values == [1]
        pathlib.Path('/tmp/cache').write_text('fresh')
        pathlib.Path('/var/tmp/cache').write_text('fresh')
        pathlib.Path.home().joinpath('cache').write_text('fresh')
        pathlib.Path(sys.argv[2]).write_text('OK')
    ''', timeout=60) == 'OK'


@pytest.mark.linux_isolation
def test_fresh_filesystem_every_call(tmp_path):
    code = '''
        import pathlib, sys
        for raw in ('/tmp/stash', '/var/tmp/stash', '/home/sandbox/stash', '/dev/shm/stash'):
            p = pathlib.Path(raw)
            assert not p.exists()
            p.write_text('state from previous inference')
        pathlib.Path(sys.argv[2]).write_text('OK')
    '''
    assert infer(tmp_path, code) == infer(tmp_path, code) == 'OK'


@pytest.mark.linux_isolation
@pytest.mark.parametrize('kind', ['symlink', 'fifo', 'missing', 'directory'])
def test_result_entry_cannot_trick_root_supervisor(tmp_path, kind):
    with pytest.raises(AssertionError, match='inference isolation'):
        infer(tmp_path, f'''
            import os, sys
            kind = {kind!r}
            if kind == 'symlink': os.symlink('/etc/shadow', sys.argv[2])
            if kind == 'fifo': os.mkfifo(sys.argv[2])
            if kind == 'directory': os.mkdir(sys.argv[2])
        ''')


@pytest.mark.linux_isolation
def test_timeout_and_descendants_do_not_hold_result_pipe_open(tmp_path):
    with pytest.raises(AssertionError, match='timed out'):
        infer(tmp_path, 'while True: pass', timeout=0.2)
    pid = int(infer(tmp_path, '''
        import os, pathlib, sys, time
        pid = os.fork()
        if pid == 0:
            time.sleep(30)
            os._exit(0)
        pathlib.Path(sys.argv[2]).write_text(str(pid))
    '''))
    with pytest.raises(ProcessLookupError):
        os.kill(pid, 0)


@pytest.mark.linux_isolation
def test_canonical_metadata_visible_inside_inference(tmp_path):
    assert infer(tmp_path, '''
        import os, pathlib, stat, sys
        for p in pathlib.Path('/output').rglob('*'):
            st = p.stat()
            assert stat.S_IMODE(st.st_mode) == 0o555
            assert st.st_uid == st.st_gid == 0
            assert st.st_mtime_ns == 0
            if p.is_file(): assert st.st_nlink == 1
        pathlib.Path(sys.argv[2]).write_text('OK')
    ''', {'model.bin': b'model', 'nested/data': b'data'}) == 'OK'
