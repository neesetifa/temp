#!/usr/bin/env python3
"""Hidden evaluation for fewshot_expert_consolidation.

The candidate delivers only a weights file (/app/merged.npz); no candidate code is executed.
The file is treated as untrusted input: it must be a regular file (no symlink, <= 20 MB), a zip/npz
whose REQUIRED arrays (scoring.SHAPES) are plain float arrays of the exact shapes, finite, and not
pickled.  Any other members of the archive are ignored and never read or decompressed.
Any violation -> reward 0.
"""
import json
import os
import shutil
import sys
import zipfile

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from scoring import SHAPES, raw_metrics, reward_from_raw  # noqa: E402

APP = os.environ.get("FEC_APP_DIR", "/app")
LOGDIR = os.environ.get("FEC_LOG_DIR", "/logs/verifier")
HIDDEN = os.path.join(HERE, "hidden", "hidden_test.npz")
ANCHORS = os.path.join(HERE, "hidden", "anchors.json")
MAX_FILE = 20 * 1024 * 1024  # bytes on disk
MAX_MEMBER = 2 * 1024 * 1024  # uncompressed bytes per REQUIRED array (largest legit one is ~31 KB)


def load_candidate(path):
    if os.path.islink(path) or not os.path.isfile(path):
        raise ValueError("merged.npz missing or not a regular file")
    if os.path.getsize(path) > MAX_FILE:
        raise ValueError("merged.npz too large")
    fd = os.open(path, os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0))
    with os.fdopen(fd, "rb") as fh:
        raw = fh.read(MAX_FILE + 1)
    import io
    bio = io.BytesIO(raw)
    with zipfile.ZipFile(bio) as zf:
        names = set(zf.namelist())
        for k in SHAPES:  # only the required members are inspected; extra members are ignored
            if k + ".npy" not in names:
                raise ValueError(f"missing array {k}")
            if zf.getinfo(k + ".npy").file_size > MAX_MEMBER:
                raise ValueError(f"array {k} too large")
    bio.seek(0)
    m = {}
    with np.load(bio, allow_pickle=False) as d:
        for k, shape in SHAPES.items():
            if k not in d.files:
                raise ValueError(f"missing array {k}")
            a = d[k]
            if a.dtype.kind != "f" or a.shape != shape:
                raise ValueError(f"array {k}: dtype {a.dtype} shape {a.shape}, expected float {shape}")
            a = a.astype(np.float64)
            if not np.isfinite(a).all():
                raise ValueError(f"array {k} has non-finite values")
            m[k] = a
    return m


def write_out(reward, metrics):
    os.makedirs(LOGDIR, exist_ok=True)
    for fn in ("metrics.json", "reward.txt"):
        p = os.path.join(LOGDIR, fn)
        if os.path.lexists(p):
            if os.path.isdir(p) and not os.path.islink(p):
                shutil.rmtree(p)
            else:
                os.unlink(p)
    with open(os.path.join(LOGDIR, "metrics.json"), "w") as f:
        json.dump(metrics, f, indent=1)
    with open(os.path.join(LOGDIR, "reward.txt"), "w") as f:
        f.write(f"{reward:.6f}\n")


def main():
    if os.geteuid() == 0:
        os.chmod(HERE, 0o700)
    try:
        m = load_candidate(os.path.join(APP, "merged.npz"))
    except Exception as e:  # malformed / missing deliverable -> 0
        write_out(0.0, {"error": f"{type(e).__name__}: {e}"[:2000], "reward": 0.0})
        print("invalid deliverable:", e)
        return
    with np.load(HIDDEN, allow_pickle=False) as d:
        H = {k: d[k] for k in d.files}
    anchors = json.load(open(ANCHORS))
    raw = raw_metrics(m, H)
    reward, det = reward_from_raw(raw, anchors)
    write_out(reward, {"reward": reward, "R": det["R"], "R1": det["R1"], "ratios": det["ratios"],
                       "per_task_diagnostic": det["per_task_diagnostic"], "raw": raw})
    print(json.dumps({"reward": round(reward, 4), "R": round(det["R"], 4), "R1": round(det["R1"], 4),
                      "kl_ratio_to_zero_point": {k: round(v, 4) for k, v in det["ratios"].items()},
                      "mean_kl": {k: round(v["mean_kl"], 5) for k, v in raw.items()}}, indent=1))


if __name__ == "__main__":
    main()
