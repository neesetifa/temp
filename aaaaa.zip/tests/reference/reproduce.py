#!/usr/bin/env python3
"""Reproduce the two scoring references of fewshot_expert_consolidation and score them.

    python3 reproduce.py zero                    # zero point (L0):  ~1 min
    python3 reproduce.py oracle                  # top reference:    300k steps, ~35 min on 2 cores
    python3 reproduce.py oracle --steps 30000    # quick check of the top of the scale, ~4 min
    options: --out merged.npz (where to write the model)

Both references run the SAME procedure and differ only in where the distillation inputs come from:

  init     : best "aligned task arithmetic" model -- each expert's hidden units are permuted to match
             the base (weight matching, Hungarian), trunk = base + lam * sum_k (expert_k - base),
             lam picked from {0.1,0.15,0.2,0.3,0.5} by mean KL on the 64 visible inputs; heads = the
             (aligned) expert heads.
  training : Adam (lr 1e-3, cosine decay to 0), batch 128 inputs per task per step, loss = mean over
             tasks of KL(expert_k(x) || merged head k(x)), all parameters trained, rng seed 1.
  inputs   : zero   -> the 64 visible inputs of task k, resampled with replacement, + N(0, 0.3^2) noise;
                       8,000 steps.
             oracle -> fresh samples from task k's TRUE input distribution (input_generator.npz, the
                       hidden generator that also produced the visible and the hidden test inputs);
                       300,000 steps.

What the top reference knows that a solver does not: only the true input distribution of each
task (unlimited fresh samples).  It has no labels, no expert training data, no extra capacity and
no other information; it uses the same base, experts and 64 visible inputs a solver gets.

With the numpy version the references were built with (2.5.3) the zero point reproduces exactly;
other numpy/BLAS builds give slightly different floating-point paths (expect +-0.01 on the reward).
"""
import argparse
import json
import math
import os
import sys
import time

import numpy as np
from scipy.optimize import linear_sum_assignment

HERE = os.path.dirname(os.path.abspath(__file__))
TESTS = os.path.dirname(HERE)
sys.path.insert(0, TESTS)
from scoring import raw_metrics, reward_from_raw  # noqa: E402

K, C, H, D, Q, M_COMP, N_VIS = 6, 10, 64, 48, 6, 4, 64
TRUNK = ["W1", "b1", "W2", "b2", "W3", "b3"]


# ------------------------------------------------------------------ data
def load_npz(p):
    with np.load(p, allow_pickle=False) as d:
        return {k: d[k] for k in d.files}


def load_inputs():
    base = load_npz(os.path.join(HERE, "data", "base.npz"))
    experts = []
    for k in range(K):
        e = load_npz(os.path.join(HERE, "data", f"expert_{k}.npz"))
        e["HW"], e["Hb"] = e.pop("head_W")[None], e.pop("head_b")[None]
        experts.append(e)
    u = load_npz(os.path.join(HERE, "data", "unlabeled_inputs.npz"))
    vis = [u[f"task_{k}"] for k in range(K)]
    return base, experts, vis


# ------------------------------------------------------------------ hidden input generator
GEN = load_npz(os.path.join(HERE, "input_generator.npz"))


def sample_task(k, n, rng):
    m = int(GEN["MAN_OF_TASK"][k])
    comp = rng.choice(M_COMP, n, p=GEN[f"m{m}_w"])
    e = rng.normal(0, 1, (n, Q))
    scale = np.sqrt(4.0 / rng.chisquare(4, n))[:, None]  # student-t(4) scale mixing
    z = GEN[f"m{m}_mu"][comp] + np.einsum("nq,nqr->nr", e * scale, GEN[f"m{m}_L"][comp])
    h = np.tanh(z @ GEN[f"m{m}_A1"] + GEN[f"m{m}_c1"])
    h = np.tanh(h @ GEN[f"m{m}_B1"] + GEN[f"m{m}_c2"])
    return h @ GEN[f"m{m}_A2"] + GEN[f"m{m}_off"] + 0.05 * rng.normal(0, 1, (n, D))


# ------------------------------------------------------------------ model
def trunk(p, x):
    h1 = np.maximum(x @ p["W1"] + p["b1"], 0)
    h2 = np.maximum(h1 @ p["W2"] + p["b2"], 0)
    h3 = np.maximum(h2 @ p["W3"] + p["b3"], 0)
    return h1, h2, h3


def logits(p, x, k):
    return trunk(p, x)[2] @ p["HW"][k] + p["Hb"][k]


def log_softmax(z):
    z = z - z.max(1, keepdims=True)
    return z - np.log(np.exp(z).sum(1, keepdims=True))


def softmax(z):
    z = z - z.max(1, keepdims=True)
    e = np.exp(z)
    return e / e.sum(1, keepdims=True)


def kl_rows(pt, ls):
    return (pt * (np.log(np.maximum(pt, 1e-30)) - log_softmax(ls))).sum(1)


def grad(p, x, k, target):
    h1, h2, h3 = trunk(p, x)
    HWk = p["HW"][k]
    z = np.einsum("nh,nhc->nc", h3, HWk) + p["Hb"][k]
    ls = log_softmax(z)
    n = len(x)
    dz = (np.exp(ls) - target) / n
    g = {}
    gHW, gHb = np.zeros_like(p["HW"]), np.zeros_like(p["Hb"])
    for kk in np.unique(k):
        m = k == kk
        gHW[kk] = h3[m].T @ dz[m]
        gHb[kk] = dz[m].sum(0)
    g["HW"], g["Hb"] = gHW, gHb
    dh3 = np.einsum("nc,nhc->nh", dz, HWk) * (h3 > 0)
    g["W3"], g["b3"] = h2.T @ dh3, dh3.sum(0)
    dh2 = (dh3 @ p["W3"].T) * (h2 > 0)
    g["W2"], g["b2"] = h1.T @ dh2, dh2.sum(0)
    dh1 = (dh2 @ p["W2"].T) * (h1 > 0)
    g["W1"], g["b1"] = x.T @ dh1, dh1.sum(0)
    return g


class Adam:
    def __init__(self, p, lr=1e-3, b1=0.9, b2=0.999):
        self.m = {k: np.zeros_like(v) for k, v in p.items()}
        self.v = {k: np.zeros_like(v) for k, v in p.items()}
        self.t, self.lr, self.b1, self.b2 = 0, lr, b1, b2

    def step(self, p, g, lr):
        self.t += 1
        c1, c2 = 1 - self.b1 ** self.t, 1 - self.b2 ** self.t
        for k, gk in g.items():
            self.m[k] = self.b1 * self.m[k] + (1 - self.b1) * gk
            self.v[k] = self.b2 * self.v[k] + (1 - self.b2) * gk * gk
            p[k] -= lr * (self.m[k] / c1) / (np.sqrt(self.v[k] / c2) + 1e-8)


# ------------------------------------------------------------------ initialization
def apply_perm(p, pis):
    q = dict(p)
    q["W1"], q["b1"] = p["W1"][:, pis[0]], p["b1"][pis[0]]
    q["W2"], q["b2"] = p["W2"][pis[0]][:, pis[1]], p["b2"][pis[1]]
    q["W3"], q["b3"] = p["W3"][pis[1]][:, pis[2]], p["b3"][pis[2]]
    q["HW"] = p["HW"][:, pis[2], :]
    return q


def align_to(ref, p, iters=5):
    """weight matching: permute p's hidden units to match ref (coordinate descent over layers)."""
    pis = [np.arange(H) for _ in range(3)]
    for _ in range(iters):
        for l in range(3):
            Win_p = p[f"W{l+1}"] if l == 0 else p[f"W{l+1}"][pis[l - 1]]
            S = ref[f"W{l+1}"].T @ Win_p + np.outer(ref[f"b{l+1}"], p[f"b{l+1}"])
            if l < 2:
                S += ref[f"W{l+2}"] @ p[f"W{l+2}"][:, pis[l + 1]].T
            _, col = linear_sum_assignment(-S)
            pis[l] = col
    return apply_perm(p, pis)


def init_model(base, experts, vis):
    Ea = [align_to(base, e) for e in experts]
    best = None
    for lam in [0.1, 0.15, 0.2, 0.3, 0.5]:
        s = {kk: base[kk] + lam * sum(e[kk] - base[kk] for e in Ea) for kk in TRUNK}
        s["HW"] = np.stack([e["HW"][0] for e in Ea])
        s["Hb"] = np.stack([e["Hb"][0] for e in Ea])
        v = np.mean([kl_rows(softmax(logits(experts[k], vis[k], 0)), logits(s, vis[k], k)).mean() for k in range(K)])
        if best is None or v < best[0]:
            best = (v, lam, s)
    print(f"init: aligned task arithmetic, lam={best[1]}, visible-input KL {best[0]:.4f}", flush=True)
    return best[2]


# ------------------------------------------------------------------ distillation
def distill(student, experts, sampler, steps, rng, bs=128, lr=1e-3):
    opt = Adam(student, lr=lr)
    heads = np.repeat(np.arange(K), bs)
    t0 = time.time()
    for t in range(steps):
        xs = [sampler(k, bs, rng) for k in range(K)]
        target = np.concatenate([softmax(logits(experts[k], xs[k], 0)) for k in range(K)])
        cur = lr * 0.5 * (1 + np.cos(np.pi * t / steps))
        opt.step(student, grad(student, np.concatenate(xs), heads, target), cur)
        if (t + 1) % max(1, steps // 10) == 0:
            print(f"  step {t+1}/{steps}  ({time.time() - t0:.0f}s)", flush=True)
    return student


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("which", choices=["zero", "oracle"])
    ap.add_argument("--steps", type=int, default=None)
    ap.add_argument("--out", default=None)
    a = ap.parse_args()
    base, experts, vis = load_inputs()
    if a.which == "zero":
        steps = a.steps or 8000
        sampler = lambda k, n, rng: vis[k][rng.integers(0, N_VIS, n)] + 0.3 * rng.normal(0, 1, (n, D))
    else:
        steps = a.steps or 300000
        sampler = sample_task
    student = distill(init_model(base, experts, vis), experts, sampler, steps, np.random.default_rng(1))
    out = a.out or os.path.join(os.getcwd(), f"reference_{a.which}_{steps}.npz")
    np.savez(out, **{k: student[k] for k in TRUNK + ["HW", "Hb"]})
    print("wrote", out)

    with np.load(os.path.join(TESTS, "hidden", "hidden_test.npz"), allow_pickle=False) as d:
        Hd = {k: d[k] for k in d.files}
    anchors = json.load(open(os.path.join(TESTS, "hidden", "anchors.json")))
    raw = raw_metrics(student, Hd)
    reward, det = reward_from_raw(raw, anchors)
    ref_key = "L0" if a.which == "zero" else "oracle"
    print(f"\n{'task':8s} {'mean KL':>10s} {'anchors.json ' + ref_key:>20s}")
    for k in range(K):
        t = f"task_{k}"
        print(f"{t:8s} {raw[t]['mean_kl']:10.6f} {anchors['groups'][t][ref_key]:20.6f}")
    print(f"\nreward = {reward:.4f}   (R = {det['R']:.4f}, R1 = {det['R1']:.4f}; "
          f"zero point should give 0, the 300k-step oracle {anchors.get('_expected_oracle_reward')})")


if __name__ == "__main__":
    main()
