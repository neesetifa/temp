# Scoring references: how they were produced, and how to check them

This directory is on the grading side only (agents never see `tests/`). Grading does not use it.
It exists so a reviewer can rebuild both ends of the reward scale and check them.

| file | what |
|---|---|
| `reproduce.py` | rebuilds the zero point or the top reference from scratch and scores it with the grader's own `scoring.py` |
| `input_generator.npz` | the hidden input generator: per-manifold parameters of the latent mixture and the 2-layer tanh embedding, plus which manifold each task uses. This is what produced the 64 visible inputs, the hidden test inputs, and the top reference's training inputs |
| `data/` | copies of the base, the 6 experts and the 64 visible inputs per task, identical to `environment/app/data`, so this does not depend on the graded `/app` |

## What the two references are

Both use the **same procedure** and differ only in the distillation inputs.

1. **Init**: align every expert's hidden units to the base (weight matching with the Hungarian
   algorithm, 5 sweeps). Trunk = base + λ·Σ_k(expert_k − base), with λ chosen from
   {0.1, 0.15, 0.2, 0.3, 0.5} by mean KL on the 64 visible inputs (λ = 0.2 wins). Heads = the
   aligned expert heads.
2. **Distillation**: Adam, lr 1e-3 with cosine decay to 0, 128 inputs per task per step, loss =
   KL(expert_k ‖ merged head k) averaged over tasks, all parameters trained, `default_rng(1)`.
3. **Inputs**:
   - **zero point** (`anchors.json` → `L0`): the task's 64 visible inputs, resampled with
     replacement, plus N(0, 0.3²) noise per coordinate; 8,000 steps.
   - **top reference** (`anchors.json` → `oracle`, shipped as `solution/merged.npz`): fresh
     samples from the task's true input distribution (`input_generator.npz`); 300,000 steps.

**What the top reference knows that a solver does not**: only each task's true input distribution,
i.e. unlimited fresh unlabeled inputs. It has no labels, no expert training data and no extra
capacity, and it uses exactly the base, experts and visible inputs a solver gets. Its remaining
error (mean KL ≈ 0.0047) comes from finite capacity and optimization. It is not an upper bound
on what is achievable, which is why the 1-point is set at 0.8 × reference.

## Reproducing

```bash
cd /tests/reference            # or wherever tests/ is unpacked; needs numpy + scipy
python3 reproduce.py zero                      # ~1 min
python3 reproduce.py oracle --steps 30000      # quick check of the top of the scale, ~5 min
python3 reproduce.py oracle                    # full 300k-step reference, ~35-50 min on 2 cores
```

Each run writes the model and prints per-task mean KL next to the value in `anchors.json`, plus the
reward under the grader's scoring. Measured with numpy 2.5.3 (the build environment):

| run | reward | match with anchors.json |
|---|---|---|
| `zero` | 0.000 | bit-identical (all 6 per-task KLs and all weights equal the shipped zero-point model) |
| `oracle --steps 30000` | 0.803 | shorter schedule, so per-task KL is 1.3–1.5× the 300k reference (0.0036 / 0.0051 / 0.0146 / 0.0078 / 0.0039 / 0.0043); 285 s on one core |
| `oracle` (300k) | 0.917 | bit-identical (all 6 per-task KLs and all weights equal `solution/merged.npz`); ~45 min on one core |

With a different numpy/BLAS build the floating-point path changes slightly, so expect agreement
to within about ±0.01 reward rather than bit-identity.

## Scoring (for reference; implemented in `../scoring.py`)

r_k = L_k / L0_k, R = mean_k r_k, R1 = mean_k(0.8·ref_k / L0_k),
reward = clip(log(1/R) / log(1/R1), 0, 1). The arithmetic mean of ratios lets one broken head
dominate (an oracle with one head zeroed scores 0; copying one expert for every task scores 0),
while for balanced solutions the reward is the usual log-scale position between the two references.
