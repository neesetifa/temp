"""Regression test for the verifier's handling of untrusted deliverables.

    python3 /tests/test_security.py      (or: pytest -q /tests/test_security.py)

No candidate code is ever executed; the only attack surface is /app/merged.npz and the log dir.
Every malformed / hostile deliverable must give reward 0 without crashing the verifier, and a
pre-planted symlink at the reward path must not redirect the write.  A valid file must still score,
also when it carries extra (even large) arrays, which the verifier must ignore.
"""
import io
import json
import os
import pickle
import shutil
import subprocess
import sys
import tempfile
import zipfile

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from scoring import SHAPES  # noqa: E402


def _valid(rng):
    return {k: rng.normal(0, 0.1, s) for k, s in SHAPES.items()}


def _save(path, arrays):
    np.savez(path, **arrays)


def _cases(rng):
    v = _valid(rng)
    cases = {}
    cases["missing_key"] = lambda p: _save(p, {k: a for k, a in v.items() if k != "W2"})
    cases["wrong_shape"] = lambda p: _save(p, dict(v, W1=np.zeros((48, 65))))
    cases["int_dtype"] = lambda p: _save(p, dict(v, b1=np.zeros(64, dtype=np.int64)))
    cases["nan"] = lambda p: _save(p, dict(v, W3=np.full((64, 64), np.nan)))
    cases["huge_values"] = lambda p: _save(p, dict(v, W1=np.full((48, 64), 1e200)))

    def obj(p):  # pickled object array inside the npz
        buf = io.BytesIO()
        np.save(buf, np.array([{"x": 1}], dtype=object), allow_pickle=True)
        with zipfile.ZipFile(p, "w") as zf:
            for k, a in v.items():
                b = io.BytesIO()
                np.save(b, a)
                zf.writestr(k + ".npy", b.getvalue())
            zf.writestr("W1.npy", buf.getvalue())
    cases["pickled_object"] = obj

    def raw_pickle(p):
        with open(p, "wb") as f:
            pickle.dump(v, f)
    cases["raw_pickle"] = raw_pickle

    def bomb(p):  # 400 MB of zeros, compresses to < 1 MB
        with zipfile.ZipFile(p, "w", zipfile.ZIP_DEFLATED) as zf:
            hdr = io.BytesIO()
            np.lib.format.write_array_header_1_0(hdr, {"descr": "<f8", "fortran_order": False, "shape": (50_000_000,)})
            zf.writestr("W1.npy", hdr.getvalue() + b"\0" * 400_000_000)
    cases["zip_bomb"] = bomb
    cases["symlink_to_hidden"] = lambda p: os.symlink(os.path.join(HERE, "hidden", "hidden_test.npz"), p)
    cases["directory"] = lambda p: os.mkdir(p)
    cases["missing_file"] = lambda p: None
    return cases, v


def _with_extra_big_array(p, valid):
    """valid model + an extra 3 MB array: extras must be ignored, file still scored."""
    np.savez(p, **valid, extra_notes=np.zeros(3 * 1024 * 1024 // 8))


def _run(app, logdir):
    env = dict(os.environ, FEC_APP_DIR=app, FEC_LOG_DIR=logdir)
    r = subprocess.run([sys.executable, os.path.join(HERE, "hidden_eval.py")], env=env, capture_output=True, text=True)
    assert r.returncode == 0, f"verifier crashed: {r.stderr[-2000:]}"
    return float(open(os.path.join(logdir, "reward.txt")).read())


def test_malformed_deliverables_score_zero():
    rng = np.random.default_rng(0)
    cases, valid = _cases(rng)
    tmp = tempfile.mkdtemp(prefix="fec_sec_")
    try:
        for name, make in cases.items():
            app, logdir = os.path.join(tmp, name, "app"), os.path.join(tmp, name, "logs")
            os.makedirs(app)
            make(os.path.join(app, "merged.npz"))
            r = _run(app, logdir)
            assert r == 0.0, f"{name}: reward {r}"
            assert "error" in json.load(open(os.path.join(logdir, "metrics.json"))) or name == "huge_values", name
        # extra arrays (even large ones) are ignored, the required ones are still scored
        app, logdir = os.path.join(tmp, "extra", "app"), os.path.join(tmp, "extra", "logs")
        os.makedirs(app)
        _with_extra_big_array(os.path.join(app, "merged.npz"), valid)
        _run(app, logdir)
        m = json.load(open(os.path.join(logdir, "metrics.json")))
        assert "raw" in m and "error" not in m, f"extra array was not ignored: {m.get('error')}"
        # valid file + planted symlink at reward path -> verifier writes a real file, target untouched
        app, logdir = os.path.join(tmp, "ok", "app"), os.path.join(tmp, "ok", "logs")
        os.makedirs(app)
        os.makedirs(logdir)
        target = os.path.join(tmp, "victim.txt")
        open(target, "w").write("untouched")
        os.symlink(target, os.path.join(logdir, "reward.txt"))
        _save(os.path.join(app, "merged.npz"), valid)
        _run(app, logdir)
        assert not os.path.islink(os.path.join(logdir, "reward.txt"))
        assert open(target).read() == "untouched"
        m = json.load(open(os.path.join(logdir, "metrics.json")))
        assert "raw" in m and all(np.isfinite(v["mean_kl"]) for v in m["raw"].values())
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


if __name__ == "__main__":
    test_malformed_deliverables_score_zero()
    print("security test passed")
