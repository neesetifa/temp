#!/usr/bin/env python3
"""Offline re-scoring of finished runs with (possibly updated) anchors -- no re-running needed.

    python3 rescore.py metrics1.json [metrics2.json ...] [--anchors anchors.json]
                       [--set-best-agent]   # write per-task best observed agent mean_kl into anchors.json

metrics*.json are the files hidden_eval.py writes to /logs/verifier/metrics.json.
"""
import argparse
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from scoring import reward_from_raw  # noqa: E402


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("metrics", nargs="+")
    ap.add_argument("--anchors", default=os.path.join(HERE, "hidden", "anchors.json"))
    ap.add_argument("--set-best-agent", action="store_true")
    a = ap.parse_args()
    anchors = json.load(open(a.anchors))
    runs = []
    for p in a.metrics:
        m = json.load(open(p))
        if "raw" not in m:
            print(f"{p}: no raw metrics (invalid deliverable) -> 0")
            continue
        runs.append((p, m["raw"]))
    if a.set_best_agent and runs:
        for g in anchors["groups"]:
            anchors["groups"][g]["best_agent"] = min(r[g]["mean_kl"] for _, r in runs)
        json.dump(anchors, open(a.anchors, "w"), indent=1)
        print(f"updated best_agent in {a.anchors}")
    for p, raw in runs:
        r, det = reward_from_raw(raw, anchors)
        print(f"{r:.4f}  {p}  R={det['R']:.4f}  ratios: " + " ".join(f"{v:.3f}" for v in det["ratios"].values()))


if __name__ == "__main__":
    main()
