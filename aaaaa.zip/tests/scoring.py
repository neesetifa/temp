"""Scoring math shared by hidden_eval.py, rescore.py and reference/reproduce.py.

Reward (v0.2):
  r_k = L_k / L0_k          L_k  = mean KL(expert_k || merged head k) on task k's hidden inputs
                            L0_k = zero-point reference for task k (anchors.json)
  R   = mean_k r_k          arithmetic mean of the ratios -> dominated by the worst head
  R1  = mean_k (0.8 * ref_k / L0_k),  ref_k = min(oracle_k, best_agent_k)
  reward = clip( log(1/R) / log(1/R1), 0, 1 )

A single broken head makes R large and the reward ~0; for balanced solutions (all r_k similar)
the reward is the usual log-scale position between the zero point and 0.8 x the reference, so
balanced partial solutions keep their order.  Per-task scores are reported for diagnostics only.
"""
import math

import numpy as np

K = 6
SHAPES = {"W1": (48, 64), "b1": (64,), "W2": (64, 64), "b2": (64,), "W3": (64, 64), "b3": (64,),
          "HW": (6, 64, 10), "Hb": (6, 10)}


def log_softmax(z):
    z = z - z.max(1, keepdims=True)
    return z - np.log(np.exp(z).sum(1, keepdims=True))


def merged_logits(m, x, k):
    h = np.maximum(x @ m["W1"] + m["b1"], 0)
    h = np.maximum(h @ m["W2"] + m["b2"], 0)
    h = np.maximum(h @ m["W3"] + m["b3"], 0)
    return h @ m["HW"][k] + m["Hb"][k]


def raw_metrics(m, H):
    """Per-task mean KL(expert || merged) and agreement on the hidden inputs (anchor independent)."""
    out = {}
    with np.errstate(all="ignore"):
        for k in range(K):
            x, p = H[f"x_{k}"], H[f"p_{k}"]
            z = merged_logits(m, x, k)
            if not np.isfinite(z).all():
                out[f"task_{k}"] = {"mean_kl": float("inf"), "agreement": 0.0}
                continue
            lt = np.log(np.maximum(p, 1e-30))
            klv = (p * (lt - log_softmax(z))).sum(1)
            out[f"task_{k}"] = {"mean_kl": float(klv.mean()) if np.isfinite(klv).all() else float("inf"),
                                "p90_kl": float(np.percentile(klv, 90)) if np.isfinite(klv).all() else float("inf"),
                                "agreement": float((p.argmax(1) == z.argmax(1)).mean())}
    return out


def _ref(g):
    return g["oracle"] if g.get("best_agent") is None else min(g["oracle"], g["best_agent"])


def per_task_score(L, L0, L1):
    """Diagnostic only (not used in the reward): single-task log-scale position, clipped to [0,1]."""
    if not np.isfinite(L) or L >= L0:
        return 0.0
    if L <= L1:
        return 1.0
    return float(math.log(L0 / L) / math.log(L0 / L1))


def reward_from_raw(raw, anchors):
    """Returns (reward, details).  details has R, R1, per-task ratios and per-task diagnostic scores."""
    g = anchors["groups"]
    ratios, diag = {}, {}
    for k in range(K):
        t = f"task_{k}"
        L = raw[t]["mean_kl"]
        ratios[t] = L / g[t]["L0"] if np.isfinite(L) else float("inf")
        diag[t] = per_task_score(L, g[t]["L0"], 0.8 * _ref(g[t]))
    R = float(np.mean(list(ratios.values())))
    R1 = float(np.mean([0.8 * _ref(g[f"task_{k}"]) / g[f"task_{k}"]["L0"] for k in range(K)]))
    if not np.isfinite(R) or R >= 1.0:
        reward = 0.0
    elif R <= R1:
        reward = 1.0
    else:
        reward = float(math.log(1.0 / R) / math.log(1.0 / R1))
    return reward, {"R": R, "R1": R1, "ratios": ratios, "per_task_diagnostic": diag}
