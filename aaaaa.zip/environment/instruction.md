# Consolidate six experts into one model, with almost no data

You are given a pretrained **base** network and six **expert** networks, one per task
(`/app/data/expert_{0..5}.npz`). Each expert was fine-tuned from the base on its own private
labelled dataset. Deployment can only afford **one** network of the base's size, so your job is to
build a single **merged model**: one shared trunk with six task heads that reproduces every
expert's predictions as faithfully as possible.

## Architecture

Base, experts and the merged model share the same trunk shape (see `/app/mlp.py`):

```
x (48) -> ReLU(x W1 + b1) (64) -> ReLU(. W2 + b2) (64) -> ReLU(. W3 + b3) (64) = h
expert k : logits = h @ head_W + head_b                      (10 classes)
merged   : logits_k = h @ HW[k] + Hb[k]   for task k = 0..5    (one trunk, six heads)
```

The experts started from the base, but not all from the same parameterization. Some of them were
fine-tuned from a copy of the base whose hidden units had been permuted (a functionally identical
network with reordered neurons), so their weights are not directly aligned with the base or with
each other.

## Data

| file | content |
|---|---|
| `data/base.npz` | base trunk (`W1 b1 W2 b2 W3 b3`) |
| `data/expert_{k}.npz` | expert k: trunk + `head_W (64,10)`, `head_b (10,)` |
| `data/unlabeled_inputs.npz` | `task_{k}`: **64 unlabeled inputs** for each task, drawn i.i.d. from that task's input distribution |

There are no labels and no other data. Each task has its own unknown input distribution over R^48.
The 64 samples are the only data you have from it, but you can run the experts (and the base) on
any input you like.

`mlp.py` has loaders, the forward pass, the KL loss, a gradient for the merged model and Adam, all
in numpy. You may install and use anything else, e.g. torch. `make_merged.py` is a working but weak
starter (naive weight averaging). `evaluate.py` reports the score formula below on the 64 visible
inputs. That number is optimistic if you train on those inputs, so hold some out for an honest
estimate. `tests/test_public.py` checks the deliverable format.

## Deliverable

Write **`/app/merged.npz`** containing these float arrays:
`W1 (48,64) b1 (64,) W2 (64,64) b2 (64,) W3 (64,64) b3 (64,) HW (6,64,10) Hb (6,10)`, all finite.
Any other arrays in the file are ignored (never read). The file as a whole must be a regular file
of at most 20 MB. `mlp.save_merged()` writes the right format. Only this file is graded; none of
your code is run at grading time, so you can spend your own session's compute on producing it.

## Grading

For each task k, the grader draws 3,000 fresh hidden inputs from task k's true input distribution
(the same distribution your 64 samples came from) and computes the mean
**L_k = KL(expert_k(x) ‖ merged head k(x))** over the softmax outputs.

Two hidden references fix the scale. Both run the same procedure: start from the base with the
experts' hidden units aligned to it and their task vectors added (scaled), then distill all six
experts into the merged model with Adam. They differ only in the inputs used for distillation:

- **zero point** (L0_k): your 64 visible inputs per task plus Gaussian input noise (σ = 0.3),
  8,000 steps;
- **top reference** (ref_k): unlimited fresh samples from each task's *true* input distribution,
  300,000 steps. That distribution is the only thing it knows that you don't. It has no labels,
  no expert training data and no other information, and it uses the same base, experts and
  64 inputs you have.

The tasks are combined so that every head matters. Let r_k = L_k / L0_k and R = mean_k r_k (an
arithmetic mean, so one bad head dominates). Then

    reward = clip( log(1/R) / log(1/R1), 0, 1 ),   R1 = mean_k (0.8 · ref_k / L0_k)

So the reward is 0 at the zero point or worse, and 1 when you are clearly better than the top
reference. One badly broken head (for example an untrained or zeroed head, or a single expert
copied for all tasks) pushes R far above 1 and the reward to 0. The reward is continuous; there is
no pass/fail. A missing or malformed file (missing required arrays, wrong shapes or dtypes,
NaN/inf, pickled objects, a symlink, more than 20 MB) gets reward 0.
