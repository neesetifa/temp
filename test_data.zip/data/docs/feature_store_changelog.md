# Feature store / risk platform changelog (excerpt)

**2026-06-29** — `txn-risk-v7` trained (auths Mar 16 – May 20, chargebacks as of Jun 30).
Thresholds set on June traffic.

**2026-07-01** — `txn-risk-v7` deployed with policy `v7-default` (single global review / decline
threshold). Decline holdout re-enabled: 2% of would-be declines are approved and logged with
`policy_path = decline_holdout`, so their outcomes can be observed.

**2026-07-06** — Model refresh paused for the FS2 migration (feature store v4). Feature definitions
unchanged; serving moved to the new store.

**2026-08-22 / 08-23** — Warehouse partition re-load: parts of these two days were loaded twice into
`auth_extract`. Duplicates are exact copies (same `txn_id`). Not fixed in the table.

**2026-09-04 / 09-05** — FX rate feed outage. `amount_usd` was not logged for non-USD authorizations
on these days (`amount_local`/`currency` are correct). The decision service scored those auths with
the field missing.

**2026-10-02 – 10-04** — Email-intelligence vendor outage. `email_age_days` null for all auths.

**2026-10-15** — Device SDK v3 rollout, wave 1 (merchants with `sdk_v3_migration_date` in
`reference/merchants.csv`). v3 uses a new device identifier, so `device_age_days` and
`device_distinct_cards_24h` restart from the merchant's migration date — returning customers look
like new devices for a while. Wave 2 is **scheduled for Oct 28 – Nov 5** (dates per merchant in the
same file).

**2026-10-19** — Decline-rate alert: v7 decline rate up several-fold since Oct 15, concentrated on
merchants migrated in SDK v3 wave 1 (RISK-2291). No policy change during the release freeze; to be
addressed in the Oct 26 release.

**2026-10-20** — Review ops staffing plan for Q4 confirmed (`config/review_ops.json`), unchanged from
Q3.

**2026-10-23** — FS2 migration complete; model release train resumes with the Oct 26 release.
