# Feature catalog — `txn_features_v4` (logged at authorization time)

Every authorization is scored on this vector. Values are the ones the feature store served to the
decision service at auth time (point-in-time); the warehouse extract logs them as-is. Missing values
are empty cells (the decision service passes them to the model as NaN).

| # | feature | type | definition |
|---|---|---|---|
| 0 | `amount_usd` | float | auth amount converted to USD with the FX snapshot of the auth hour |
| 1 | `hour_local` | int 0–23 | hour of day in the card holder's local time (from IP geolocation) |
| 2 | `is_weekend` | 0/1 | Saturday/Sunday (UTC date) |
| 3 | `vertical` | enum | merchant vertical, derived from MCC: 0 digital_goods, 1 electronics, 2 fashion, 3 travel, 4 food_delivery, 5 subscriptions, 6 marketplace, 7 home_goods |
| 4 | `region` | enum | merchant region: 0 NA, 1 EU, 2 LATAM, 3 APAC |
| 5 | `channel_app` | 0/1 | 1 = in-app checkout, 0 = web |
| 6 | `is_recurring` | 0/1 | merchant-initiated recurring charge |
| 7 | `card_type` | enum | 0 credit, 1 debit, 2 prepaid |
| 8 | `card_age_days` | float | days since the card was first seen on our network |
| 9 | `card_txn_count_24h` | int | auths on this card in the trailing 24h (incl. this one) |
| 10 | `card_distinct_merchants_24h` | int | distinct merchants for the card in the trailing 24h |
| 11 | `card_decline_count_24h` | int | declines (any reason, incl. issuer) for the card in trailing 24h |
| 12 | `bin_risk_90d` | float | fraud-coded chargeback rate of the card's BIN over the trailing 90 days (chargebacks received) |
| 13 | `ip_bin_country_mismatch` | 0/1 | IP country differs from card issuing country |
| 14 | `avs_result` | enum | 0 match, 1 partial, 2 no match, 3 unavailable (AVS only in US/CA/UK-issued flows we support: NA merchants) |
| 15 | `cvv_match` | 0/1 | CVV2 check passed |
| 16 | `device_present` | 0/1 | device SDK payload present (merchant integrated the SDK and the call succeeded) |
| 17 | `device_age_days` | float | days since the device id was first seen (null without SDK payload) |
| 18 | `device_distinct_cards_24h` | int | distinct cards on the device in trailing 24h (null without SDK payload) |
| 19 | `emulator_flag` | 0/1 | SDK detected emulator / instrumented runtime (null without SDK payload) |
| 20 | `ip_proxy_score` | float 0–1 | vendor proxy/VPN/hosting likelihood for the IP |
| 21 | `billing_distance_km` | float | distance between IP geolocation and billing address |
| 22 | `email_age_days` | float | email-intelligence vendor: age of the email address (null if vendor has no record or call failed) |
| 23 | `email_domain_risk` | float 0–1 | vendor risk score of the email domain |
| 24 | `account_age_days` | float | age of the shopper's merchant account (null for guest checkout) |
| 25 | `prev_orders` | int | prior successful orders of the account at this merchant (null for guest checkout) |
| 26 | `new_shipping_address` | 0/1 | shipping address not used before by the account (null for non-physical goods) |
| 27 | `shipping_billing_match` | 0/1 | shipping address equals billing address (null for non-physical goods) |
| 28 | `amount_vs_card_avg` | float | amount / the card's average amount at our merchants over 90 days (null if no history) |
| 29 | `merchant_age_days` | int | days since the merchant went live |
| 30 | `merchant_cb_rate_90d` | float | fraud-coded chargebacks received in the trailing 90 days / auths in the same period (null for merchants live < 60 days) |

Notes
- Rate features (`bin_risk_90d`, `merchant_cb_rate_90d`) count chargebacks by **received** date,
  so they lag the underlying fraud by the chargeback delay.
- See `feature_store_changelog.md` for incidents and definition changes.
