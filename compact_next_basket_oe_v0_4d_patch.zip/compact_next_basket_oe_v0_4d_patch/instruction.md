# Compact novel next-basket recommendation

`/app/train.csv` contains real purchase histories derived from UCI Online Retail II. Each row is one training customer: an ordered basket history plus the items in that customer's next basket that had **not appeared anywhere in the visible history**.

Build `/output/predict.py`.

It will be called as:

```bash
python /output/predict.py <in.csv> <out.csv>
```

`<in.csv>` has these columns:

```text
query_id,history,gaps_days
```

`history` is a sequence of baskets. Baskets are separated by `|`; item IDs inside a basket are separated by spaces. The last basket in `history` is the most recent observed basket. `gaps_days` contains one non-negative day gap per history basket, in the same order.

Write `<out.csv>` with exactly one column named `prediction`. Each row must contain exactly **10 distinct item IDs**, separated by single spaces, best recommendation first. Output rows must correspond to input rows in the same order.

The held-out label contains only **novel** next-basket items: items already present in that customer's visible history receive no credit. Held-out customers with no novel item in their next basket are not part of evaluation.

The complete `/output` artifact is limited to **64 KiB (65,536 bytes)**. The verifier meters regular-file contents **and** filesystem-encoded relative path/name bytes (plus one entry byte per file or directory), so filenames/directories cannot carry unmetered state. Extended attributes, symlinks, and other special files are not allowed. Final inference runs in an isolated filesystem view: only the submitted `/output` artifact is carried from the solve phase; files left in `/tmp`, `/var/tmp`, `/app`, home directories, or other solve-phase locations are not available to `predict.py`.

Inference preserves artifact names and contents, with fixed read-only permissions and timestamps. Absolute paths such as `/output/model.bin` are supported. Temporary directories start fresh for each call; network access and access to other processes are unavailable. Python and the image's installed numerical libraries are provided by a trusted runtime.

The held-out customers are disjoint from the customers in `/app/train.csv`. Their visible histories are supplied only through `<in.csv>` at evaluation time. The predictor cannot access `/app/train.csv` during final evaluation, so any cross-customer statistics or learned model state needed at inference time must fit inside `/output`.

Training columns are:

```text
query_id,history,gaps_days,target_items
```

`target_items` contains only the next-basket items that are novel relative to that training customer's visible history. IDs are opaque remapped identifiers; do not infer meaning from their numeric values.

The score is based on how highly hidden novel next-basket items appear in each held-out customer's top-10 ranking. A train-derived global novel-item popularity recommender, filtered to remove items already seen by each customer, is the score floor. The useful part of the task is deciding which cross-customer item relationships or compressed representations are worth encoding under the artifact-size limit.

Keep the submission deterministic. Reordering input rows must only reorder the corresponding outputs.
