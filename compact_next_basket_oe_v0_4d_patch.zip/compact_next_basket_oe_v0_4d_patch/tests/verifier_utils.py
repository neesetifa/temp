from __future__ import annotations

import base64
import csv
import errno
import json
import math
import os
import pathlib
import stat
import subprocess

ARTIFACT_LIMIT = 65_536
OUTPUT_DIR = pathlib.Path('/output')
PREDICT = OUTPUT_DIR / 'predict.py'
TEST_DIR = pathlib.Path(__file__).resolve().parent
CATALOG_PATH = TEST_DIR / 'catalog.csv'


def snapshot_artifact(root=OUTPUT_DIR):
    """Read a bounded, descriptor-relative snapshot; never reopen paths to copy.

    Only entry type, relative name and bytes cross the inference boundary.
    O_NOFOLLOW at *every* component prevents rename/symlink races from reaching
    external files. Reads are bounded even when a regular file grows mid-read.
    """
    root = pathlib.Path(root)
    flags = os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_NONBLOCK
    entries = []
    total = 0

    def no_xattrs(fd):
        if not hasattr(os, 'listxattr'):
            raise AssertionError('artifact validation requires extended-attribute inspection')
        try:
            attrs = os.listxattr(fd)
        except OSError as exc:
            if exc.errno in (errno.ENOTSUP, errno.EOPNOTSUPP):
                return
            raise
        if attrs:
            raise AssertionError('extended attributes not allowed in /output')

    def walk(fd, prefix):
        nonlocal total
        no_xattrs(fd)
        # Do not build an unbounded rglob/sorted list before enforcing the budget.
        with os.scandir(fd) as children:
            for child in children:
                name = os.fsencode(child.name)
                rel = prefix + name
                total += len(rel) + 1
                if total > ARTIFACT_LIMIT:
                    raise AssertionError('artifact too large: names exceed 65536 bytes')
                st = os.stat(child.name, dir_fd=fd, follow_symlinks=False)
                if not (stat.S_ISDIR(st.st_mode) or stat.S_ISREG(st.st_mode)):
                    raise AssertionError('symlink or special file not allowed in /output')
                child_flags = os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK
                if stat.S_ISDIR(st.st_mode):
                    child_flags |= os.O_DIRECTORY
                cfd = os.open(child.name, child_flags, dir_fd=fd)
                try:
                    actual = os.fstat(cfd)
                    if (st.st_dev, st.st_ino, st.st_mode) != (actual.st_dev, actual.st_ino, actual.st_mode):
                        raise AssertionError('artifact changed during snapshot')
                    no_xattrs(cfd)
                    if stat.S_ISDIR(actual.st_mode):
                        entries.append(('d', rel, b''))
                        walk(cfd, rel + b'/')
                    else:
                        remaining = ARTIFACT_LIMIT - total
                        if actual.st_size > remaining:
                            raise AssertionError('artifact too large: contents exceed 65536 bytes')
                        with os.fdopen(os.dup(cfd), 'rb') as f:
                            data = f.read(remaining + 1)
                        total += len(data)
                        if total > ARTIFACT_LIMIT:
                            raise AssertionError('artifact too large: contents exceed 65536 bytes')
                        entries.append(('f', rel, data))
                finally:
                    os.close(cfd)

    try:
        fd = os.open(root, flags)
        try:
            walk(fd, b'')
        finally:
            os.close(fd)
    except (OSError, RecursionError) as exc:
        raise AssertionError(f'cannot snapshot /output safely: {exc}') from exc
    return total, sorted(entries, key=lambda e: e[1])


def artifact_size_and_validate(root=OUTPUT_DIR):
    return snapshot_artifact(root)[0]


def load_catalog():
    with CATALOG_PATH.open(newline='', encoding='utf-8') as f:
        r = csv.DictReader(f)
        if r.fieldnames != ['item_id']:
            raise AssertionError('invalid verifier catalog')
        out = {str(row['item_id']).strip() for row in r}
    if len(out) < 10:
        raise AssertionError('catalog too small')
    return out


SANDBOX_HELPER = '/usr/local/libexec/oe-infer'
MAX_IO_BYTES = 64 * 1024 * 1024


def run_predict(input_csv, output_csv, timeout=60, artifact_root=OUTPUT_DIR):
    _, entries = snapshot_artifact(artifact_root)
    if not any(kind == 'f' and name == b'predict.py' and data for kind, name, data in entries):
        raise AssertionError('/output/predict.py missing or empty')
    if not 0 < timeout <= 60:
        raise AssertionError('inference timeout must be in (0, 60] seconds')
    with open(input_csv, 'rb') as f:
        input_data = f.read(MAX_IO_BYTES + 1)
    if len(input_data) > MAX_IO_BYTES:
        raise AssertionError('input CSV exceeds inference transport limit')
    request = {
        'version': 1, 'timeout': timeout,
        'artifact': [[k, base64.b64encode(n).decode('ascii'), base64.b64encode(d).decode('ascii')]
                     for k, n, d in entries],
        'input': base64.b64encode(input_data).decode('ascii'),
    }
    try:
        cp = subprocess.run(
            [SANDBOX_HELPER], input=json.dumps(request).encode('ascii'),
            stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            cwd='/', env={'PATH': '/usr/local/bin:/usr/bin:/bin', 'LANG': 'C.UTF-8'},
            close_fds=True, timeout=timeout + 30,
        )
    except FileNotFoundError as exc:
        raise AssertionError('inference isolation unavailable: install the image-built oe-infer helper') from exc
    except subprocess.TimeoutExpired as exc:
        raise AssertionError('inference isolation supervisor timed out') from exc
    if cp.returncode:
        raise AssertionError('inference isolation failed: ' + cp.stderr.decode('utf-8', 'replace')[-4000:])
    try:
        result = json.loads(cp.stdout)
        if result['status'] != 'ok':
            raise AssertionError(result['error'])
        data = base64.b64decode(result['output'], validate=True)
        if len(data) > MAX_IO_BYTES:
            raise ValueError('oversized result')
    except (KeyError, ValueError, TypeError) as exc:
        raise AssertionError('invalid inference supervisor response') from exc
    pathlib.Path(output_csv).write_bytes(data)


def parse_predictions(output_csv, expected_rows, catalog):
    with output_csv.open(newline='', encoding='utf-8') as f:
        r = csv.DictReader(f)
        if r.fieldnames != ['prediction']:
            raise AssertionError('output must have exactly one column named prediction')
        rows = list(r)
    if len(rows) != expected_rows:
        raise AssertionError(f'wrong row count: {len(rows)} != {expected_rows}')
    out = []
    for i, row in enumerate(rows):
        toks = str(row['prediction']).strip().split()
        if len(toks) != 10:
            raise AssertionError(f'row {i}: exactly 10 item IDs required')
        if len(set(toks)) != 10:
            raise AssertionError(f'row {i}: item IDs must be distinct')
        bad = [x for x in toks if x not in catalog]
        if bad:
            raise AssertionError(f'row {i}: unknown item IDs {bad[:3]}')
        out.append(tuple(toks))
    return out


def write_input(path, rows):
    with path.open('w', newline='', encoding='utf-8') as f:
        w = csv.writer(f)
        w.writerow(['query_id', 'history', 'gaps_days'])
        for r in rows:
            w.writerow([r[0], r[1], r[2]])


def ndcg_at_10(pred, target):
    if not target:
        return 0.0
    dcg = sum(1 / math.log2(rank + 1) for rank, item in enumerate(pred, 1) if item in target)
    k = min(10, len(target))
    idcg = sum(1 / math.log2(rank + 1) for rank in range(1, k + 1))
    return dcg / idcg if idcg else 0.0
