"""Use real Darwin xattr syscalls for portable unit tests on macOS.

CPython exposes os.listxattr only on Linux. This test-only adapter exercises
actual file-descriptor xattrs; production still fails closed without that API.
Darwin's automatically added com.apple.provenance is omitted in this adapter
only. User xattrs are inspected unchanged. This is not Linux deployment proof.
It does not emulate or skip the Linux isolation tests.
"""
import ctypes
import os
import sys

import pytest


@pytest.fixture(autouse=True)
def darwin_xattrs(monkeypatch):
    if sys.platform != 'darwin':
        return
    libc = ctypes.CDLL(None, use_errno=True)
    libc.flistxattr.argtypes = [ctypes.c_int, ctypes.c_void_p, ctypes.c_size_t, ctypes.c_int]
    libc.listxattr.argtypes = [ctypes.c_char_p, ctypes.c_void_p, ctypes.c_size_t, ctypes.c_int]
    libc.setxattr.argtypes = [ctypes.c_char_p, ctypes.c_char_p, ctypes.c_void_p,
                             ctypes.c_size_t, ctypes.c_uint32, ctypes.c_int]
    libc.flistxattr.restype = libc.listxattr.restype = ctypes.c_ssize_t

    def checked(rc):
        if rc < 0:
            err = ctypes.get_errno()
            raise OSError(err, os.strerror(err))
        return rc

    def listxattr(path, *, follow_symlinks=True):
        fn = libc.flistxattr if isinstance(path, int) else libc.listxattr
        arg = path if isinstance(path, int) else os.fsencode(path)
        flags = 0 if follow_symlinks else 1
        size = checked(fn(arg, None, 0, flags))
        if not size:
            return []
        buf = ctypes.create_string_buffer(size)
        n = checked(fn(arg, buf, size, flags))
        return [os.fsdecode(x) for x in buf.raw[:n].split(b'\0')
                if x and x != b'com.apple.provenance']

    def setxattr(path, key, value):
        checked(libc.setxattr(os.fsencode(path), os.fsencode(key), value, len(value), 0, 0))

    monkeypatch.setattr(os, 'listxattr', listxattr, raising=False)
    monkeypatch.setattr(os, 'setxattr', setxattr, raising=False)
