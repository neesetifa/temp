#!/bin/bash
set +e
mkdir -p /logs/verifier
python - <<'PY'
import pathlib,time
pathlib.Path('/logs/verifier/.start_time').write_text(str(time.time()))
PY
cd /tests
python -m pytest -q -p no:cacheprovider test_artifact_security.py test_security.py test_smoke.py test_schema.py test_main.py
status=$?
python /tests/finalize_artifacts.py
exit $status
