# Inference isolation and deployment

This patch changes execution isolation, artifact accounting and their tests. It
does not change the dataset, target, ranking metric, reward normalization,
calibration anchor or model objective.

## Boundary

`run_predict` reads a descriptor-relative snapshot of `/output`. Every directory
and regular file costs `len(os.fsencode(relative_path)) + 1` bytes; regular file
contents are added to that sum. The inclusive limit is 65,536 bytes. Symlinks,
special files and extended attributes (including ACL xattrs) are rejected. Reads
and traversal are bounded while accounting, not after constructing an unlimited
file list. `O_NOFOLLOW` protects each traversed component. The exact bytes that
were accounted are sent to inference; files are not reopened after validation.
Concurrent writes may change the captured bytes, but cannot add unmetered data
to that immutable snapshot. Stop solve processes before verification for
reproducible submissions and to protect the verifier itself from same-UID
interference.

The fixed, image-installed `/usr/local/libexec/oe-infer` is the only privileged
entrypoint. It accepts no arguments, discards inherited environment and extra
descriptors, and executes only the root-owned supervisor with Python `-I -S`.
The supervisor independently validates the bounded names/content protocol,
including paths and the 64 KiB budget. It never receives a host pathname to read
or write on behalf of a caller.

Each invocation creates an independent root filesystem in a root-only spool.
Runtime code comes from `/opt/oe-runtime`, captured at **image build time**, not
from directories exposed during solving. Runtime files are copied, not shared
through hardlinks or bind mounts. The runtime template root is mode 0700, so
solve processes cannot even encode state through its descendants' access times.
The only solve-produced state imported is the
metered artifact. `/output` files and directories have fixed modes and times;
ownership, xattrs, hardlink topology, source inodes and executable bits are not
preserved. Names and file contents remain readable, including absolute paths
such as `/output/model.bin`. All artifact files are executable/readable with
mode 0555, so helper executables need no extra permission bit in the protocol.

Before running `predict.py`, the child enters that root with `chroot`, changes
its cwd to `/output`, clears supplementary groups, becomes reserved UID/GID
10002, clears capabilities and sets `no_new_privs`. No external directory FD
survives exec. The runtime contains no `/proc`, verifier data or solve workspace.
Only fixed null/zero/random/urandom devices and fresh temporary/work directories
are provided. A default-deny libseccomp filter also applies to native extensions,
`ctypes`, raw syscalls, execs and descendants. Socket, System V IPC, ptrace,
process-memory, handle-based file access, io_uring and namespace APIs are absent
from the allowlist. `clone3` returns ENOSYS for libc's ordinary clone fallback;
namespace flags and CLONE_PARENT are forbidden. Threads and subprocesses may
run, but cannot change session/process group or signal other processes.

The root supervisor kills the whole prediction process group on completion or
timeout, opens results with `O_NOFOLLOW`/`O_NONBLOCK`, and accepts only a bounded
regular file with one link. Submitted code never runs as root. Python audit
hooks are not used as an enforcement boundary. Chroot by itself would be
insufficient without privilege removal, descriptor hygiene and syscall limits.

## Deployment contract

Use the supplied Dockerfile. Solve and verifier run as `oeagent` (UID 10001);
`oeinfer` (UID 10002) is reserved for inference. Image/runtime/helper paths must
remain root-owned and not be overlaid with solve-writable mounts. The verifier
and its results must be protected by the evaluation harness, and all solve-time
processes must be stopped before evaluation. A solver that can modify the
verifier or image, or run as root, is outside this boundary.

This backend requires Linux >= 5.9 (`close_range`), libseccomp2, a suid-enabled
helper filesystem, and the usual container capabilities CHOWN, DAC_OVERRIDE,
FOWNER, SETUID, SETGID, SYS_CHROOT and MKNOD. The container supervisor must not
start with `no-new-privileges`; the predictor itself always sets it. No
`--privileged`, SYS_ADMIN, user namespace, mount namespace, `unshare` or runtime
mount is needed. Missing privileges or unsupported syscalls fail closed.
Successful portable tests alone do **not** establish deployment compatibility.

If deployment also prohibits setuid/chroot, this backend cannot meet the stated
contract there. The harness must instead execute the same metered snapshot in
a fresh, independently managed container/VM built from the trusted image. Do
not replace this with an audit-hook filter or unrestricted same-filesystem
fallback. This is a deployment requirement, not a change to the OE objective.

Input/result transport is bounded to 64 MiB each, independently of the 64 KiB
artifact budget. Per-file output/log size, open descriptors, process count and
CPU time are bounded. Inference keeps the existing 60-second maximum; request
read and setup/cleanup add at most 30 seconds to the caller deadline. Runtime
copying must fit inside the setup deadline and needs temporary disk space.
Container-level memory/storage/PID limits remain necessary for resource abuse.
The boundary does not claim to eliminate timing/hardware covert channels or
kernel vulnerabilities.

## Verification

On a Linux Docker host, from this task directory:

```sh
sh author_tools/check_isolation.sh
```

This builds the `isolation` stage without requiring dataset materialization,
then runs all accounting and execution tests as `oeagent`. It repeats them with
namespace/mount syscalls explicitly denied, and checks fail-closed behavior
under `no-new-privileges` and missing SYS_CHROOT. Linux tests never skip because
isolation is unavailable. Run this gate on the **actual deployment profile**
before accepting a release; no deployment pass is claimed by this source patch.

For portable accounting/protocol development only:

```sh
python -m pytest -q -p no:cacheprovider tests/test_artifact_security.py tests/test_security.py -m 'not linux_isolation'
```

The macOS test adapter uses real Darwin xattr calls and ignores its automatically
added `com.apple.provenance` attribute only in tests. Linux production validation
rejects all xattrs. This adapter neither implements nor simulates Linux isolation.

`tests/test.sh` runs both security suites before the original scoring tests.
`pre_review.py` includes isolation overhead in its timeout envelope. A complete
benchmark review still needs the materialized dataset, catalog, scoring files,
baseline and calibration producer, which are not included in this patch-only
directory.

Security API references: [chroot(2)](https://man7.org/linux/man-pages/man2/chroot.2.html),
[seccomp(2)](https://man7.org/linux/man-pages/man2/seccomp.2.html), and
[Docker runtime capabilities](https://docs.docker.com/engine/containers/run/).
