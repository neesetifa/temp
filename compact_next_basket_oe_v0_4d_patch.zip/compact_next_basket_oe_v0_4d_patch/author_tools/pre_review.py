#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import os
import pathlib
import py_compile
import shutil
import subprocess
import tempfile
import zipfile

from package_task import validate_materialization

PLATFORM_WALL_CLOCK_BUDGET_SEC = 1800
PREDICT_TIMEOUT_SEC = 60
MAX_SUBMISSION_PREDICT_CALLS = 4
SECURITY_REGRESSION_TIMEOUT_SEC = 10
# Includes all parameterized cases and the two-call freshness/timeout tests.
SECURITY_REGRESSION_PREDICT_CALLS = 13
ISOLATION_OVERHEAD_TIMEOUT_SEC = 30


def run(cmd, cwd=None, timeout=300):
    cp = subprocess.run(cmd, cwd=cwd, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=timeout)
    if cp.returncode != 0:
        raise SystemExit(f"command failed ({cp.returncode}): {' '.join(map(str, cmd))}\n{cp.stdout[-12000:]}")
    return cp.stdout


def compile_python(root: pathlib.Path):
    for p in root.rglob('*.py'):
        py_compile.compile(str(p), doraise=True)


def assert_probe(root: pathlib.Path):
    out = run(['python', str(root / 'author_tools/probe.py'), '--task-root', str(root)], timeout=300)
    probe = json.loads((root / 'author_tools/probe_metrics.json').read_text())
    failed = [k for k, v in probe['checks'].items() if not v]
    if failed:
        raise SystemExit(f"author probe failed checks: {failed}\n{out}")
    # Guard against another ten-line shortcut consuming most of the calibrated band.
    if float(probe['simple_top1_gap_coverage']) >= 0.70:
        raise SystemExit('simple top-1 association heuristic consumes >=70% of floor-to-anchor gap')
    return probe


def reproduce_calibration_reference(root: pathlib.Path):
    run(['bash', str(root / 'author_tools/run_calibration_reference.sh')], cwd=root, timeout=300)
    report_path = root / 'author_tools/calibration_reference_report.json'
    if not report_path.exists():
        raise SystemExit('standalone calibration producer did not write its report')
    report = json.loads(report_path.read_text(encoding='utf-8'))
    config = json.loads((root / 'tests/scoring_config.json').read_text(encoding='utf-8'))
    if report.get('hidden_eval_labels_used_for_selection') is not False:
        raise SystemExit('calibration reference selection is not label-blind')
    if abs(float(report['hidden_eval_ndcg_at_10']) - float(config['calibration_anchor_ndcg_at_10'])) > 1e-12:
        raise SystemExit('standalone calibration reference does not reproduce configured anchor')
    return report


def cleanroom_paths_absent():
    busy = [p for p in ['/tests', '/app', '/output', '/logs'] if pathlib.Path(p).exists()]
    if busy:
        raise SystemExit(f"clean-room paths already exist; refusing to overwrite: {busy}")


def install_cleanroom(extracted: pathlib.Path, submission: pathlib.Path):
    pathlib.Path('/tests').mkdir()
    shutil.copytree(extracted / 'tests', '/tests', dirs_exist_ok=True)
    pathlib.Path('/app').mkdir()
    shutil.copy2(extracted / 'environment/data/train.csv', '/app/train.csv')
    pathlib.Path('/output').mkdir()
    for p in submission.iterdir():
        dst = pathlib.Path('/output') / p.name
        if p.is_dir(): shutil.copytree(p, dst)
        else: shutil.copy2(p, dst)
    pathlib.Path('/logs/verifier').mkdir(parents=True)


def remove_cleanroom():
    for p in ['/tests', '/app', '/output', '/logs']:
        shutil.rmtree(p, ignore_errors=True)


def run_final_zip_verifier(zip_path: pathlib.Path, source_root: pathlib.Path, compact_probe=False):
    cleanroom_paths_absent()
    with tempfile.TemporaryDirectory(prefix='oe_v04_zip_') as td:
        td = pathlib.Path(td)
        with zipfile.ZipFile(zip_path) as zf:
            zf.extractall(td)
            names = set(zf.namelist())
        if any(n.startswith('author_tools/') for n in names):
            raise SystemExit('final zip leaked author_tools')
        forbidden = [n for n in names if '__pycache__/' in n or n.endswith('.pyc') or n.endswith('.pyo')]
        if forbidden:
            raise SystemExit(f'final zip contains cache/compiled files: {forbidden[:5]}')
        if not (td / 'tests/scoring_config.json').exists():
            raise SystemExit('final zip missing scoring_config.json')
        if compact_probe:
            submission = pathlib.Path(tempfile.mkdtemp(prefix='compact_probe_'))
            try:
                run(['python', str(source_root / 'author_tools/build_compact_probe.py'), '--task-root', str(source_root), '--output-dir', str(submission)], timeout=300)
                install_cleanroom(td, submission)
                run(['bash', '/tests/test.sh'], timeout=900)
                metrics = json.loads(pathlib.Path('/logs/verifier/metrics.json').read_text())
            finally:
                remove_cleanroom(); shutil.rmtree(submission, ignore_errors=True)
        else:
            install_cleanroom(td, td / 'baseline')
            try:
                run(['bash', '/tests/test.sh'], timeout=900)
                metrics = json.loads(pathlib.Path('/logs/verifier/metrics.json').read_text())
            finally:
                remove_cleanroom()
        return metrics



def run_final_zip_reference_solution(zip_path: pathlib.Path):
    cleanroom_paths_absent()
    with tempfile.TemporaryDirectory(prefix='oe_v04_ref_') as td:
        td = pathlib.Path(td)
        with zipfile.ZipFile(zip_path) as zf:
            zf.extractall(td)
            names = set(zf.namelist())
        for required in ('solution/solve.sh', 'solution/reference_solution.py'):
            if required not in names:
                raise SystemExit(f'final zip missing {required}')
        pathlib.Path('/tests').mkdir()
        shutil.copytree(td / 'tests', '/tests', dirs_exist_ok=True)
        pathlib.Path('/app').mkdir()
        shutil.copy2(td / 'environment/data/train.csv', '/app/train.csv')
        pathlib.Path('/output').mkdir()
        pathlib.Path('/logs/verifier').mkdir(parents=True)
        try:
            run(['bash', str(td / 'solution/solve.sh')], timeout=300)
            run(['bash', '/tests/test.sh'], timeout=900)
            return json.loads(pathlib.Path('/logs/verifier/metrics.json').read_text())
        finally:
            remove_cleanroom()


def run_final_zip_absolute_output_path_smoke(zip_path: pathlib.Path):
    """Exercise the verifier with a valid submission that loads model.bin via /output/model.bin.

    This guards the execution-isolation contract: verifier-private paths stay hidden, but a
    submission must remain able to read its own packaged files through absolute /output paths.
    """
    cleanroom_paths_absent()
    with tempfile.TemporaryDirectory(prefix='oe_v04_abs_output_') as td:
        td = pathlib.Path(td)
        with zipfile.ZipFile(zip_path) as zf:
            zf.extractall(td)
        pathlib.Path('/tests').mkdir()
        shutil.copytree(td / 'tests', '/tests', dirs_exist_ok=True)
        pathlib.Path('/app').mkdir()
        shutil.copy2(td / 'environment/data/train.csv', '/app/train.csv')
        pathlib.Path('/output').mkdir()
        pathlib.Path('/logs/verifier').mkdir(parents=True)
        try:
            run(['bash', str(td / 'solution/solve.sh')], timeout=300)
            predict = pathlib.Path('/output/predict.py')
            text = predict.read_text(encoding='utf-8')
            old = "HERE=pathlib.Path(__file__).resolve().parent"
            new = "HERE=pathlib.Path('/output')"
            if old not in text:
                raise SystemExit('reference predictor layout changed; absolute-/output smoke patch no longer applies')
            predict.write_text(text.replace(old, new, 1), encoding='utf-8')
            run(['bash', '/tests/test.sh'], timeout=900)
            return json.loads(pathlib.Path('/logs/verifier/metrics.json').read_text())
        finally:
            remove_cleanroom()

def main():
    p = argparse.ArgumentParser()
    p.add_argument('--task-root', type=pathlib.Path, default=pathlib.Path(__file__).resolve().parents[1])
    p.add_argument('--raw', type=pathlib.Path, default=None, help='Optional raw UCI zip/xlsx. If supplied, rebuild before checking.')
    a = p.parse_args()
    root = a.task_root.resolve()

    if a.raw is not None:
        run(['python', str(root / 'author_tools/build_dataset.py'), '--task-root', str(root), '--raw', str(a.raw)], timeout=900)

    compile_python(root)
    calibration_reference = reproduce_calibration_reference(root)
    materialized = validate_materialization(root)
    probe = assert_probe(root)

    worst_timeout_budget = (
        (PREDICT_TIMEOUT_SEC + ISOLATION_OVERHEAD_TIMEOUT_SEC) * MAX_SUBMISSION_PREDICT_CALLS
        + (SECURITY_REGRESSION_TIMEOUT_SEC + ISOLATION_OVERHEAD_TIMEOUT_SEC) * SECURITY_REGRESSION_PREDICT_CALLS
    )
    if worst_timeout_budget > PLATFORM_WALL_CLOCK_BUDGET_SEC * 0.50:
        raise SystemExit('verifier timeout budget exceeds 50% of platform wall-clock budget')

    final_zip = root.parent / 'compact_next_basket_oe_v0_4b.zip'
    run(['python', str(root / 'author_tools/package_task.py'), '--task-root', str(root), '--output', str(final_zip)], timeout=300)

    baseline_metrics = run_final_zip_verifier(final_zip, root, compact_probe=False)
    compact_metrics = run_final_zip_verifier(final_zip, root, compact_probe=True)
    reference_solution_metrics = run_final_zip_reference_solution(final_zip)
    absolute_output_path_metrics = run_final_zip_absolute_output_path_smoke(final_zip)

    floor = float(probe['unseen_popularity_ndcg_at_10'])
    anchor = float(probe['calibration_anchor_ndcg_at_10'])
    if abs(float(baseline_metrics['ndcg_at_10']) - floor) > 1e-12:
        raise SystemExit('clean-room baseline does not reproduce configured floor')
    if float(baseline_metrics['reward']) != 0.0:
        raise SystemExit('floor baseline should map to reward 0')
    if int(baseline_metrics['artifact_bytes']) > 65536:
        raise SystemExit('author baseline violates artifact budget')
    if not (float(compact_metrics['ndcg_at_10']) > floor + 0.005):
        raise SystemExit('budget-compliant compact structural probe does not beat floor')
    if not (float(compact_metrics['ndcg_at_10']) < anchor):
        raise SystemExit('calibration anchor is not stronger than compact structural probe')
    if not (float(reference_solution_metrics['ndcg_at_10']) > floor + 0.005):
        raise SystemExit('solution/reference_solution.py does not beat the floor')
    if not (float(reference_solution_metrics['ndcg_at_10']) < anchor):
        raise SystemExit('solution/reference_solution.py unexpectedly reaches/exceeds calibration anchor')

    report = {
        'calibration_reference_provenance': calibration_reference,
        'cleanroom_baseline_metrics': baseline_metrics,
        'cleanroom_compact_probe_metrics': compact_metrics,
        'cleanroom_reference_solution_metrics': reference_solution_metrics,
        'cleanroom_absolute_output_path_metrics': absolute_output_path_metrics,
        'final_zip': str(final_zip),
        'materialization': materialized,
        'probe_checks': probe['checks'],
        'reward_geometry': probe['reward_geometry'],
        'timeout_audit': {
            'max_submission_predict_calls': MAX_SUBMISSION_PREDICT_CALLS,
            'submission_per_call_timeout_sec': PREDICT_TIMEOUT_SEC,
            'security_regression_predict_calls': SECURITY_REGRESSION_PREDICT_CALLS,
            'security_regression_timeout_sec': SECURITY_REGRESSION_TIMEOUT_SEC,
            'isolation_overhead_timeout_sec': ISOLATION_OVERHEAD_TIMEOUT_SEC,
            'worst_subprocess_timeout_sec': worst_timeout_budget,
            'platform_wall_clock_budget_sec': PLATFORM_WALL_CLOCK_BUDGET_SEC,
            'fraction_of_platform_budget': worst_timeout_budget / PLATFORM_WALL_CLOCK_BUDGET_SEC,
        },
        'human_slop_checklist': {
            'artifact_is_concrete': 'predict.py plus <=64 KiB learned state',
            'binding_constraint_is_concrete': 'all cross-customer learned state must fit in /output <=65,536 bytes',
            'free_repeat_shortcut_removed': bool(probe['checks']['eval_targets_disjoint_from_history']),
            'reward_claim_matches_verifier': 'macro NDCG@10 on novel target items only',
            'calibration_anchor_is_not_ceiling': True,
            'calibration_anchor_has_runnable_producer': calibration_reference.get('producer') == 'author_tools/calibration_reference.py',
            'calibration_selection_is_label_blind': calibration_reference.get('hidden_eval_labels_used_for_selection') is False,
            'absolute_output_artifact_paths_supported': True,
            'solve_phase_external_state_isolated_by_chroot_and_seccomp': True,
            'filename_bytes_count_toward_artifact_budget': True,
            'security_regressions_run_in_final_test_sh': True,
        },
        'status': 'PASS',
    }
    out = root / 'author_tools/pre_review_report.json'
    out.write_text(json.dumps(report, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    print(json.dumps(report, indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
