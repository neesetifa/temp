#!/usr/bin/env python3
"""Build an author-only compact association submission for pre-review probing.

This is not shipped in the final task and is not a reference solution. It is a
budget-compliant structural probe used to verify that learned cross-item state
can beat the unseen-popularity floor while remaining below the full-memory
calibration anchor.
"""
from __future__ import annotations

import argparse
import os
import pathlib
import struct
from collections import Counter, defaultdict

import pandas as pd

SENTINEL = 65535
K = 4


def parse_history(s):
    return [[int(x) for x in b.split()] for b in str(s).split("|") if str(b).strip()]


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--task-root", type=pathlib.Path, default=pathlib.Path(__file__).resolve().parents[1])
    p.add_argument("--output-dir", type=pathlib.Path, required=True)
    a = p.parse_args()
    root = a.task_root
    out = a.output_dir
    out.mkdir(parents=True, exist_ok=True)

    tr = pd.read_csv(root / "environment/data/train.csv")
    catalog = pd.read_csv(root / "tests/catalog.csv")["item_id"].astype(int).tolist()
    nslots = max(catalog) + 1
    if nslots >= SENTINEL:
        raise SystemExit("compact probe assumes uint16 item ids")

    src_count = Counter()
    target_pop = Counter()
    assoc = defaultdict(Counter)
    for r in tr.itertuples(index=False):
        seen = {x for b in parse_history(r.history) for x in b}
        target = {int(x) for x in str(r.target_items).split()}
        src_count.update(seen)
        target_pop.update(target)
        for s in seen:
            for t in target:
                assoc[s][t] += 1

    pop = [x for x, _ in target_pop.most_common()]
    pop += [x for x in catalog if x not in set(pop)]
    table = [[SENTINEL] * K for _ in range(nslots)]
    for s, counts in assoc.items():
        vals = []
        for t, n in counts.items():
            score = n / ((max(1, src_count[s]) * max(1, target_pop[t])) ** 0.5)
            vals.append((score, t))
        vals.sort(key=lambda z: (-z[0], z[1]))
        for j, (_, t) in enumerate(vals[:K]):
            table[s][j] = t

    with (out / "model.bin").open("wb") as f:
        f.write(struct.pack("<HH", nslots, len(pop)))
        f.write(struct.pack("<" + "H" * len(pop), *pop))
        flat = [x for row in table for x in row]
        f.write(struct.pack("<" + "H" * len(flat), *flat))

    predict = r'''#!/usr/bin/env python3
import csv,struct,sys,pathlib
from collections import Counter
K=4; SENT=65535
HERE=pathlib.Path(__file__).resolve().parent
b=(HERE/'model.bin').read_bytes(); n,m=struct.unpack_from('<HH',b,0); off=4
pop=list(struct.unpack_from('<'+'H'*m,b,off)); off+=2*m
assoc=struct.unpack_from('<'+'H'*(n*K),b,off)
def hist(s):
    return [[int(x) for x in z.split()] for z in str(s).split('|') if z.strip()]
def main():
    if len(sys.argv)!=3: raise SystemExit('usage: predict.py <in.csv> <out.csv>')
    with open(sys.argv[1],newline='',encoding='utf-8') as f:
        r=csv.DictReader(f)
        if r.fieldnames!=['query_id','history','gaps_days']: raise SystemExit('bad input schema')
        rows=list(r)
    ans=[]
    for row in rows:
        seen={x for q in hist(row['history']) for x in q}; v=Counter()
        for s in seen:
            if 0<=s<n:
                base=s*K
                for j in range(K):
                    t=assoc[base+j]
                    if t!=SENT and t not in seen: v[t]+=K-j
        out=[x for x,_ in v.most_common(10)]; have=set(out)
        if len(out)<10:
            for t in pop:
                if t not in seen and t not in have:
                    out.append(t);have.add(t)
                    if len(out)==10:break
        ans.append(' '.join(map(str,out)))
    with open(sys.argv[2],'w',newline='',encoding='utf-8') as f:
        w=csv.writer(f);w.writerow(['prediction']);w.writerows([[x] for x in ans])
if __name__=='__main__':main()
'''
    (out / "predict.py").write_text(predict, encoding="utf-8")
    size = 0
    for p in out.rglob("*"):
        size += len(os.fsencode(p.relative_to(out).as_posix())) + 1
        if p.is_file():
            size += p.stat().st_size
    print(f"compact probe artifact: {size} bytes")
    if size > 65536:
        raise SystemExit("compact probe exceeds 64 KiB")


if __name__ == "__main__":
    main()
