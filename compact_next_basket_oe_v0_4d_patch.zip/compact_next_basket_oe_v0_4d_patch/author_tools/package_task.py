#!/usr/bin/env python3
from __future__ import annotations

import argparse
import ast
import csv
import json
import math
import pathlib
import zipfile

REQUIRED_CONFIG_KEYS = {
    "artifact_limit_bytes",
    "calibration_anchor_ndcg_at_10",
    "calibration_anchor_reward",
    "calibration_anchor_kind",
    "calibration_anchor_producer",
    "customer_disjoint_eval",
    "metric",
    "normalization",
    "novel_target_only",
    "unseen_popularity_ndcg_at_10",
}


def parse_history(s):
    return [[x for x in b.split() if x] for b in str(s).split("|") if str(b).strip()]


def ndcg(pred, target):
    target = set(target)
    if not target:
        return 0.0
    dcg = sum(1.0 / math.log2(r + 1) for r, x in enumerate(pred, 1) if x in target)
    k = min(10, len(target))
    idcg = sum(1.0 / math.log2(r + 1) for r in range(1, k + 1))
    return dcg / idcg if idcg else 0.0


def collect_config_keys_from_test_main(path: pathlib.Path):
    tree = ast.parse(path.read_text(encoding="utf-8"))
    keys = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Subscript) and isinstance(node.value, ast.Name) and node.value.id == "config":
            sl = node.slice
            if isinstance(sl, ast.Constant) and isinstance(sl.value, str):
                keys.add(sl.value)
    return keys


def validate_rubrics(path: pathlib.Path):
    lines = [ln for ln in path.read_text(encoding="utf-8").splitlines() if ln.strip()]
    if not lines:
        raise SystemExit("rubrics.jsonl is empty")
    for i, ln in enumerate(lines, 1):
        obj = json.loads(ln)
        if set(obj) != {"id", "rubric"}:
            raise SystemExit(f"rubrics.jsonl line {i}: expected exactly id,rubric; got {sorted(obj)}")
        if not isinstance(obj["id"], str) or not obj["id"].strip():
            raise SystemExit(f"rubrics.jsonl line {i}: invalid id")
        if not isinstance(obj["rubric"], str) or not obj["rubric"].strip():
            raise SystemExit(f"rubrics.jsonl line {i}: invalid rubric")


def validate_materialization(root: pathlib.Path):
    train = root / "environment/data/train.csv"
    test = root / "tests/test.csv"
    catalog = root / "tests/catalog.csv"
    config_path = root / "tests/scoring_config.json"
    report_path = root / "author_tools/build_report.json"
    calibration_report_path = root / "author_tools/calibration_reference_report.json"
    pop_path = root / "baseline/popular_items.txt"
    main_path = root / "tests/test_main.py"
    security_path = root / "tests/test_security.py"
    test_sh_path = root / "tests/test.sh"
    rubric_path = root / "tests/rubrics.jsonl"
    for p in (train, test, catalog, config_path, report_path, calibration_report_path, pop_path, main_path, security_path, test_sh_path, rubric_path):
        if not p.exists() or p.stat().st_size == 0:
            raise SystemExit(f"missing materialized file: {p}")

    with train.open(newline="", encoding="utf-8") as f:
        tr = list(csv.DictReader(f))
    with test.open(newline="", encoding="utf-8") as f:
        r = csv.DictReader(f)
        if r.fieldnames != ["query_id", "history", "gaps_days", "target_items"]:
            raise SystemExit(f"unexpected tests/test.csv schema: {r.fieldnames}")
        te = list(r)
    with catalog.open(newline="", encoding="utf-8") as f:
        cr = csv.DictReader(f)
        if cr.fieldnames != ["item_id"]:
            raise SystemExit("unexpected catalog schema")
        catalog_rows = list(cr)

    config = json.loads(config_path.read_text(encoding="utf-8"))
    report = json.loads(report_path.read_text(encoding="utf-8"))
    calibration_report = json.loads(calibration_report_path.read_text(encoding="utf-8"))
    missing = REQUIRED_CONFIG_KEYS - set(config)
    if missing:
        raise SystemExit(f"scoring_config.json missing required keys: {sorted(missing)}")
    used = collect_config_keys_from_test_main(main_path)
    missing_used = used - set(config)
    if missing_used:
        raise SystemExit(f"test_main.py reads missing config keys: {sorted(missing_used)}")
    validate_rubrics(rubric_path)
    if "test_security.py" not in test_sh_path.read_text(encoding="utf-8"):
        raise SystemExit("tests/test.sh does not execute adversarial security regressions")
    security_text = security_path.read_text(encoding="utf-8")
    for required in ("test_external_solve_phase_state_is_not_visible", "test_filename_encoded_payload_counts_toward_budget"):
        if required not in security_text:
            raise SystemExit(f"tests/test_security.py missing regression: {required}")
    docker_text = (root / "environment/Dockerfile").read_text(encoding="utf-8")
    for token in ('USER oeagent', 'libseccomp2', '4755', 'security/launcher.py', 'security/oe-infer.c'):
        if token not in docker_text:
            raise SystemExit(f"environment missing required isolation configuration: {token}")
    for rel in ('environment/security/launcher.py', 'environment/security/oe-infer.c',
                'environment/security/build_runtime.py', 'tests/test_artifact_security.py',
                'tests/pytest.ini', 'SECURITY.md'):
        if not (root / rel).is_file():
            raise SystemExit(f"missing isolation component: {rel}")
    if 'test_artifact_security.py' not in test_sh_path.read_text(encoding='utf-8'):
        raise SystemExit('tests/test.sh must run artifact accounting regressions')

    if config["calibration_anchor_kind"] != "full_memory_label_blind_author_calibration_reference":
        raise SystemExit("unexpected calibration anchor kind")
    if config["calibration_anchor_producer"] != "author_tools/calibration_reference.py (source bundle)":
        raise SystemExit("unexpected calibration anchor producer")
    if calibration_report.get("producer") != "author_tools/calibration_reference.py":
        raise SystemExit("calibration reference report has unexpected producer")
    if calibration_report.get("hidden_eval_labels_used_for_selection") is not False:
        raise SystemExit("calibration reference must select hyperparameters without hidden eval labels")
    if "reward-scale anchor only" not in str(calibration_report.get("purpose", "")):
        raise SystemExit("calibration reference report does not state its role")

    import hashlib
    def file_sha256(path):
        h = hashlib.sha256()
        with path.open("rb") as f:
            for chunk in iter(lambda: f.read(1 << 20), b""):
                h.update(chunk)
        return h.hexdigest()
    expected_hashes = calibration_report.get("input_sha256", {})
    for rel, path in (("environment/data/train.csv", train), ("tests/test.csv", test), ("tests/catalog.csv", catalog)):
        if expected_hashes.get(rel) != file_sha256(path):
            raise SystemExit(f"calibration reference report is stale for {rel}")

    if config["metric"] != "macro_novel_ndcg_at_10" or config["novel_target_only"] is not True:
        raise SystemExit("v0.4 config must score novel targets only")
    expected_norm = "z=max(0,(raw-unseen_popularity)/(calibration_anchor-unseen_popularity)); reward=1-(1-calibration_anchor_reward)^z"
    if config["normalization"] != expected_norm:
        raise SystemExit("stale or unexpected normalization description")

    # Every target item must be absent from visible history.
    for split_name, rows in (("train", tr), ("test", te)):
        for idx, row in enumerate(rows):
            seen = {x for b in parse_history(row["history"]) for x in b}
            target = set(row["target_items"].split())
            if not target:
                raise SystemExit(f"{split_name} row {idx}: empty target")
            overlap = seen & target
            if overlap:
                raise SystemExit(f"{split_name} row {idx}: target/history overlap {sorted(overlap)[:3]}")

    pop = [x for x in pop_path.read_text(encoding="utf-8").split() if x]
    if len(pop) < 10 or len(set(pop)) != len(pop):
        raise SystemExit("baseline/popular_items.txt must be a distinct item ranking with at least 10 IDs")
    catalog_set = {row["item_id"] for row in catalog_rows}
    if any(x not in catalog_set for x in pop):
        raise SystemExit("popular_items.txt contains unknown catalog IDs")

    vals = []
    for row in te:
        seen = {x for b in parse_history(row["history"]) for x in b}
        pred = [x for x in pop if x not in seen][:10]
        vals.append(ndcg(pred, row["target_items"].split()))
    raw = sum(vals) / len(vals)

    scalar_checks = {
        "train_customers": (len(tr), int(report["train_customers"])),
        "evaluation_customers": (len(te), int(report["evaluation_customers"])),
        "catalog_size": (len(catalog_rows), int(report["catalog_size"])),
    }
    for name, (actual, declared) in scalar_checks.items():
        if actual != declared:
            raise SystemExit(f"stale build_report.json: {name} actual={actual} report={declared}")

    numeric_checks = [
        ("unseen_popularity report", raw, float(report["unseen_popularity_ndcg_at_10"])),
        ("unseen_popularity config", raw, float(config["unseen_popularity_ndcg_at_10"])),
        ("anchor report/config", float(config["calibration_anchor_ndcg_at_10"]), float(report["calibration_anchor_ndcg_at_10"])),
        ("anchor standalone-report/config", float(config["calibration_anchor_ndcg_at_10"]), float(calibration_report["hidden_eval_ndcg_at_10"])),
        ("anchor inner-validation standalone/build-report", float(calibration_report["inner_validation_ndcg_at_10"]), float(report["calibration_anchor_inner_validation_ndcg_at_10"])),
        ("anchor reward report/config", float(config["calibration_anchor_reward"]), float(report["calibration_anchor_reward"])),
    ]
    for name, actual, declared in numeric_checks:
        if abs(actual - declared) > 1e-12:
            raise SystemExit(f"stale calibration metadata: {name} actual={actual} declared={declared}")

    if int(calibration_report["selected_k_neighbors"]) != int(report["calibration_anchor_k_neighbors"]):
        raise SystemExit("calibration selected k mismatch between standalone and build reports")
    if abs(float(calibration_report["selected_popularity_prior"]) - float(report["calibration_anchor_popularity_prior"])) > 1e-12:
        raise SystemExit("calibration selected popularity prior mismatch between standalone and build reports")
    if report.get("calibration_anchor_producer") != "author_tools/calibration_reference.py":
        raise SystemExit("build report missing standalone calibration producer provenance")
    if report.get("calibration_anchor_hidden_eval_labels_used_for_selection") is not False:
        raise SystemExit("build report does not assert label-blind calibration selection")

    if int(config["artifact_limit_bytes"]) != int(report["artifact_limit_bytes"]):
        raise SystemExit("artifact limit mismatch between scoring_config and build_report")
    if not (0 <= raw < float(config["calibration_anchor_ndcg_at_10"]) <= 1):
        raise SystemExit("invalid floor/anchor ordering")
    return {
        "train_customers": len(tr),
        "evaluation_customers": len(te),
        "catalog_size": len(catalog_rows),
        "unseen_popularity_ndcg_at_10": raw,
        "calibration_anchor_ndcg_at_10": float(config["calibration_anchor_ndcg_at_10"]),
    }


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--task-root", type=pathlib.Path, default=pathlib.Path(__file__).resolve().parents[1])
    p.add_argument("--output", type=pathlib.Path, default=None)
    a = p.parse_args()
    root = a.task_root.resolve()
    summary = validate_materialization(root)
    output = a.output or root.parent / "compact_next_basket_oe_v0_4b.zip"
    include = ["baseline", "environment", "tests", "solution", "README.md", "SECURITY.md", "instruction.md", "task.toml"]
    with zipfile.ZipFile(output, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
        for name in include:
            pth = root / name
            if pth.is_dir():
                for f in pth.rglob("*"):
                    rel = f.relative_to(root)
                    if '__pycache__' in rel.parts or f.suffix == '.pyc':
                        continue
                    if f.is_file():
                        zf.write(f, rel)
            else:
                zf.write(pth, pth.relative_to(root))
    print(json.dumps({"output": str(output), "validated": summary}, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
