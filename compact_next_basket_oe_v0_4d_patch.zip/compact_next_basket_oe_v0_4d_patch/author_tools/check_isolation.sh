#!/bin/sh
# Run from any directory. This target needs no dataset/materialization files.
set -eu
task_root=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
docker build --target isolation -t oe-isolation "$task_root/environment"
docker build -f "$task_root/author_tools/Dockerfile.security" -t oe-security-tests "$task_root"
# Normal deployment profile, then an explicit namespace/mount denial profile.
docker run --rm --network none oe-security-tests
docker run --rm --network none \
    --security-opt "seccomp=$task_root/author_tools/no_namespaces.json" oe-security-tests
# Verify forbidden deployment configurations fail closed rather than falling
# back to same-filesystem inference. Run as oeagent, never --privileged.
docker run --rm --network none --security-opt no-new-privileges oe-security-tests \
    python -c 'import subprocess; p=subprocess.run(["/usr/local/libexec/oe-infer"],capture_output=True); assert p.returncode==125 and b"isolation unavailable" in p.stderr, p'
docker run --rm --network none --cap-drop SYS_CHROOT oe-security-tests \
    python -c 'import pathlib,tempfile; from verifier_utils import run_predict
with tempfile.TemporaryDirectory() as t:
 p=pathlib.Path(t); (p/"predict.py").write_text("raise SystemExit(0)"); (p/"in.csv").write_text("")
 try: run_predict(p/"in.csv",p/"result.csv",artifact_root=p,timeout=1)
 except AssertionError as e: assert "isolation" in str(e), str(e)
 else: raise AssertionError("missing CAP_SYS_CHROOT did not fail closed")'
