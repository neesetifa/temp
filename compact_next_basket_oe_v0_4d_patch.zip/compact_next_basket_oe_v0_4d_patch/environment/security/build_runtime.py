"""Run only while building the image, before any solve-phase code exists."""
import os
import pathlib
import shutil

root = pathlib.Path('/opt/oe-runtime')
root.mkdir(mode=0o755)
# Copy trusted code, never bind the solve-time filesystem into inference.
for name in ('/usr/local', '/usr/lib', '/lib', '/lib64'):
    src = pathlib.Path(name)
    dst = root / name.lstrip('/')
    if src.is_symlink():
        dst.parent.mkdir(parents=True, exist_ok=True)
        dst.symlink_to(os.readlink(src))
    elif src.is_dir():
        shutil.copytree(src, dst, symlinks=True)
for name in ('/bin/sh', '/usr/bin/env'):
    dst = root / name.lstrip('/')
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(pathlib.Path(name).resolve(), dst)
    dst.chmod(0o555)
for p in root.rglob('*'):
    if p.is_symlink():
        continue
    # No setuid files or writable runtime state. Runtime is a separate copy.
    p.chmod(0o555 if p.is_dir() or p.stat().st_mode & 0o111 else 0o444)
