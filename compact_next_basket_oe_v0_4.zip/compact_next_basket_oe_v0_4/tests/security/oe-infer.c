/* The sole setuid entrypoint. No caller paths, commands, env or extra FDs. */
#define _GNU_SOURCE
#include <errno.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/prctl.h>
#include <sys/stat.h>
#include <unistd.h>

int main(int argc, char **argv) {
    (void)argv;
    if (argc != 1 || (getuid() != 10001 && getuid() != 0)) {
        fputs("oe-infer: invalid invocation\n", stderr);
        return 125;
    }
    if (geteuid() != 0 || setgid(0) || setuid(0)) {
        fputs("oe-infer: isolation unavailable; requires setuid root, a suid-enabled "
              "filesystem, and no-new-privileges disabled for the supervisor\n", stderr);
        return 125;
    }
    umask(077);
    if (chdir("/") || prctl(PR_SET_DUMPABLE, 0)) return 125;
    for (int sig = 1; sig < NSIG; ++sig) signal(sig, SIG_DFL);
    sigset_t signals;
    sigemptyset(&signals);
    if (sigprocmask(SIG_SETMASK, &signals, NULL)) return 125;
    /* Linux close_range is mandatory here: fail closed on unsupported kernels. */
    if (close_range(3, ~0U, 0)) {
        perror("oe-infer: close_range (Linux >= 5.9 required)");
        return 125;
    }
    char *const args[] = {"/usr/local/bin/python3", "-I", "-S", "-B",
        "/opt/oe-isolation/launcher.py", NULL};
    char *const env[] = {"PATH=/usr/local/bin:/usr/bin:/bin", "LANG=C.UTF-8", NULL};
    execve(args[0], args, env);
    perror("oe-infer: exec trusted supervisor");
    return 125;
}
