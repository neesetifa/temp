"""Fixed root supervisor. Installed root-owned; never loaded from /tests.

Only a bounded names/content message crosses the trust boundary. Paths from the
caller are never used on the supervisor filesystem. No mounts/namespaces/audit
hooks.
"""
from __future__ import annotations

import base64
import ctypes
import errno
import json
import math
import os
import pathlib
import resource
import shutil
import signal
import stat
import subprocess
import sys
import tempfile

LIMIT = 65536
MAX_IO = 64 * 1024 * 1024
MAX_REQUEST = (MAX_IO * 4 // 3) + 1024 * 1024
INFER_UID = 10002
RUNTIME = pathlib.Path('/opt/oe-runtime')
SPOOL = pathlib.Path('/var/lib/oe-inference')


def decode_request(raw):
    if len(raw) > MAX_REQUEST:
        raise ValueError('oversized inference request')
    request = json.loads(raw)
    if request['version'] != 1:
        raise ValueError('unsupported inference protocol')
    timeout = float(request['timeout'])
    if not math.isfinite(timeout) or not 0 < timeout <= 60:
        raise ValueError('invalid inference timeout')
    entries, seen, total = [], set(), 0
    for kind, encoded_name, encoded_data in request['artifact']:
        name = base64.b64decode(encoded_name, validate=True)
        data = base64.b64decode(encoded_data, validate=True)
        parts = name.split(b'/')
        if (kind not in ('d', 'f') or any(p in (b'', b'.', b'..') for p in parts)
                or b'\0' in name or name in seen or (kind == 'd' and data)):
            raise ValueError('invalid artifact entry')
        total += 1 + len(name) + len(data)
        if total > LIMIT:
            raise ValueError('artifact too large')
        seen.add(name)
        entries.append((kind, name, data))
    kinds = {n: k for k, n, _ in entries}
    for _, name, _ in entries:
        parent = name.rpartition(b'/')[0]
        if parent and kinds.get(parent) != 'd':
            raise ValueError('missing artifact parent directory')
    if not any(k == 'f' and n == b'predict.py' and d for k, n, d in entries):
        raise ValueError('predict.py missing or empty')
    input_data = base64.b64decode(request['input'], validate=True)
    if len(input_data) > MAX_IO:
        raise ValueError('oversized inference input')
    return sorted(entries, key=lambda e: e[1]), input_data, timeout


def materialize_artifact(root, entries):
    root.mkdir(mode=0o755)
    for kind, name, data in entries:
        target = root / os.fsdecode(name)
        if kind == 'd':
            target.mkdir(mode=0o755)
        else:
            target.write_bytes(data)
            # Every file has identical permissions; no executable-bit channel.
            target.chmod(0o555)
            os.utime(target, ns=(0, 0))
    for kind, name, _ in reversed(entries):
        if kind == 'd':
            target = root / os.fsdecode(name)
            target.chmod(0o555)
            os.utime(target, ns=(0, 0))
    root.chmod(0o555)
    os.utime(root, ns=(0, 0))


def make_filter():
    """Default-deny kernel filter, including native code and descendants.

    libseccomp checks the syscall architecture (including x32 on x86-64).
    No socket/IPC/process-memory/kernel-handle APIs are on the allowlist.
    """
    sec = ctypes.CDLL('libseccomp.so.2', use_errno=True)
    sec.seccomp_init.argtypes = [ctypes.c_uint32]
    sec.seccomp_init.restype = ctypes.c_void_p
    sec.seccomp_syscall_resolve_name.argtypes = [ctypes.c_char_p]
    sec.seccomp_syscall_resolve_name.restype = ctypes.c_int
    sec.seccomp_rule_add.argtypes = [ctypes.c_void_p, ctypes.c_uint32, ctypes.c_int, ctypes.c_uint]
    sec.seccomp_rule_add.restype = ctypes.c_int
    sec.seccomp_load.argtypes = [ctypes.c_void_p]
    sec.seccomp_load.restype = ctypes.c_int
    sec.seccomp_release.argtypes = [ctypes.c_void_p]
    allow, deny = 0x7fff0000, 0x50000 | errno.EPERM
    ctx = sec.seccomp_init(deny)
    if not ctx:
        raise RuntimeError('seccomp_init failed')

    class Compare(ctypes.Structure):
        _fields_ = [('arg', ctypes.c_uint), ('op', ctypes.c_uint),
                    ('a', ctypes.c_uint64), ('b', ctypes.c_uint64)]

    def rule(name, action=allow, comparison=None):
        nr = sec.seccomp_syscall_resolve_name(name.encode())
        if nr < 0:  # Not a syscall on this architecture (including pseudo IDs).
            return
        args = [] if comparison is None else [comparison]
        rc = sec.seccomp_rule_add(ctx, action, nr, len(args), *args)
        if rc:
            raise RuntimeError(f'seccomp rule {name}: {rc}')

    for name in '''read write readv writev pread64 pwrite64 preadv pwritev
        open openat close close_range lseek stat fstat lstat newfstatat statx
        access faccessat faccessat2 readlink readlinkat getdents getdents64
        getcwd chdir fchdir mkdir mkdirat rmdir unlink unlinkat rename renameat
        renameat2 link linkat symlink symlinkat chmod fchmod fchmodat umask
        truncate ftruncate fsync fdatasync sync_file_range utime utimes utimensat
        mmap mmap2 mprotect munmap mremap madvise brk msync mincore
        rt_sigaction rt_sigprocmask rt_sigreturn rt_sigpending rt_sigtimedwait
        sigaltstack rt_sigsuspend restart_syscall
        futex futex_time64 futex_waitv set_tid_address set_robust_list rseq
        arch_prctl getpid getppid gettid getuid geteuid getgid getegid getgroups
        clock_gettime clock_gettime64 clock_getres gettimeofday time nanosleep
        clock_nanosleep clock_nanosleep_time64 sched_yield sched_getaffinity
        sched_getparam sched_getscheduler sched_get_priority_max sched_get_priority_min
        getrusage times getrlimit ugetrlimit getrandom uname sysinfo
        poll ppoll ppoll_time64 select pselect6 pselect6_time64
        epoll_create epoll_create1 epoll_ctl epoll_wait epoll_pwait epoll_pwait2
        pipe pipe2 dup dup2 dup3 sendfile copy_file_range
        execve execveat fork vfork wait4 waitid exit exit_group'''.split():
        rule(name)
    # Clone may create ordinary processes/threads, never new namespaces or a
    # CLONE_PARENT child outside the supervised process group.
    forbidden = 0x7e020000 | 0x00008000  # namespace flags | CLONE_PARENT
    rule('clone', comparison=Compare(0, 7, forbidden, 0))  # MASKED_EQ
    rule('clone3', 0x50000 | errno.ENOSYS)  # libc falls back to clone
    # Only local FD operations; locks on shared runtime inodes cannot be a relay.
    for command in (0, 1, 2, 3, 4, 1030):
        rule('fcntl', comparison=Compare(1, 4, command, 0))  # EQ
    # Common terminal queries plus FIONCLEX/FIOCLEX, which only change the
    # close-on-exec bit of a descriptor already owned by this process.  Python
    # uses FIOCLEX when opening its main script on aarch64.
    for command in (0x5401, 0x5413, 0x541b, 0x5450, 0x5451):
        rule('ioctl', comparison=Compare(1, 4, command, 0))
    # Permit querying only this process's limits, never changing others' state.
    # glibc getrlimit uses prlimit64(0, ..., NULL, old_limit).
    nr = sec.seccomp_syscall_resolve_name(b'prlimit64')
    if nr >= 0:
        rc = sec.seccomp_rule_add(ctx, allow, nr, 2, Compare(0, 4, 0, 0), Compare(2, 4, 0, 0))
        if rc:
            raise RuntimeError(f'seccomp prlimit64: {rc}')
    return sec, ctx


def execute(entries, input_data, timeout):
    sec, ctx = make_filter()  # fail before executing any submitted code
    libc = ctypes.CDLL(None, use_errno=True)

    def check(rc, what):
        if rc != 0:
            raise OSError(ctypes.get_errno(), what)

    # Reap orphaned grandchildren after killing the process group, including
    # containers whose PID 1 does not reap. No lingering same-UID descendants.
    check(libc.prctl(36, 1, 0, 0, 0), 'PR_SET_CHILD_SUBREAPER')

    with tempfile.TemporaryDirectory(prefix='run-', dir=SPOOL) as tmp:
        base = pathlib.Path(tmp)
        root = base / 'root'
        # Independent files, not hardlinks: even atimes and file locks must not
        # expose mutable solve-time/runtime state across invocations.
        shutil.copytree(RUNTIME, root, symlinks=True, copy_function=shutil.copyfile)
        # copyfile strips modes; restore only fixed runtime executability.
        for p in root.rglob('*'):
            if not p.is_symlink():
                original = RUNTIME / p.relative_to(root)
                p.chmod(0o555 if p.is_dir() or original.stat().st_mode & 0o111 else 0o444)
        root.chmod(0o755)
        materialize_artifact(root / 'output', entries)
        (root / 'input.csv').write_bytes(input_data)
        (root / 'input.csv').chmod(0o444)
        for name in ('var', 'home', 'dev'):
            (root / name).mkdir(mode=0o755, exist_ok=True)
            (root / name).chmod(0o755)
        for name in ('work', 'tmp', 'var/tmp', 'home/sandbox', 'dev/shm'):
            p = root / name
            p.mkdir(parents=True, exist_ok=True)
            p.chmod(0o700)
            os.chown(p, INFER_UID, INFER_UID)
        # Only these fixed devices; no host /dev directory or /dev/fd aliases.
        for name, minor in (('null', 3), ('zero', 5), ('random', 8), ('urandom', 9)):
            p = root / 'dev' / name
            try:
                os.mknod(p, stat.S_IFCHR | 0o666, os.makedev(1, minor))
            except OSError:
                # Runtimes that drop CAP_MKNOD cannot materialize device nodes,
                # and the validation cloud is one of them. Python sources entropy
                # through the getrandom syscall, which the filter allows, so an
                # absent /dev is not fatal -- and it leaves the jail smaller.
                continue
            p.chmod(0o666)
        env = {'PATH': '/usr/local/bin:/usr/bin:/bin', 'LANG': 'C.UTF-8',
               'LC_ALL': 'C.UTF-8', 'HOME': '/home/sandbox', 'TMPDIR': '/tmp',
               'PYTHONHASHSEED': '0', 'PYTHONDONTWRITEBYTECODE': '1',
               'LD_LIBRARY_PATH': '/usr/local/lib',
               'OPENBLAS_NUM_THREADS': '1', 'OMP_NUM_THREADS': '1',
               'JOBLIB_TEMP_FOLDER': '/tmp', 'MPLCONFIGDIR': '/tmp/matplotlib'}

        def enter():
            os.setsid()
            # No cwd or open directory FD outside root survives into predict.py.
            os.chroot(root)
            os.chdir('/output')
            os.setgroups([])
            os.setresgid(INFER_UID, INFER_UID, INFER_UID)
            os.setresuid(INFER_UID, INFER_UID, INFER_UID)
            # UID transition clears permitted/effective caps; also explicitly
            # clear inheritable caps. no_new_privs blocks file capabilities.
            class Header(ctypes.Structure):
                _fields_ = [('version', ctypes.c_uint32), ('pid', ctypes.c_int)]
            class Caps(ctypes.Structure):
                _fields_ = [('effective', ctypes.c_uint32), ('permitted', ctypes.c_uint32),
                            ('inheritable', ctypes.c_uint32)]
            check(libc.capset(ctypes.byref(Header(0x20080522, 0)), (Caps * 2)()), 'capset')
            check(libc.prctl(38, 1, 0, 0, 0), 'no_new_privs')
            resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
            resource.setrlimit(resource.RLIMIT_FSIZE, (MAX_IO, MAX_IO))
            resource.setrlimit(resource.RLIMIT_NOFILE, (256, 256))
            resource.setrlimit(resource.RLIMIT_NPROC, (64, 64))
            resource.setrlimit(resource.RLIMIT_CPU, (math.ceil(timeout), math.ceil(timeout) + 1))
            check(sec.seccomp_load(ctx), 'seccomp_load')

        with open(base / 'diagnostics', 'w+b') as log:
            try:
                child = subprocess.Popen(
                    ['/usr/local/bin/python3', '-B', '/output/predict.py', '/input.csv', '/work/result.csv'],
                    stdin=subprocess.DEVNULL, stdout=log, stderr=log, env=env,
                    close_fds=True, preexec_fn=enter,
                )
            except subprocess.SubprocessError as exc:
                raise RuntimeError('isolation setup failed: check SYS_CHROOT, SETUID, '
                                   'SETGID and seccomp support') from exc
            try:
                child.wait(timeout=timeout)
            except subprocess.TimeoutExpired:
                raise ValueError(f'predict.py timed out after {timeout:g}s')
            finally:
                # setsid/setpgid are denied after enter(), so descendants cannot
                # escape this group. Do this even when the leader exits normally.
                try:
                    os.killpg(child.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
                child.wait()
                while True:
                    try:
                        os.waitpid(-child.pid, 0)
                    except ChildProcessError:
                        break
                sec.seccomp_release(ctx)
            if child.returncode != 0:
                log.seek(0, os.SEEK_END)
                log.seek(max(0, log.tell() - 4000))
                raise ValueError(f'predict.py failed with code {child.returncode}: ' +
                                 log.read().decode('utf-8', 'replace'))
        # Open each parent without following attacker-created symlinks. Work is
        # owned by inference; NEVER trust a result path in the root supervisor.
        workfd = os.open(root / 'work', os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
        try:
            fd = os.open('result.csv', os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK, dir_fd=workfd)
            with os.fdopen(fd, 'rb') as f:
                st = os.fstat(f.fileno())
                if not stat.S_ISREG(st.st_mode) or st.st_nlink != 1 or st.st_size > MAX_IO:
                    raise ValueError('submission did not create regular output CSV')
                data = f.read(MAX_IO + 1)
                if len(data) > MAX_IO:
                    raise ValueError('oversized output CSV')
                return data
        finally:
            os.close(workfd)


def main():
    if os.geteuid() != 0 or os.getuid() != 0:
        raise RuntimeError('trusted inference supervisor requires the setuid helper')
    # Avoid lingering root readers from incomplete requests. Independent of the
    # caller's timeout; setup and inference have a bounded total wall clock.
    def expired(*_):
        raise TimeoutError('inference supervisor deadline exceeded')
    signal.signal(signal.SIGALRM, expired)
    signal.alarm(4)
    entries, input_data, timeout = decode_request(sys.stdin.buffer.read(MAX_REQUEST + 1))
    signal.alarm(math.ceil(timeout) + 25)
    output = execute(entries, input_data, timeout)
    sys.stdout.write(json.dumps({'status': 'ok', 'output': base64.b64encode(output).decode('ascii')}))


if __name__ == '__main__':
    try:
        main()
    except Exception as exc:
        sys.stdout.write(json.dumps({'status': 'error', 'error': f'inference isolation: {exc}'}))
