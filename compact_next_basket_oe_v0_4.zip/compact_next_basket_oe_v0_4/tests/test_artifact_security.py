"""Portable accounting/protocol tests; Linux execution tests are in test_security."""
import base64
import importlib.util
import json
import os
import pathlib
import stat

import pytest

import verifier_utils as verifier


@pytest.fixture
def artifact(tmp_path):
    root = tmp_path / 'artifact'
    root.mkdir()
    (root / 'predict.py').write_bytes(b'pass\n')
    return root


@pytest.fixture
def launcher():
    path = pathlib.Path('/opt/oe-isolation/launcher.py')
    if not path.exists():
        path = pathlib.Path(__file__).resolve().parent / 'security/launcher.py'
    spec = importlib.util.spec_from_file_location('oe_launcher_test', path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def request(entries, **overrides):
    obj = {'version': 1, 'timeout': 1, 'input': '', 'artifact': [
        [k, base64.b64encode(n).decode(), base64.b64encode(d).decode()] for k, n, d in entries]}
    obj.update(overrides)
    return json.dumps(obj).encode()


def test_exact_budget_boundary(artifact):
    predictor = artifact / 'predict.py'
    predictor.write_bytes(b'x' * (verifier.ARTIFACT_LIMIT - len(b'predict.py') - 1))
    assert verifier.artifact_size_and_validate(artifact) == verifier.ARTIFACT_LIMIT
    predictor.write_bytes(predictor.read_bytes() + b'x')
    with pytest.raises(AssertionError, match='artifact too large'):
        verifier.artifact_size_and_validate(artifact)


def test_nested_directory_names_and_utf8_count(artifact):
    (artifact / '模型').mkdir()
    (artifact / '模型' / '值').write_bytes(b'123')
    assert verifier.artifact_size_and_validate(artifact) == (
        len(b'predict.py') + 1 + 5 + len('模型'.encode()) + 1 +
        len('模型/值'.encode()) + 1 + 3)


def test_directory_only_payload_is_bounded(artifact):
    for i in range(400):
        (artifact / (str(i) + 'X' * 200)).mkdir()
    with pytest.raises(AssertionError, match='artifact too large'):
        verifier.snapshot_artifact(artifact)


@pytest.mark.parametrize('kind', ['file_link', 'dir_link', 'dangling_link', 'fifo', 'root_link'])
def test_non_regular_entries_rejected(artifact, tmp_path, kind):
    external = tmp_path / 'external'
    external.mkdir()
    (external / 'secret').write_bytes(b'secret')
    target = artifact / 'bad'
    if kind == 'fifo':
        os.mkfifo(target)
    elif kind == 'root_link':
        link = tmp_path / 'root_link'
        link.symlink_to(artifact, target_is_directory=True)
        artifact = link
    else:
        target.symlink_to({'file_link': external / 'secret', 'dir_link': external,
                           'dangling_link': external / 'missing'}[kind])
    with pytest.raises(AssertionError):
        verifier.snapshot_artifact(artifact)


def test_hardlinks_charge_each_file_and_lose_topology(artifact, launcher, tmp_path):
    os.link(artifact / 'predict.py', artifact / 'second')
    size, entries = verifier.snapshot_artifact(artifact)
    assert size == len(b'predict.py') + len(b'second') + 2 + 10
    dest = tmp_path / 'copy'
    launcher.materialize_artifact(dest, entries)
    assert (dest / 'predict.py').stat().st_nlink == 1
    assert (dest / 'second').stat().st_nlink == 1


def test_snapshot_is_the_inference_payload(artifact, monkeypatch, tmp_path):
    original = verifier.snapshot_artifact
    def snapshot_then_change(root):
        snapshot = original(root)
        (root / 'predict.py').write_bytes(b'changed after validation')
        return snapshot
    monkeypatch.setattr(verifier, 'snapshot_artifact', snapshot_then_change)
    def fake_run(cmd, **kwargs):
        sent = json.loads(kwargs['input'])
        assert base64.b64decode(sent['artifact'][0][2]) == b'pass\n'
        assert kwargs['close_fds'] is True
        assert 'PYTHONPATH' not in kwargs['env']
        return type('Result', (), {'returncode': 0, 'stdout': b'{"status":"ok","output":"b2s="}'})()
    monkeypatch.setattr(verifier.subprocess, 'run', fake_run)
    input_csv = tmp_path / 'input'
    input_csv.write_bytes(b'input')
    out = tmp_path / 'out'
    verifier.run_predict(input_csv, out, artifact_root=artifact)
    assert out.read_bytes() == b'ok'


def test_symlink_swap_during_snapshot_rejected(artifact, tmp_path, monkeypatch):
    secret = tmp_path / 'secret'
    secret.write_bytes(b'do not read')
    original = os.open
    def swapping_open(path, flags, *args, **kwargs):
        if path == 'predict.py' and kwargs.get('dir_fd') is not None:
            (artifact / path).unlink()
            (artifact / path).symlink_to(secret)
        return original(path, flags, *args, **kwargs)
    monkeypatch.setattr(os, 'open', swapping_open)
    with pytest.raises(AssertionError, match='cannot snapshot'):
        verifier.snapshot_artifact(artifact)


def test_file_growth_cannot_bypass_bound(artifact, monkeypatch):
    original = os.fstat
    def growing_fstat(fd):
        st = original(fd)
        if stat.S_ISREG(st.st_mode):
            with (artifact / 'predict.py').open('ab') as f:
                f.write(b'x' * verifier.ARTIFACT_LIMIT)
        return st
    monkeypatch.setattr(os, 'fstat', growing_fstat)
    with pytest.raises(AssertionError, match='artifact too large'):
        verifier.snapshot_artifact(artifact)


@pytest.mark.parametrize('on_root', [False, True])
def test_xattrs_rejected(artifact, on_root):
    path = artifact if on_root else artifact / 'predict.py'
    # Linux user xattrs; macOS accepts this name too. Failure is a test failure,
    # never an integration-test skip that disguises a missing security check.
    os.setxattr(path, 'user.oe_payload', b'hidden model')
    with pytest.raises(AssertionError, match='extended attributes'):
        verifier.snapshot_artifact(artifact)


def test_metadata_normalized(artifact, launcher, tmp_path):
    p = artifact / 'predict.py'
    p.chmod(0o711)
    os.utime(p, ns=(123456000000, 987654000000))
    dest = tmp_path / 'copy'
    launcher.materialize_artifact(dest, verifier.snapshot_artifact(artifact)[1])
    st = (dest / 'predict.py').stat()
    assert stat.S_IMODE(st.st_mode) == 0o555
    assert st.st_mtime_ns == st.st_atime_ns == 0
    assert os.listxattr(dest / 'predict.py') == []


@pytest.mark.parametrize('entry', [
    ('f', b'/absolute', b''), ('f', b'../escape', b''), ('f', b'a/../../escape', b''),
    ('f', b'a//b', b''), ('f', b'a/./b', b''), ('f', b'a\0b', b''),
    ('l', b'link', b'target'), ('d', b'dir', b'data'), ('f', b'no_parent/file', b''),
    ('f', b'predict.py', b'duplicate'), ('f', b'big', b'x' * 65536),
])
def test_root_protocol_rejects_malicious_entries(launcher, entry):
    with pytest.raises(ValueError):
        launcher.decode_request(request([('f', b'predict.py', b'pass'), entry]))


@pytest.mark.parametrize('timeout', [0, -1, 61, float('inf'), float('nan')])
def test_root_protocol_rejects_bad_timeout(launcher, timeout):
    with pytest.raises(ValueError):
        launcher.decode_request(request([('f', b'predict.py', b'pass')], timeout=timeout))


def test_root_protocol_independently_meters_names(launcher):
    entries = [('f', b'predict.py', b'pass')]
    entries += [('d', f'{i:04d}_'.encode() + b'A' * 200, b'') for i in range(400)]
    with pytest.raises(ValueError, match='artifact too large'):
        launcher.decode_request(request(entries))


def test_missing_helper_fails_closed(artifact, tmp_path, monkeypatch):
    monkeypatch.setattr(verifier, 'SANDBOX_HELPER', str(tmp_path / 'not-installed'))
    source = tmp_path / 'in'
    source.write_bytes(b'')
    with pytest.raises(AssertionError, match='isolation unavailable'):
        verifier.run_predict(source, tmp_path / 'out', artifact_root=artifact)


def test_missing_xattr_inspection_fails_closed(artifact, monkeypatch):
    monkeypatch.delattr(os, 'listxattr')
    with pytest.raises(AssertionError, match='requires extended-attribute inspection'):
        verifier.snapshot_artifact(artifact)


def test_directory_swap_during_snapshot_rejected(artifact, tmp_path, monkeypatch):
    (artifact / 'nested').mkdir()
    external = tmp_path / 'external'
    external.mkdir()
    (external / 'secret').write_bytes(b'secret')
    original = os.open
    def swapping_open(path, flags, *args, **kwargs):
        if path == 'nested' and kwargs.get('dir_fd') is not None:
            (artifact / path).rmdir()
            (artifact / path).symlink_to(external, target_is_directory=True)
        return original(path, flags, *args, **kwargs)
    monkeypatch.setattr(os, 'open', swapping_open)
    with pytest.raises(AssertionError, match='cannot snapshot'):
        verifier.snapshot_artifact(artifact)
