"""Check the verifier image's inference runtime before executing it.

This code, its Python interpreter, and the expected manifest are baked into the
separate verifier image. None are imported from the solve container or /output.
The image boundary is the root of trust; this check fails closed on accidental
or malicious mutation of the verifier's inference runtime after image build.
"""
from __future__ import annotations

import hashlib
import json
import os
import pathlib
import stat
import sys

RUNTIME_PATHS = (
    pathlib.Path('/opt/oe-runtime'),
    pathlib.Path('/opt/oe-isolation'),
    pathlib.Path('/usr/local/libexec/oe-infer'),
)
MANIFEST = pathlib.Path('/tests/runtime_manifest.json')


def inventory(roots=RUNTIME_PATHS):
    entries = []

    def visit(path):
        info = path.lstat()
        mode = stat.S_IMODE(info.st_mode)
        if stat.S_ISDIR(info.st_mode):
            entries.append([str(path), 'directory', mode])
            for child in sorted(path.iterdir(), key=lambda p: os.fsencode(p.name)):
                visit(child)
        elif stat.S_ISLNK(info.st_mode):
            entries.append([str(path), 'symlink', mode, os.readlink(path)])
        elif stat.S_ISREG(info.st_mode):
            digest = hashlib.sha256()
            with path.open('rb') as stream:
                for chunk in iter(lambda: stream.read(1 << 20), b''):
                    digest.update(chunk)
            entries.append([str(path), 'file', mode, info.st_size, digest.hexdigest()])
        else:
            raise RuntimeError(f'unsupported verifier runtime entry: {path}')

    for root in roots:
        visit(pathlib.Path(root))
    return entries


def verify(manifest=MANIFEST, roots=RUNTIME_PATHS):
    expected = json.loads(pathlib.Path(manifest).read_text(encoding='utf-8'))
    if not isinstance(expected, list) or not expected:
        raise RuntimeError('empty verifier runtime manifest')
    if inventory(roots) != expected:
        raise RuntimeError('verifier runtime differs from fresh image manifest')


def main():
    if not (sys.flags.isolated and sys.flags.no_site):
        raise RuntimeError('runtime check requires isolated no-site Python')
    if len(sys.argv) == 3 and sys.argv[1] == '--write':
        pathlib.Path(sys.argv[2]).write_text(
            json.dumps(inventory(), separators=(',', ':'), ensure_ascii=True) + '\n',
            encoding='utf-8',
        )
    elif len(sys.argv) == 1:
        verify()
    else:
        raise RuntimeError('invalid runtime check invocation')


if __name__ == '__main__':
    try:
        main()
    except Exception as exc:
        print(f'verifier runtime integrity failure: {exc}', file=sys.stderr)
        raise SystemExit(2)
