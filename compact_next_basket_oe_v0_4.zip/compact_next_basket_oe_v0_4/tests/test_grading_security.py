from __future__ import annotations

import json
import pathlib
import sys

import pytest

from finalize_artifacts import finalize
from verify_runtime import inventory, verify


def _write_ctrf(log: pathlib.Path, *, tests: int, passed: int, failed: int = 0,
                pending: int = 0, skipped: int = 0, other: int = 0) -> None:
    payload = {
        'results': {
            'tool': {'name': 'pytest'},
            'summary': {
                'tests': tests,
                'passed': passed,
                'failed': failed,
                'pending': pending,
                'skipped': skipped,
                'other': other,
                'start': 0,
                'stop': 1,
            },
            'tests': [],
        }
    }
    (log / 'ctrf.json').write_text(json.dumps(payload), encoding='utf-8')


def test_pytest_runs_under_isolated_no_site_python():
    assert sys.flags.isolated == 1, 'pytest must run under python -I'
    assert sys.flags.no_site == 1, 'pytest must run under python -S'


def test_verifier_runtime_manifest_rejects_modified_file(tmp_path):
    runtime = tmp_path / 'runtime'
    runtime.mkdir()
    program = runtime / 'python3'
    program.write_bytes(b'original runtime')
    manifest = tmp_path / 'manifest.json'
    manifest.write_text(json.dumps(inventory((runtime,))), encoding='utf-8')
    verify(manifest, (runtime,))
    program.write_bytes(b'forged runtime')
    with pytest.raises(RuntimeError, match='runtime differs'):
        verify(manifest, (runtime,))


def test_planted_reward_without_ctrf_is_rejected(tmp_path):
    (tmp_path / 'reward.txt').write_text('1.0\n', encoding='utf-8')
    (tmp_path / 'metrics.json').write_text(json.dumps({'reward': 1.0}), encoding='utf-8')
    reward, failure = finalize(tmp_path)
    assert reward == 0.0
    assert failure != 'none'
    assert float((tmp_path / 'reward.txt').read_text()) == 0.0


def test_zero_test_ctrf_is_rejected(tmp_path):
    (tmp_path / 'reward.txt').write_text('1.0\n', encoding='utf-8')
    (tmp_path / 'metrics.json').write_text(json.dumps({'reward': 1.0}), encoding='utf-8')
    _write_ctrf(tmp_path, tests=0, passed=0)
    reward, failure = finalize(tmp_path)
    assert reward == 0.0
    assert failure != 'none'


def test_ctrf_gate_controls_continuous_reward(tmp_path):
    # Even if a stale/planted reward.txt claims 1.0, the scored value comes from
    # metrics only after CTRF proves the verifier tests really passed.
    (tmp_path / 'reward.txt').write_text('1.0\n', encoding='utf-8')
    (tmp_path / 'metrics.json').write_text(json.dumps({'reward': 0.314159}), encoding='utf-8')
    _write_ctrf(tmp_path, tests=7, passed=7)
    reward, failure = finalize(tmp_path)
    assert failure == 'none'
    assert abs(reward - 0.314159) < 1e-12
    assert abs(float((tmp_path / 'reward.txt').read_text()) - 0.314159) < 1e-12
