"""Private synthetic token language for the kv-cache eviction task.

Verifier-side only. The agent receives pre-generated training token sequences,
never this file.

Token map
---------
0            BOS
1            DEF   (start of a fact:  [PIN] DEF key val)
2            PIN   (optional marker before DEF)
3            ASK   (fact lookup:      ASK key val)
4            QO    (quote open:       QO w1..wn QC)
5            QC    (quote close)
6            RE    (re-quote:         RE w1..wn QC  -- exact copy of an earlier quote)
7..10        TOPIC markers; filler words follow the bigram table of the latest topic
11..15       unused / reserved
16..79       64 word tokens
80..143      64 key tokens
144..191     48 value tokens
192..255     64 quote-word tokens (quotes and re-quotes only)

Slice labels are attached to the *predicting* position t (the model's output at
t predicts token t+1):
  0 = other / filler
  1 = fact answer   (t is the key position in "ASK key", next token = val)
  2 = quote copy    (t inside a re-quote, next token is the copied word or QC)
  3 = filler word   (t is a filler word and t+1 is a filler word)
"""
from __future__ import annotations

from dataclasses import dataclass
import numpy as np

BOS, DEF, PIN, ASK, QO, QC, RE = 0, 1, 2, 3, 4, 5, 6
TOPIC0, N_TOPIC = 7, 4
WORD0, N_WORD = 16, 64
KEY0, N_KEY = 80, 64
VAL0, N_VAL = 144, 48
QWORD0, N_QWORD = 192, 64
VOCAB = 256
SEQ_LEN = 512
N_HOT_KEYS = 16

_TABLE_SEED = 0x5EED_4B56


def _markov_table():
    rng = np.random.default_rng(_TABLE_SEED)
    succ = np.zeros((N_TOPIC, N_WORD, 3), dtype=np.int64)
    for z in range(N_TOPIC):
        for a in range(N_WORD):
            succ[z, a] = rng.choice(N_WORD, size=3, replace=False)
    return succ


_SUCC = _markov_table()
_SUCC_P = np.array([0.6, 0.25, 0.15])


@dataclass(frozen=True)
class Workload:
    p_fact: float
    p_quote: float
    p_pin: float
    p_query_plain: float
    short_gap_mean: float
    long_gap_min: int
    p_hot_extra: float
    p_requote_long: float
    p_requote_short: float
    topic_len_mean: float


IN_DIST = Workload(
    p_fact=0.060, p_quote=0.012, p_pin=0.35, p_query_plain=0.40,
    short_gap_mean=36.0, long_gap_min=60, p_hot_extra=0.5,
    p_requote_long=0.75, p_requote_short=0.20, topic_len_mean=110.0,
)

SHIFTED = Workload(
    p_fact=0.090, p_quote=0.016, p_pin=0.50, p_query_plain=0.40,
    short_gap_mean=70.0, long_gap_min=90, p_hot_extra=0.5,
    p_requote_long=0.80, p_requote_short=0.20, topic_len_mean=170.0,
)


def generate_sequence(rng: np.random.Generator, wl: Workload, T: int = SEQ_LEN):
    toks = [BOS]
    labels = [0]
    src = [-1]          # for labeled positions: position of the dependency source
    used_keys = set()
    facts = {}          # key -> (val, pos_of_val)
    quotes = []         # list of (start_pos_of_w1, words)
    sched = []          # (due, kind, payload)
    a = int(rng.integers(N_WORD))
    topic = int(rng.integers(N_TOPIC))
    topic_left = 0
    prev_filler = False

    def emit(tok, lab=0, s=-1):
        toks.append(int(tok))
        labels.append(0)
        src.append(-1)
        # label belongs to the predicting position (previous index)
        if lab:
            labels[-2] = lab
            src[-2] = s

    while len(toks) < T:
        t = len(toks)
        due = [i for i, it in enumerate(sched) if it[0] <= t]
        if due:
            i = min(due, key=lambda j: sched[j][0])
            _, kind, payload = sched.pop(i)
            if kind == "ask":
                key = payload
                val, vpos = facts[key]
                emit(ASK)
                emit(key)
                emit(val, lab=1, s=vpos)
            else:
                qstart, words = quotes[payload]
                emit(RE)
                emit(words[0])
                for j, w in enumerate(words[1:]):
                    emit(w, lab=2, s=qstart + j + 1)
                emit(QC, lab=2, s=qstart + len(words))
            continue
        u = rng.random()
        if u < wl.p_fact and len(used_keys) < N_KEY:
            free = [k for k in range(N_KEY) if k not in used_keys]
            kidx = int(rng.choice(free))
            used_keys.add(kidx)
            key = KEY0 + kidx
            val = VAL0 + int(rng.integers(N_VAL))
            pinned = rng.random() < wl.p_pin
            if pinned:
                emit(PIN)
            emit(DEF)
            emit(key)
            emit(val)
            vpos = len(toks) - 1
            facts[key] = (val, vpos)
            t = len(toks)
            if pinned:
                nq = 1 + int(rng.random() < 0.4)
                for _ in range(nq):
                    sched.append((t + int(rng.integers(wl.long_gap_min, T)), "ask", key))
            elif rng.random() < wl.p_query_plain:
                sched.append((t + 6 + int(rng.geometric(1.0 / wl.short_gap_mean)), "ask", key))
            if kidx < N_HOT_KEYS and rng.random() < wl.p_hot_extra:
                sched.append((t + int(rng.integers(20, T)), "ask", key))
        elif u < wl.p_fact + wl.p_quote:
            n = int(rng.integers(3, 9))
            words = [QWORD0 + int(w) for w in rng.integers(0, N_QWORD, size=n)]
            emit(QO)
            qstart = len(toks)
            for w in words:
                emit(w)
            emit(QC)
            quotes.append((qstart, words))
            p_re = wl.p_requote_long if n >= 6 else wl.p_requote_short
            if rng.random() < p_re:
                sched.append((len(toks) + int(rng.integers(20, T)), "re", len(quotes) - 1))
        else:
            if topic_left <= 0:
                topic = int((topic + rng.integers(1, N_TOPIC)) % N_TOPIC)
                topic_left = int(rng.geometric(1.0 / wl.topic_len_mean))
                emit(TOPIC0 + topic)
                prev_filler = False
                continue
            c = int(_SUCC[topic, a][rng.choice(3, p=_SUCC_P)])
            emit(WORD0 + c, lab=3 if prev_filler else 0)
            a = c
            topic_left -= 1
            prev_filler = True
            continue
        prev_filler = False
    return (np.asarray(toks[:T], dtype=np.int64),
            np.asarray(labels[:T], dtype=np.int64),
            np.asarray(src[:T], dtype=np.int64))


def generate_corpus(seed: int, n: int, wl: Workload = IN_DIST, T: int = SEQ_LEN):
    rng = np.random.default_rng(seed)
    toks = np.zeros((n, T), dtype=np.int64)
    labs = np.zeros((n, T), dtype=np.int64)
    srcs = np.zeros((n, T), dtype=np.int64)
    for i in range(n):
        toks[i], labs[i], srcs[i] = generate_sequence(rng, wl, T)
    # The final position predicts nothing.
    labs[:, -1] = 0
    return toks, labs, srcs


if __name__ == "__main__":
    for name, wl in (("in", IN_DIST), ("shift", SHIFTED)):
        t, l, s = generate_corpus(1, 200, wl)
        pos = np.arange(t.shape[1])[None, :]
        gap1 = (pos - s)[l == 1]
        gap2 = (pos - s)[l == 2]
        print(name, "filler", (l == 3).sum(1).mean(), "topics", ((t >= 7) & (t < 11)).sum(1).mean())
        print(name, "facts/seq", (t == DEF).sum(1).mean(), "pins", (t == PIN).sum(1).mean(),
              "asks", (l == 1).sum(1).mean(), "quotes", (t == QO).sum(1).mean(), "requote toks", (l == 2).sum(1).mean(),
              "ans gap med/p90", np.median(gap1), np.percentile(gap1, 90), "copy gap med", np.median(gap2))
    print(t[0][:120])
