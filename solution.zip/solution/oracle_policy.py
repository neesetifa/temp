"""Privileged ORACLE eviction policy for kv_cache_eviction (uses the hidden mechanism).

Not a legitimate solution: it regenerates the hidden evaluation sequences from
the task generator (fixed seeds), identifies the current sequence from its first
chunk (tokens decoded exactly from layer-0 keys), computes the full-cache
attention of every FUTURE query, and keeps the entries that future queries will
actually use. Selection = per-layer budget share, then a single in-layer top-k on
  head_w[l,h] * role_w[role(p)] * (max_future_attn^alpha + beta * mean_future_attn)
with the knobs tuned on training sequences (oracle_params.npz).

solve.sh installs it as /app/policy.py together with oracle_params.npz,
oracle_generator.py (= tests/generator.py) and oracle_roles.py (= legit reference
policy module, used only for its token-role parser).
"""
from __future__ import annotations

from pathlib import Path
import sys

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

HIDDEN = (("IN_DIST", 424242), ("SHIFTED", 515151))
N_PER_SHARD = 60


class EvictionPolicy:
    def __init__(self, config):
        import oracle_generator as G
        from oracle_roles import SeqState
        from kvmodel import TinyLM
        self.SeqState = SeqState
        app = Path(config.get("app_dir", HERE))
        mp = next(p for p in (app / "model.npz", HERE / "model.npz", Path("/app/model.npz")) if p.exists())
        self.m = TinyLM(mp)
        self.L, self.H = self.m.L, self.m.H
        self.budget = int(config["budget"])
        with np.load(HERE / "oracle_params.npz", allow_pickle=False) as z:
            p = {k: z[k] for k in z.files}
        self.p = {"layer_frac": p["layer_frac"].astype(float), "head_w": p["head_w"].astype(float),
                  "role_w": p["role_w"].astype(float), "alpha": float(p["alpha"]),
                  "beta": float(p["beta"]), "min_recent": int(p["min_recent"])}
        self.lookup = {}
        for wl_name, seed in HIDDEN:
            toks, _, _ = G.generate_corpus(seed, N_PER_SHARD, getattr(G, wl_name), T=int(config["seq_len"]))
            for t in toks:
                self.lookup[tuple(int(x) for x in t[:int(config["chunk"])])] = t
        w = self.m.w
        emb = w["emb"]
        a = emb / np.sqrt(np.mean(emb * emb, -1, keepdims=True) + 1e-6) * w["g1_0"]
        self.table = a @ w["Wk_0"]

    def begin_sequence(self, seq_len):
        self.ready = False

    def _prepare(self, view):
        C = view.chunk_end - view.chunk_start
        K = np.concatenate([k[-C:] for k in view.keys], 1)
        pref = tuple(int(x) for x in ((K[:, None] - self.table[None]) ** 2).sum(-1).argmin(1))
        tokens = np.asarray(self.lookup[pref])
        T = len(tokens)
        A = np.zeros((self.L, self.H, T, T))

        def cb(l, s, e, hh, pos, P):
            A[l, hh, s:e][:, pos] = P

        self.m.run(tokens, collect=cb, chunk=T)
        self.fut_max = np.maximum.accumulate(A[:, :, ::-1, :], axis=2)[:, :, ::-1, :]
        self.fut_sum = np.cumsum(A[:, :, ::-1, :], axis=2)[:, :, ::-1, :]
        st = self.SeqState(T)
        st.push(tokens)
        self.role = st.role.copy()
        self.T = T
        self.ready = True

    def select(self, view):
        if not self.ready:
            self._prepare(view)
        p, e, l = self.p, view.chunk_end, view.layer
        frac = p["layer_frac"]
        held_other = sum(view.held[ll] for ll in range(self.L) if ll < l) + \
            sum(min(view.held[ll], int(frac[ll] * self.budget)) for ll in range(self.L) if ll > l)
        lb = int(max(0, min(frac[l] * self.budget, self.budget - held_other)))
        scores, owners, locals_ = [], [], []
        for h, pos in enumerate(view.positions):
            if e < self.T:
                fm = self.fut_max[l, h, e, pos]
                fs = self.fut_sum[l, h, e, pos] / (self.T - e)
            else:
                fm = fs = np.zeros(len(pos))
            sc = p["head_w"][l, h] * p["role_w"][self.role[pos]] * (fm ** p["alpha"] + p["beta"] * fs)
            scores.append(sc + 10.0 * (pos >= e - p["min_recent"]))
            owners.append(np.full(len(pos), h))
            locals_.append(np.arange(len(pos)))
        sc = np.concatenate(scores)
        own = np.concatenate(owners)
        loc = np.concatenate(locals_)
        k = min(lb, sc.size)
        top = np.argpartition(-sc, k - 1)[:k] if 0 < k < sc.size else np.arange(sc.size)[:k]
        keep = [[] for _ in range(self.H)]
        for j in top:
            keep[own[j]].append(loc[j])
        return [np.sort(np.asarray(x, dtype=np.int64)) for x in keep]
