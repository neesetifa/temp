#!/bin/bash
cp /solution/model.json /app/release/model.json
cp /solution/policy.json /app/release/policy.json
