#!/bin/bash
# Install the privileged ORACLE policy into /app (defines the top of the reward scale).
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
TESTS="${TESTS_DIR:-/tests}"
cp "$HERE/oracle_policy.py" /app/policy.py
cp "$HERE/oracle_params.npz" /app/oracle_params.npz
cp "$HERE/legit_reference/policy.py" /app/oracle_roles.py
if [ -f "$HERE/oracle_generator.py" ]; then
  cp "$HERE/oracle_generator.py" /app/oracle_generator.py
else
  cp "$TESTS/generator.py" /app/oracle_generator.py
fi
