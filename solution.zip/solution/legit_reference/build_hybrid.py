"""Builder for the final (hybrid) reference assets. Agent-visible data only.

    python build_hybrid.py --app /app --base <assets with t_* trees and tuned shares> --budget 96 --out ref_assets.npz

Combines the general learned importance model (t_* trees, from build_reference.py)
with head roles + fact-query model (from build_planned.py helpers): inside every
layer all heads compete in one top-k; in fact heads the fact-value entries are
scored by fact_w * P(asked later) + fact_b; the topic heads always keep the
latest topic marker. All allocation knobs are tuned by coordinate search on
held-out training sequences with the group-balanced log-KL objective.
"""
from __future__ import annotations

import argparse
from pathlib import Path
import sys
import time

import numpy as np
from sklearn.ensemble import HistGradientBoostingRegressor

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from policy import EvictionPolicy  # noqa: E402
from build_reference import export_hgb, position_groups  # noqa: E402
from build_planned import head_roles, key_rates, fact_rows  # noqa: E402


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--app", default="/app")
    ap.add_argument("--base", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--budget", type=int, default=96)
    ap.add_argument("--n-tune", type=int, default=8)
    ap.add_argument("--passes", type=int, default=2)
    ns = ap.parse_args()
    app = Path(ns.app)
    sys.path.insert(0, str(app))
    from kvmodel import TinyLM, kl_full_vs
    model = TinyLM(app / "model.npz")
    toks = np.load(app / "data" / "train_tokens.npy").astype(np.int64)
    chunk, budget, L, H = 32, ns.budget, model.L, model.H
    t0 = time.time()
    with np.load(ns.base, allow_pickle=False) as z:
        base = {k: z[k] for k in z.files}
    assets = {k: v for k, v in base.items() if k.startswith("t_")}
    fh, th, _, _ = head_roles(model, toks)
    kr = key_rates(toks[:600])
    X, y = fact_rows(toks[:400], kr, chunk)
    q = HistGradientBoostingRegressor(max_iter=150, learning_rate=0.08, max_leaf_nodes=31,
                                      min_samples_leaf=50, random_state=0).fit(X, y)
    assets.update({"q_" + k[2:]: v for k, v in export_hgb(q).items()})
    assets.update({"fact_heads": fh, "topic_heads": th, "key_rate": kr})
    print("heads", fh.tolist(), th.tolist(), f"{time.time() - t0:.0f}s", flush=True)

    tune = toks[600:600 + ns.n_tune]
    fulls = [model.run(t) for t in tune]
    groups = [position_groups(t)[chunk:-1] for t in tune]
    cfg = {"d": model.d, "heads": H, "layers": L, "head_dim": model.hd, "vocab": model.V,
           "chunk": chunk, "seq_len": toks.shape[1], "budget": budget, "app_dir": str(app)}

    def objective(p):
        a = dict(assets)
        a.update({"layer_frac": p["layer_frac"], "head_w": p["head_w"], "min_recent": np.asarray(p["min_recent"]),
                  "fact_w": np.asarray(p["fact_w"]), "fact_b": np.asarray(p["fact_b"])})
        pol = EvictionPolicy(cfg, assets=a)
        kls = [kl_full_vs(f, model.run(t, policy=pol, budget=budget, chunk=chunk))[chunk:-1]
               for t, f in zip(tune, fulls)]
        kl, g = np.concatenate(kls), np.concatenate(groups)
        return float(np.mean([np.log(kl[g == k].mean() + 1e-6) for k in (1, 3, 0)]))

    p = {"layer_frac": np.asarray(base.get("layer_frac", np.full(L, 1 / L)), float),
         "head_w": np.asarray(base.get("head_w", np.ones((L, H))), float),
         "min_recent": int(base.get("min_recent", 1)), "fact_w": 1.0, "fact_b": 0.0}
    best = objective(p)
    print("start", round(best, 4), flush=True)

    def try_(q, tag):
        nonlocal best, p
        v = objective(q)
        if v < best:
            best, p = v, q
            print(tag, round(v, 4), f"{time.time() - t0:.0f}s", flush=True)
            return True
        return False

    for it in range(ns.passes):
        for m in (0.25, 0.5, 2.0, 4.0):
            try_({**p, "fact_w": p["fact_w"] * m}, f"fact_w {p['fact_w'] * m}")
        for d in (-0.3, -0.1, 0.1, 0.3):
            try_({**p, "fact_b": p["fact_b"] + d}, f"fact_b {p['fact_b'] + d}")
        for l in range(L):
            for d in (-0.12, -0.05, 0.05, 0.12):
                fr = p["layer_frac"].copy()
                fr[l] = max(0.02, fr[l] + d)
                try_({**p, "layer_frac": fr / fr.sum()}, f"layer_frac {np.round(fr / fr.sum(), 3)}")
        for l in range(L):
            for h in range(H):
                for m in (0.5, 2.0):
                    hw = p["head_w"].copy()
                    hw[l, h] *= m
                    try_({**p, "head_w": hw}, f"head_w {l} {h} {hw[l, h]}")
        for mr in (0, 1, 2, 4):
            if mr != p["min_recent"]:
                try_({**p, "min_recent": mr}, f"min_recent {mr}")
    assets.update({"layer_frac": p["layer_frac"], "head_w": p["head_w"], "min_recent": np.asarray(p["min_recent"]),
                   "fact_w": np.asarray(p["fact_w"]), "fact_b": np.asarray(p["fact_b"])})
    np.savez_compressed(ns.out, **assets)
    print("saved", ns.out, {k: np.round(v, 3).tolist() if hasattr(v, "tolist") else v for k, v in p.items()},
          "obj", round(best, 4), f"{time.time() - t0:.0f}s")


if __name__ == "__main__":
    main()
