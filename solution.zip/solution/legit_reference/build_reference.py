"""Offline builder for the reference policy assets (uses agent-visible data only).

    python build_reference.py --app /app --out /solution/ref_assets.npz

Steps
  1. run the full-cache model on training sequences and record attention;
  2. at every chunk boundary, featurize each (layer, head, past position) with the
     same features the online policy computes, target = max attention future
     queries pay to that entry;
  3. fit a gradient-boosted regressor, export its trees to plain numpy arrays;
  4. tune per-layer budget shares by direct search on training sequences
     (objective: unweighted mean KL over all positions).
"""
from __future__ import annotations

import argparse
from pathlib import Path
import sys
import time

import numpy as np
from sklearn.ensemble import HistGradientBoostingRegressor

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from policy import SeqState, EvictionPolicy, N_ATT_FEATS  # noqa: E402


def full_attention(model, tokens):
    L, H, T = model.L, model.H, len(tokens)
    A = np.zeros((L, H, T, T))

    def cb(l, s, e, hh, pos, P):
        A[l, hh, s:e][:, pos] = P

    lp = model.run(tokens, collect=cb, chunk=T)
    return lp, A


def make_rows(model, tokens, chunk, rng, filler_keep=0.25):
    T = len(tokens)
    L, H = model.L, model.H
    _, A = full_attention(model, tokens)
    st = SeqState(T)
    X, y = [], []
    for e in range(chunk, T, chunk):
        st.push(tokens[e - chunk:e])
        pos_all = np.arange(e)
        role = st.role[:e]
        keep = (role != 1) | (pos_all >= e - 48) | (rng.random(e) < filler_keep)
        pos = pos_all[keep]
        F = st.features(pos, e)
        for l in range(L):
            for h in range(H):
                Ach = A[l, h, e - chunk:e][:, pos]          # chunk queries -> candidates
                acc = A[l, h, :e][:, pos].sum(0)
                att = np.stack([Ach.mean(0), Ach.max(0), Ach[-4:].mean(0),
                                acc / np.maximum(1, e - pos)], 1)
                lh = np.full((len(pos), 2), [l, l * H + h], dtype=float)
                X.append(np.concatenate([F, att, lh], 1))
                y.append(A[l, h, e:, :][:, pos].max(0))
    return np.concatenate(X), np.concatenate(y)


def export_hgb(model):
    feats, thr, left, right, leaf, val, mgl, offs = [], [], [], [], [], [], [], [0]
    for pred in model._predictors:
        nodes = pred[0].nodes
        feats.append(nodes["feature_idx"].astype(np.int64))
        thr.append(nodes["num_threshold"].astype(np.float64))
        left.append(nodes["left"].astype(np.int64))
        right.append(nodes["right"].astype(np.int64))
        leaf.append(nodes["is_leaf"].astype(np.int64))
        val.append(nodes["value"].astype(np.float64))
        mgl.append(nodes["missing_go_to_left"].astype(np.int64))
        offs.append(offs[-1] + len(nodes))
    return {
        "t_feat": np.concatenate(feats), "t_thr": np.concatenate(thr),
        "t_left": np.concatenate(left), "t_right": np.concatenate(right),
        "t_leaf": np.concatenate(leaf), "t_val": np.concatenate(val),
        "t_mgl": np.concatenate(mgl), "t_off": np.asarray(offs, dtype=np.int64),
        "t_base": np.asarray(float(np.ravel(model._baseline_prediction)[0])),
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--app", default="/app")
    ap.add_argument("--out", default=str(HERE / "ref_assets.npz"))
    ap.add_argument("--n-train", type=int, default=120)
    ap.add_argument("--n-tune", type=int, default=12)
    ap.add_argument("--budget", type=int, default=512)
    ap.add_argument("--reuse", default=None, help="reuse trees from an existing assets file")
    ap.add_argument("--warm", action="store_true", help="also start tuning from the reused shares/weights")
    ns = ap.parse_args()
    app = Path(ns.app)
    sys.path.insert(0, str(app))
    from kvmodel import TinyLM, kl_full_vs

    model = TinyLM(app / "model.npz")
    toks = np.load(app / "data" / "train_tokens.npy").astype(np.int64)
    chunk, budget = 32, ns.budget
    rng = np.random.default_rng(0)
    t0 = time.time()
    if ns.reuse:
        with np.load(ns.reuse, allow_pickle=False) as z:
            keep = ("t_", "layer_frac", "head_w", "min_recent") if ns.warm else ("t_",)
            assets = {k: z[k] for k in z.files if k.startswith(keep)}
    else:
        assets = fit_trees(model, toks, chunk, rng, ns.n_train, t0)
    tune_layers(model, toks, chunk, budget, assets, ns, app, kl_full_vs, t0)


def fit_trees(model, toks, chunk, rng, n_train, t0):
    Xs, ys = [], []
    for i in range(n_train):
        X, y = make_rows(model, toks[i], chunk, rng)
        Xs.append(X)
        ys.append(y)
    X, y = np.concatenate(Xs), np.concatenate(ys)
    print(f"rows={len(y)}  featurize {time.time() - t0:.0f}s", flush=True)
    gbm = HistGradientBoostingRegressor(max_iter=250, learning_rate=0.08, max_leaf_nodes=63,
                                        min_samples_leaf=40, l2_regularization=1.0, random_state=0)
    gbm.fit(X, y)
    assets = export_hgb(gbm)
    # sanity: exported trees reproduce sklearn predictions
    from policy import predict_trees
    sub = X[:5000]
    assert np.allclose(predict_trees(assets, sub), gbm.predict(sub), atol=1e-8)
    print(f"gbm fit done {time.time() - t0:.0f}s", flush=True)
    return assets


def position_groups(tokens):
    """Group predicting positions by recovered role: 1 answer, 3 filler, 0 other."""
    st = SeqState(len(tokens))
    st.push(tokens)
    r = st.role
    g = np.zeros(len(tokens), dtype=np.int64)
    g[:-1][r[:-1] == 6] = 1                                  # key in "ASK key" -> predicts the value
    g[:-1][(r[:-1] == 1) & (r[1:] == 1)] = 3                 # filler -> filler
    return g


def tune_layers(model, toks, chunk, budget, assets, ns, app, kl_full_vs, t0):
    tune = toks[ns.n_train:ns.n_train + ns.n_tune]
    fulls = [model.run(t) for t in tune]
    groups = [position_groups(t)[chunk:-1] for t in tune]
    cfg = {"d": model.d, "heads": model.H, "layers": model.L, "head_dim": model.hd,
           "vocab": model.V, "chunk": chunk, "seq_len": toks.shape[1], "budget": budget,
           "app_dir": str(app)}
    L, H = model.L, model.H

    def objective(frac, hw, min_recent):
        a = dict(assets)
        a["layer_frac"] = np.asarray(frac, dtype=float)
        a["head_w"] = np.asarray(hw, dtype=float)
        a["min_recent"] = np.asarray(min_recent)
        pol = EvictionPolicy(cfg, assets=a)
        kls = []
        for t, f in zip(tune, fulls):
            kls.append(kl_full_vs(f, model.run(t, policy=pol, budget=budget, chunk=chunk))[chunk:-1])
        kl, g = np.concatenate(kls), np.concatenate(groups)
        return float(np.mean([np.log(kl[g == k].mean() + 1e-6) for k in (1, 3, 0)]))

    frac = np.full(L, 1.0 / L)
    hw = np.ones((L, H))
    mr = 1
    if "layer_frac" in assets and getattr(ns, "warm", False):
        frac = np.asarray(assets["layer_frac"], dtype=float)
        hw = np.asarray(assets.get("head_w", hw), dtype=float)
        mr = int(assets.get("min_recent", mr))
    best_val = objective(frac, hw, mr)
    print("start", best_val, flush=True)
    for it in range(2):
        for l in range(L):
            for delta in (-0.12, -0.05, 0.05, 0.12):
                f = frac.copy()
                f[l] += delta
                if f[l] < 0.02:
                    continue
                f = f / f.sum()
                v = objective(f, hw, mr)
                if v < best_val:
                    best_val, frac = v, f
                    print("frac", np.round(f, 3), round(v, 4), f"{time.time() - t0:.0f}s", flush=True)
        for l in range(L):
            for h in range(H):
                for mult in (0.5, 2.0):
                    w = hw.copy()
                    w[l, h] *= mult
                    v = objective(frac, w, mr)
                    if v < best_val:
                        best_val, hw = v, w
                        print("head_w", l, h, w[l, h], round(v, 4), f"{time.time() - t0:.0f}s", flush=True)
        for m in (0, 1, 2, 4):
            v = objective(frac, hw, m)
            if v < best_val:
                best_val, mr = v, m
    assets = dict(assets)
    assets["layer_frac"] = frac
    assets["head_w"] = hw
    assets["min_recent"] = np.asarray(mr)
    np.savez_compressed(ns.out, **assets)
    print("saved", ns.out, "layer_frac", np.round(frac, 3), "min_recent", mr, "obj", best_val,
          "\nhead_w", np.round(hw, 2).tolist(), f"{time.time() - t0:.0f}s")


if __name__ == "__main__":
    main()
