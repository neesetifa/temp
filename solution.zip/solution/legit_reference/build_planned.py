"""Builder for the planned-mode reference assets (agent-visible data only).

    python build_planned.py --app /app --base ref_assets_trees.npz --budget 96 --out ref_assets.npz

1. Head roles from full-cache attention on training sequences:
   fact heads  = heads that put >0.3 attention on the fact value at "ASK key" positions;
   topic heads = heads that put >0.5 attention on the latest topic marker at filler positions.
2. Per-key ask rate estimated on the training corpus (smoothed).
3. Fact-query model: P(fact is asked at or after chunk end e | fact-level features),
   gradient boosted, exported to numpy trees (prefix q_).
4. Budget plan tuned by coordinate search on held-out training sequences with the
   group-balanced objective from build_reference.py.
"""
from __future__ import annotations

import argparse
from pathlib import Path
import sys
import time

import numpy as np
from sklearn.ensemble import HistGradientBoostingRegressor

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from policy import (SeqState, EvictionPolicy, fact_features, ROLE_FACT_VAL, ROLE_ASK_KEY,  # noqa: E402
                    ROLE_FILLER, ROLE_TOPIC)
from build_reference import export_hgb, full_attention, position_groups  # noqa: E402


def head_roles(model, toks, n=30):
    L, H = model.L, model.H
    fact = np.zeros((L, H)); nf = 0
    topic = np.zeros((L, H)); nt = 0
    for t in toks[:n]:
        st = SeqState(len(t)); st.push(t)
        _, A = full_attention(model, t)
        for q in np.flatnonzero(st.role == ROLE_ASK_KEY):
            k = int(t[q])
            fp = [v for kk, v in st.fact_pos.items() if kk == k]
            if fp and 0 <= fp[0][2] < q:
                fact += A[:, :, q, fp[0][2]]; nf += 1
        tp = np.flatnonzero(st.role == ROLE_TOPIC)
        for q in np.flatnonzero(st.role == ROLE_FILLER):
            prev = tp[tp < q]
            if prev.size and q - prev.max() > 8:
                topic += A[:, :, q, prev.max()]; nt += 1
    fact /= max(nf, 1); topic /= max(nt, 1)
    fh = np.argwhere(fact > 0.3)
    th = np.argwhere((topic > 0.5) & (fact <= 0.3))
    return fh, th, fact, topic


def key_rates(toks):
    asked = np.zeros(64); defined = np.zeros(64)
    for t in toks:
        st = SeqState(len(t)); st.push(t)
        for k in st.fact_pos:
            defined[k - 80] += 1
            asked[k - 80] += bool(st.asks.get(k))
    return (asked + 2.0) / (defined + 4.0)


def fact_rows(toks, key_rate, chunk):
    X, y = [], []
    for t in toks:
        st = SeqState(len(t)); st.push(t)
        for e in range(chunk, len(t), chunk):
            vpos, F = fact_features(st, e, key_rate)
            if not vpos.size:
                continue
            lab = [any(x >= e for x in st.asks.get(int(st.key_of[p]), [])) for p in vpos]
            X.append(F); y.append(np.asarray(lab, float))
    return np.concatenate(X), np.concatenate(y)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--app", default="/app")
    ap.add_argument("--base", required=True, help="assets file with the general importance trees (t_*)")
    ap.add_argument("--out", required=True)
    ap.add_argument("--budget", type=int, default=96)
    ap.add_argument("--n-tune", type=int, default=8)
    ap.add_argument("--passes", type=int, default=2)
    ns = ap.parse_args()
    app = Path(ns.app)
    sys.path.insert(0, str(app))
    from kvmodel import TinyLM, kl_full_vs
    model = TinyLM(app / "model.npz")
    toks = np.load(app / "data" / "train_tokens.npy").astype(np.int64)
    chunk, budget = 32, ns.budget
    L, H = model.L, model.H
    t0 = time.time()
    with np.load(ns.base, allow_pickle=False) as z:
        base = {k: z[k] for k in z.files}
    assets = {k: v for k, v in base.items() if k.startswith("t_")}

    fh, th, fact_att, topic_att = head_roles(model, toks)
    print("fact heads", fh.tolist(), "topic heads", th.tolist(), f"{time.time() - t0:.0f}s", flush=True)
    kr = key_rates(toks[:600])
    X, y = fact_rows(toks[:400], kr, chunk)
    q = HistGradientBoostingRegressor(max_iter=150, learning_rate=0.08, max_leaf_nodes=31,
                                      min_samples_leaf=50, random_state=0).fit(X, y)
    qa = export_hgb(q)
    print(f"fact model rows={len(y)} pos_rate={y.mean():.3f} {time.time() - t0:.0f}s", flush=True)
    assets.update({"q_" + k[2:]: v for k, v in qa.items()})
    assets.update({"fact_heads": fh, "topic_heads": th, "key_rate": kr})

    tune = toks[600:600 + ns.n_tune]
    fulls = [model.run(t) for t in tune]
    groups = [position_groups(t)[chunk:-1] for t in tune]
    cfg = {"d": model.d, "heads": H, "layers": L, "head_dim": model.hd, "vocab": model.V,
           "chunk": chunk, "seq_len": toks.shape[1], "budget": budget, "app_dir": str(app)}

    def objective(p):
        a = dict(assets)
        a.update({"fact_cap": p["fact_cap"], "layer_frac": p["layer_frac"], "head_w": p["head_w"],
                  "min_recent": np.asarray(p["min_recent"])})
        pol = EvictionPolicy(cfg, assets=a)
        kls = [kl_full_vs(f, model.run(t, policy=pol, budget=budget, chunk=chunk))[chunk:-1]
               for t, f in zip(tune, fulls)]
        kl, g = np.concatenate(kls), np.concatenate(groups)
        return float(np.mean([np.log(kl[g == k].mean() + 1e-6) for k in (1, 3, 0)]))

    special = {tuple(x) for x in fh.tolist()} | {tuple(x) for x in th.tolist()}
    p = {"fact_cap": np.full(len(fh), 0.2), "layer_frac": np.full(L, 1.0 / L),
         "head_w": np.ones((L, H)), "min_recent": 1}
    best = objective(p)
    print("start", round(best, 4), flush=True)

    def try_(q, tag):
        nonlocal best, p
        v = objective(q)
        if v < best:
            best, p = v, q
            print(tag, round(v, 4), f"{time.time() - t0:.0f}s", flush=True)

    for it in range(ns.passes):
        for i in range(len(fh)):
            for d in (-0.08, -0.04, 0.04, 0.08):
                q = {**p, "fact_cap": p["fact_cap"].copy()}
                q["fact_cap"][i] = max(0.01, q["fact_cap"][i] + d)
                if (q["fact_cap"].sum() * budget + 2 * len(th)) < budget - 8:
                    try_(q, f"fact_cap {np.round(q['fact_cap'], 3)}")
        for l in range(L):
            for d in (-0.12, -0.05, 0.05, 0.12):
                q = {**p, "layer_frac": p["layer_frac"].copy()}
                q["layer_frac"][l] = max(0.02, q["layer_frac"][l] + d)
                q["layer_frac"] /= q["layer_frac"].sum()
                try_(q, f"layer_frac {np.round(q['layer_frac'], 3)}")
        for l in range(L):
            for h in range(H):
                if (l, h) in special:
                    continue
                for m in (0.5, 2.0):
                    q = {**p, "head_w": p["head_w"].copy()}
                    q["head_w"][l, h] *= m
                    try_(q, f"head_w {l} {h} {q['head_w'][l, h]}")
        for mr in (0, 1, 2, 4):
            if mr != p["min_recent"]:
                try_({**p, "min_recent": mr}, f"min_recent {mr}")
    assets.update({"fact_cap": p["fact_cap"], "layer_frac": p["layer_frac"], "head_w": p["head_w"],
                   "min_recent": np.asarray(p["min_recent"])})
    np.savez_compressed(ns.out, **assets)
    print("saved", ns.out, {k: np.round(v, 3).tolist() if hasattr(v, "tolist") else v for k, v in p.items()},
          "obj", round(best, 4), f"{time.time() - t0:.0f}s")


if __name__ == "__main__":
    main()
