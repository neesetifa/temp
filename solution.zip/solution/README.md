# kv_cache_eviction: reference and calibration notes (verifier side)

## v0.2 change (after the v0.1 frontier probe)

In v0.1 the probe ran two agents for 5 runs each. 4 of the 10 runs reached 0.98 or higher, and the best runs beat the legitimate reference by 2-4x on every KL component. The anchors had been set at reference x 1.08, so the reward saturated.

v0.2 keeps the model, the budget (96), the hidden shards and the raw metrics unchanged. Only two things change:

- **The solution is now a privileged ORACLE** (`oracle_policy.py`, installed by `solve.sh`). It uses the hidden mechanism: it regenerates the hidden sequences from the generator, identifies the current sequence from its first chunk, and keeps exactly the entries that future queries will attend to. Its allocation knobs are tuned on training sequences with the reward-shaped objective.
- **The score-1 anchor of each KL component** = 0.8 x min(oracle, best observed v0.1 agent). Top-1 agreement reaches score 1 at 1.0. Nothing saturates any more.

Because the raw metrics are unchanged, the v0.1 runs can be re-scored offline from their `metrics.json`:

    python tests/rescore.py run*/metrics.json

| policy | v0.1 reward | v0.2 reward |
|---|---:|---:|
| generic policies: starter, H2O, Pyramid/Ada-SnapKV | 0 | 0 |
| strong-agent probe A / B (author-written) | 0.67 / 0.81 | 0.41 / 0.47 |
| legitimate learned reference (`legit_reference/`) | 1.00 | 0.57 |
| best v0.1 agent run (codex; top-1 assumed 0.995 / 0.975) | 1.00 | about 0.77 |
| **ORACLE** (`oracle_policy.py`, verified through `test.sh` as `nobody`) | - | **0.905** |

The ORACLE's metrics:

- in_dist: answer_kl 0.0054, top1 0.997, filler_kl 0.0145, other_kl 0.132
- shifted: answer_kl 0.0251, top1 0.993, filler_kl 0.0279, other_kl 0.249

On `other_kl` the oracle is worse than the best agent, which is why that anchor comes from the agent. The answer and filler anchors come from the oracle, whose future knowledge puts them 1.4-5x below the best agent.

The rest of this file describes the v0.1 legitimate reference, now kept in `legit_reference/`.


**Task one-liner:** Under a 96-entry global KV budget (about 1.2% of the full 8192-entry cache), write a chunked KV-cache eviction policy for a private pretrained 4-layer decoder. The policy is scored by KL(full || compressed) per position-role group on hidden in-distribution and shifted workloads. Generic attention-statistics eviction (H2O, SnapKV, Ada-KV, PyramidKV) scores 0. Reaching the reference needs model-specific reverse engineering plus learned, budget-aware prioritization.

## What makes it hard (all discoverable from /app only)

1. **Heterogeneous heads.** Layer-1 heads 0/1/2 are associative-retrieval heads that attend to fact values. Layer-1 head 3 tracks the latest topic marker. Several layer-2/3 heads sink onto DEF markers, and the rest average diffusely over filler. Every head type needs a different kind of entry.
2. **Future importance is not current attention.** Fact values receive almost no attention until they are asked for, so heavy-hitter and observation-window scores evict exactly the entries that matter.
3. **Tight budget.** 96 entries cannot hold every fact in every retrieval head and still serve the diffuse heads. The policy must predict which facts will be asked later. Pinned facts get asked late, unpinned facts are asked soon or never, some keys are asked more often, and facts already asked may be asked again. It then has to trade fact retention against filler and other context.
4. **Shift.** The hidden shifted shard has more facts, more pins, longer ask gaps and longer topic segments.
5. **No token ids.** The policy never receives token ids, but layer-0 pre-RoPE keys are a deterministic function of the token, so tokens can be decoded exactly from `view.keys` using the shipped weights.

## Legitimate reference (`legit_reference/policy.py` + `ref_assets.npz`)

The reference uses only the shipped weights and training corpus:

- exact token decoding and an incremental grammar parse;
- a gradient-boosted predictor of future max attention for every (layer, head, entry), with trees exported to numpy;
- head roles detected from training attention;
- a gradient-boosted P(fact asked later) model;
- a hybrid in-layer top-k, with layer shares, head weights and fact weight/bias tuned by coordinate search on held-out training sequences.

The tuning objective is the mean over recovered position groups of log mean KL. Runtime is about 1.2 s per sequence.

Assets were produced on 2 CPU cores, about 1.5 h in total:

```
python build_reference.py --app /app --out base512.npz --budget 512 --n-train 80 --n-tune 8           # fit t_* trees
python build_reference.py --app /app --out v1_160.npz --budget 160 --n-tune 8 --reuse base512.npz      # shares @160
python build_reference.py --app /app --out v3_160.npz --budget 160 --n-tune 8 --reuse v1_160.npz --warm
python build_reference.py --app /app --out v3_96.npz  --budget 96  --n-tune 8 --reuse v3_160.npz --warm
python build_hybrid.py    --app /app --base v3_96.npz --budget 96 --out ref_assets.npz                 # final
```

`build_planned.py` holds helpers used by `build_hybrid.py`: head-role detection, key ask rates and fact rows.

## Calibration ladder (hidden shards, 60 sequences each, budget 96)

| policy | reward | in_dist answer_kl / top1 / filler_kl / other_kl | shifted answer_kl / top1 / filler_kl / other_kl |
|---|---:|---|---|
| starter: sinks + recent window | 0.000 | 7.41 / 0.12 / 2.47 / 1.39 | 7.95 / 0.06 / 2.19 / 1.26 |
| H2O | 0.000 | 7.18 / 0.13 / 0.77 / 0.66 | 7.83 / 0.07 / 0.59 / 0.67 |
| Pyramid + Ada-SnapKV (EMA) | 0.000 | about 7.3 / 0.16 / 0.74 / 0.71 | about 8.2 / 0.08 / 1.02 / 0.86 |
| strong-agent probe A: token decode, fact heads keep all facts, topic head, H2O elsewhere | 0.667 | 0.24 / 0.97 / 0.046 / 0.45 | 0.50 / 0.93 / 0.073 / 0.50 |
| strong-agent probe B: probe A + pinned priority, 60% fact budget | 0.807 | - | - |
| reference | 1.000 | 0.085 / 0.989 / 0.032 / 0.341 | 0.324 / 0.957 / 0.055 / 0.440 |
| cheating future-attention oracle (budget 160, not a policy) | - | 0.013 / 0.996 / 0.030 / 0.128 | 0.010 / 0.994 / 0.048 / 0.240 |

Reward = 0.4 × in_dist + 0.6 × shifted. Each shard score is
0.45·answer_kl + 0.20·answer_top1 + 0.20·filler_kl + 0.15·other_kl.
Each KL component is interpolated in log space between its anchors; top-1 is interpolated linearly. The anchors and how they were chosen are recorded in `tests/hidden_eval.py`.

## Verifier notes

- The model weights used for scoring are `tests/model.npz`, the verifier's own copy. `/app/model.npz` is never trusted.
- The policy runs as `nobody` in `tests/policy_server.py` and receives one framed `.npz` (`allow_pickle=False`) per (chunk, layer) step. It never sees token ids, future positions or verifier objects. `test_security.py` checks this, and `/tests` is locked down with `chmod 700` before scoring.
- Hard zero on: budget violation, invalid indices, crash, or a total policy time above 20 min.
- Runtime: starter about 60 s and reference about 150 s for the whole `test.sh`, measured on 2 cores.
- Design change during development: the quote/re-quote copy mechanism did not train at this model size, so its positions are folded into `other` and quotes act only as distractor spans.
