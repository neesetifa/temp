from __future__ import annotations

import os
import subprocess
import sys
import numpy as np

RUNNER = "/sandbox/agent_call.py"
IO_DIR = "/sandbox/io"
_counter = [0]
REQUIRED = ("fit_forecast_policy", "predict_forecast")


def _sandbox_ready() -> bool:
    return os.path.exists(RUNNER) and getattr(os, "geteuid", lambda: 1000)() == 0


def _demote():
    import ctypes
    import pwd

    try:
        ctypes.CDLL("libc.so.6", use_errno=True).prctl(38, 1, 0, 0, 0)
    except Exception:
        pass

    p = pwd.getpwnam("nobody")
    try:
        os.setgroups([])
    except Exception:
        pass
    os.setgid(p.pw_gid)
    os.setuid(p.pw_uid)


def _eval_inproc(solve_path, payload):
    import agent_call

    return agent_call.run_eval(agent_call._load(solve_path), payload)


def _write_payload_npz(path, payload):
    train = payload["train"]
    inputs = payload["inputs"]
    data = {"n_inputs": np.asarray(len(inputs), dtype=np.int64)}
    for i, arr in enumerate(train):
        data[f"train_{i}"] = np.asarray(arr)
    for j, inp in enumerate(inputs):
        for i, arr in enumerate(inp):
            data[f"input_{j}_{i}"] = np.asarray(arr)
    np.savez(path, **data)


def run_eval(solve_path, payload, timeout=360):
    if not _sandbox_ready():
        return _eval_inproc(solve_path, payload)
    _counter[0] += 1
    in_path = os.path.join(IO_DIR, f"in_eval_{_counter[0]}.npz")
    out_path = os.path.join(IO_DIR, f"out_eval_{_counter[0]}.npz")
    _write_payload_npz(in_path, payload)
    os.chmod(in_path, 0o644)
    if os.path.exists(out_path):
        os.remove(out_path)
    r = subprocess.run(
        [sys.executable, RUNNER, solve_path, "eval", in_path, out_path],
        preexec_fn=_demote,
        capture_output=True,
        text=True,
        timeout=timeout,
    )
    if r.returncode != 0 or not os.path.exists(out_path):
        raise RuntimeError(
            f"sandboxed eval failed (rc={r.returncode}): {r.stderr[-800:]}"
        )
    with np.load(out_path, allow_pickle=False) as z:
        n = int(z["n"])
        return {"preds": [np.asarray(z[f"p{i}"], dtype=np.float64) for i in range(n)]}


def check_solution(solve_path) -> bool:
    if not _sandbox_ready():
        try:
            import agent_call

            m = agent_call._load(solve_path)
            return all(callable(getattr(m, n, None)) for n in REQUIRED)
        except Exception:
            return False
    r = subprocess.run(
        [sys.executable, RUNNER, solve_path, "check"],
        preexec_fn=_demote,
        capture_output=True,
        text=True,
        timeout=60,
    )
    return r.returncode == 0
