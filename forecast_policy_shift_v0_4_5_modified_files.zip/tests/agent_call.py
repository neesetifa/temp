import importlib.util
import os
import sys
import numpy as np


REQUIRED = ("fit_forecast_policy", "predict_forecast")

TRAIN_NAMES = (
    "train_time", "train_market", "train_context_X", "train_candidate_pred", "train_y"
)
INPUT_NAMES = (
    "time", "market", "context_X", "candidate_pred"
)


def _load(path):
    sys.path.insert(0, os.path.dirname(os.path.abspath(path)))  # /app only
    spec = importlib.util.spec_from_file_location("candidate_solve", path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot load solve module at {path}")
    module = importlib.util.module_from_spec(spec)
    # Register so pickling/unpickling classes defined in solve.py resolves.
    sys.modules["candidate_solve"] = module
    spec.loader.exec_module(module)
    return module


def _arrays_equal(a, b):
    return np.array_equal(np.asarray(a), np.asarray(b))


def _safe_param_signature(obj, depth=0, seen=None):
    """Best-effort deterministic signature for common parameter containers.

    The grading contract is prediction determinism; arbitrary fitted estimator
    objects are not required to be byte-identical. This signature catches common
    accidental stochastic params in dict/list/array/scalar returns without
    failing valid opaque model objects whose internal state is not safely
    comparable.
    """
    if seen is None:
        seen = set()
    if depth > 6:
        return ("opaque", type(obj).__name__)
    oid = id(obj)
    if oid in seen:
        return ("cycle", type(obj).__name__)
    if isinstance(obj, (str, bytes, int, float, bool, type(None), np.integer, np.floating, np.bool_)):
        if isinstance(obj, (float, np.floating)) and not np.isfinite(float(obj)):
            return (type(obj).__name__, "nonfinite", str(obj))
        return (type(obj).__name__, obj.item() if hasattr(obj, "item") else obj)
    if isinstance(obj, np.ndarray):
        arr = np.asarray(obj)
        return ("ndarray", str(arr.dtype), arr.shape, arr.tolist())
    if isinstance(obj, dict):
        seen.add(oid)
        try:
            items = sorted(obj.items(), key=lambda kv: repr(kv[0]))
            return ("dict", tuple((repr(k), _safe_param_signature(v, depth + 1, seen)) for k, v in items))
        finally:
            seen.discard(oid)
    if isinstance(obj, (list, tuple)):
        seen.add(oid)
        try:
            return (type(obj).__name__, tuple(_safe_param_signature(v, depth + 1, seen) for v in obj))
        finally:
            seen.discard(oid)
    # Estimators / arbitrary model objects: compare stable public scalar/array attrs if present,
    # otherwise mark opaque. Do not inspect callables or private handles.
    d = getattr(obj, "__dict__", None)
    if isinstance(d, dict):
        public = {}
        for k, v in d.items():
            if k.startswith("_"):
                continue
            if callable(v):
                continue
            if isinstance(v, (str, bytes, int, float, bool, type(None), np.integer, np.floating, np.ndarray, list, tuple, dict)):
                public[k] = v
        if public:
            return (type(obj).__name__, _safe_param_signature(public, depth + 1, seen))
    return ("opaque", type(obj).__name__)


def _fit_once(module, train):
    tr = tuple(np.array(a, copy=True) for a in train)
    tr_before = [np.array(a, copy=True) for a in tr]
    params = module.fit_forecast_policy(*tr)
    for orig, cur, name in zip(tr_before, tr, TRAIN_NAMES):
        if not np.array_equal(orig, cur):
            raise RuntimeError(f"fit mutated input {name}")
    return params


def _predict_checked(module, params, inp, label):
    copies = [np.array(a, copy=True) for a in inp]
    inp1 = tuple(np.array(a, copy=True) for a in inp)
    p1 = module.predict_forecast(*inp1, params)
    for orig, cur, name in zip(copies, inp1, INPUT_NAMES):
        if not np.array_equal(orig, cur):
            raise RuntimeError(f"predict mutated input {name} ({label})")
    inp2 = tuple(np.array(a, copy=True) for a in copies)
    p2 = module.predict_forecast(*inp2, params)
    p1_arr = np.asarray(p1, dtype=np.float64)
    p2_arr = np.asarray(p2, dtype=np.float64)
    if p1_arr.shape != p2_arr.shape or not np.allclose(p1_arr, p2_arr, atol=1e-10, rtol=1e-10):
        raise RuntimeError(f"nondeterministic predict {label}")
    return p1_arr


def run_eval(module, payload):
    """Fit twice on identical training arrays and predict all verifier inputs.

    Params stay inside this process (opaque to the grader).  The second fit is
    intentional: it catches stochastic fitting that a repeated-predict check
    would miss.
    """
    train = payload["train"]
    params_a = _fit_once(module, train)
    params_b = _fit_once(module, train)

    # Best-effort comparison for simple parameter containers.  Prediction
    # equality below is the authoritative deterministic-behavior check for
    # arbitrary fitted model objects.
    if _safe_param_signature(params_a) != _safe_param_signature(params_b):
        raise RuntimeError("nondeterministic fit parameters")

    preds = []
    for idx, inp in enumerate(payload["inputs"]):
        pa = _predict_checked(module, params_a, inp, f"batch {idx} fit A")
        pb = _predict_checked(module, params_b, inp, f"batch {idx} fit B")
        if pa.shape != pb.shape or not np.allclose(pa, pb, atol=1e-10, rtol=1e-10):
            raise RuntimeError(f"nondeterministic fit predictions batch {idx}")
        preds.append(pa)
    return {"preds": preds}


def main():
    solve_path = sys.argv[1]
    cmd = sys.argv[2]
    try:
        module = _load(solve_path)
    except ModuleNotFoundError as exc:
        print(f"dependency_error: {exc.name}: {exc}", file=sys.stderr)
        sys.exit(2)
    except ImportError as exc:
        print(f"dependency_error: {exc}", file=sys.stderr)
        sys.exit(2)
    except Exception as exc:
        print(f"import_error: {type(exc).__name__}: {exc}", file=sys.stderr)
        sys.exit(2)

    if cmd == "check":
        ok = all(callable(getattr(module, n, None)) for n in REQUIRED)
        sys.exit(0 if ok else 1)
    in_path, out_path = sys.argv[3], sys.argv[4]
    with np.load(in_path, allow_pickle=False) as z:
        n_train = len(TRAIN_NAMES)
        train = tuple(np.asarray(z[f"train_{i}"]) for i in range(n_train))
        n_inputs = int(z["n_inputs"])
        inputs = []
        for j in range(n_inputs):
            inputs.append(tuple(np.asarray(z[f"input_{j}_{i}"]) for i in range(len(INPUT_NAMES))))
    payload = {"train": train, "inputs": inputs}
    result = run_eval(module, payload) if cmd == "eval" else getattr(module, cmd)(*payload)
    preds = result["preds"] if isinstance(result, dict) else result
    np.savez(out_path, n=np.asarray(len(preds)),
             **{f"p{i}": np.asarray(p, dtype=np.float64) for i, p in enumerate(preds)})


if __name__ == "__main__":
    main()
