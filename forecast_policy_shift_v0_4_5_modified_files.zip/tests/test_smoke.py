from pathlib import Path

APP_DIR = Path('/app')


def test_solve_file_exists():
    assert (APP_DIR / 'solve.py').exists(), 'did not produce /app/solve.py'


def test_training_files_exist():
    assert (APP_DIR / 'train_data.npz').exists(), 'train_data.npz missing'
    assert (APP_DIR / 'public_eval.npz').exists(), 'public_eval.npz missing'
