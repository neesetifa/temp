#!/bin/bash
set -uo pipefail

mkdir -p /logs/verifier
rm -f /logs/verifier/reward.txt /logs/verifier/failure_mode.txt
printf '0' > /logs/verifier/reward.txt

mkdir -p /sandbox/io
cp /tests/agent_call.py /sandbox/agent_call.py
chmod 755 /sandbox /sandbox/agent_call.py
chmod 1777 /sandbox/io
chmod -R a+rX /app 2>/dev/null || true
find /app -xdev -perm /6000 -exec chmod a-s {} + 2>/dev/null || true
chmod 700 /tests
chmod -R go-rwx /solution 2>/dev/null || true

START_SEC=$(date +%s)

set +e
pytest /tests/test_smoke.py /tests/test_main.py \
  -v --tb=short \
  > /logs/verifier/stdout.txt 2> /logs/verifier/stderr.txt
EXIT=$?
set -e

if [ "$EXIT" -ne 0 ]; then
    printf '0\n' > /logs/verifier/reward.txt
    if grep -qi "failed to import in the sandbox\|did not produce /app/solve.py" \
        /logs/verifier/stderr.txt /logs/verifier/stdout.txt 2>/dev/null; then
        echo pipeline_broken > /logs/verifier/failure_mode.txt
    else
        python3 /tests/categorize_failure /logs/verifier/stderr.txt \
            > /logs/verifier/failure_mode.txt 2>/dev/null \
            || echo unknown > /logs/verifier/failure_mode.txt
    fi
else
    python3 -I -S - /logs/verifier/reward.txt <<'PY'
import sys
path = sys.argv[1]
try:
    val = float(open(path).read().strip())
except Exception:
    val = 0.0
if not (0.0 <= val <= 1.0):
    val = 0.0
open(path, 'w').write(f'{val:.12f}\n')
PY
fi

END_SEC=$(date +%s)
echo $(( END_SEC - START_SEC )) > /logs/verifier/wall_clock_sec.txt
if [ -f /proc/self/status ]; then
    awk '/VmHWM/ {printf "%.0f\n", $2/1024}' /proc/self/status \
        > /logs/verifier/peak_memory_mb.txt 2>/dev/null
fi

exit 0
