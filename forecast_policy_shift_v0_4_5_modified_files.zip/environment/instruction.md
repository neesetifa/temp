# Forecast policy update

`app/solve.py` still applies one simple rule to all of the forecast columns. Replace that policy.

The reporting system already has several forecasting models. Their sales-count predictions are stored in `candidate_pred`, and the candidate columns keep the same meaning between the labeled archive and deployment rows. Historical archive rows also include the final observed sales count, so they can be used as backtests for the existing forecasts.

The archive is uneven across markets. Some market IDs have several forecast vintages with labels, some histories are older, some only have a recent portion of the archive, and some deployment-time markets have no labeled selector rows. Candidate quality also changes with how far ahead the forecast is being made, so a policy tuned only to short-range backtests is not enough for the deployment period.

Implement these functions in `app/solve.py`:

```python
def fit_forecast_policy(
    train_time,
    train_market,
    train_context_X,
    train_candidate_pred,
    train_y,
):
    ...
```

```python
def predict_forecast(
    time,
    market,
    context_X,
    candidate_pred,
    params,
):
    ...
```

`candidate_pred` has one row per monthly forecast record and one column per existing forecasting model. Values are non-negative sales-count predictions.

`time` is a monthly index and `market` is an anonymized market ID. `context_X` contains information available with the forecast record. Its first column is the forecast horizon in months; the remaining columns describe calendar and historical market profile information. The column layout is unchanged between fitting and prediction.

The deployment rows cover forecasts roughly 4 to 46 months beyond the corresponding labeled archive cutoff. Treat the problem as out-of-time deployment rather than an IID random holdout.

Forecast quality is measured using
`RMSE(log1p(prediction), log1p(observed_sales))`.
Evaluation considers both overall performance and performance on several held-out cohorts. The cohort definitions and scoring thresholds are not part of the API contract.

Return one non-negative finite sales-count prediction for every input row, in the original row order. You may select candidates, combine them, or learn a policy from the archived backtests.

Do not modify the input arrays. Do not read hidden files or use external data or network access. Grading runs without internet access; use only the bundled arrays and packages available in the base image. The result must be deterministic for the same inputs, including repeated fitting on the same archive.
