from __future__ import annotations

import importlib.util
import sys
from pathlib import Path

import lightgbm as lgb
import numpy as np
from sklearn.linear_model import Ridge

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "tests"))

def _load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); return mod

gen = _load(ROOT / "tests" / "generator.py", "gen")
ref = _load(ROOT / "solution" / "reference_solution.py", "ref")
he = _load(ROOT / "tests" / "hidden_eval.py", "he")

def _lp(x): return np.log1p(np.maximum(np.asarray(x,float),0.0))
def _fromlog(x): return np.maximum(np.expm1(np.asarray(x,float)),0.0)
def _rmse(y,z): return float(np.sqrt(np.mean((_lp(y)-np.asarray(z,float))**2)))

def _ctx(data, market=False):
    p=_lp(data["candidate_pred"]); c=np.asarray(data["context_X"],float)
    parts=[p,p.mean(1,keepdims=True),p.std(1,keepdims=True),np.median(p,1)[:,None],c,np.asarray(data["time"],float)[:,None]/200]
    if market:
        m=np.asarray(data["market"],int); oh=np.zeros((len(m),46)); oh[np.arange(len(m)),np.clip(m,0,45)]=1; parts.append(oh)
    return np.concatenate(parts,1)

def _lgb(train,hidden,market=False):
    X=_ctx(train,market); Xh=_ctx(hidden,market); y=_lp(train["y"])
    m=lgb.LGBMRegressor(n_estimators=450,learning_rate=.025,num_leaves=15,max_depth=5,min_child_samples=30,
        reg_lambda=10.,reg_alpha=1.,verbosity=-1,random_state=7,n_jobs=1)
    m.fit(X,y); return m.predict(Xh)

def _score_only(hidden, pred_log):
    return _rmse(hidden["y"], pred_log)

def run():
    train=gen.generate_train(); hidden=gen.generate_hidden(); pt=_lp(train["candidate_pred"]); ph=_lp(hidden["candidate_pred"]); yt=_lp(train["y"])
    params=ref.fit_forecast_policy(train["time"],train["market"],train["context_X"],train["candidate_pred"],train["y"])
    P={}
    P["simple_average"]=ph.mean(1)
    P["robust_median"]=np.median(ph,1)
    P["global_ridge_stack"]=Ridge(alpha=12.).fit(pt,yt).predict(ph)
    P["context_lgbm"]=_lgb(train,hidden,False)
    P["market_context_lgbm"]=_lgb(train,hidden,True)
    # Directly replay a strong frontier-style static hierarchical selector.
    P["static_hierarchical_selector"]=ref._predict_log(hidden["time"],hidden["market"],hidden["context_X"],hidden["candidate_pred"],params,
        use_market=True,use_freshness=False,use_horizon=False,use_similarity=True)
    P["no_market_state"]=ref._predict_log(hidden["time"],hidden["market"],hidden["context_X"],hidden["candidate_pred"],params,
        use_market=False,use_freshness=True,use_horizon=True,use_similarity=True)
    P["no_freshness"]=ref._predict_log(hidden["time"],hidden["market"],hidden["context_X"],hidden["candidate_pred"],params,
        use_market=True,use_freshness=False,use_horizon=True,use_similarity=True)
    P["no_horizon"]=ref._predict_log(hidden["time"],hidden["market"],hidden["context_X"],hidden["candidate_pred"],params,
        use_market=True,use_freshness=True,use_horizon=False,use_similarity=True)
    P["no_similarity"]=ref._predict_log(hidden["time"],hidden["market"],hidden["context_X"],hidden["candidate_pred"],params,
        use_market=True,use_freshness=True,use_horizon=True,use_similarity=False)
    P["reference_solution"]=ref._predict_log(hidden["time"],hidden["market"],hidden["context_X"],hidden["candidate_pred"],params)
    out={}
    for k,z in P.items():
        m=he._metrics(hidden["y"], _fromlog(z), hidden["slice_mask"]); out[k]=m
        print(f"{k:34s} reward={m["reward"]:.3f} log_rmse={m["overall_log_rmse"]:.6f}")
    r=out["reference_solution"]["overall_log_rmse"]
    print("\ncapability_ablation")
    for k in ["static_hierarchical_selector","no_market_state","no_freshness","no_horizon","no_similarity"]:
        print(f"  {k:30s} delta={out[k]["overall_log_rmse"]-r:+.6f}")
    print("\nreference_slices")
    z=P["reference_solution"]
    for i,nm in enumerate(gen.SLICE_NAMES):
        q=hidden["slice_mask"][i]; print(f"  {nm:28s} n={int(q.sum()):4d} rmse={_rmse(hidden['y'][q],z[q]):.6f}")
    return out

if __name__ == "__main__": run()
